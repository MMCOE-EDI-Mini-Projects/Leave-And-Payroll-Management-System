# Upgrade Plan: LeavePayrollManagementSystem (20260923093808)

- **Generated**: 2026-09-23
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 17: not available (baseline will be skipped)
- JDK 25: **<TO_BE_INSTALLED>** (required for upgrade and final validation)
- JDK 26: C:\Program Files\Java\jdk-26.0.2.1 (available, not used as the requested LTS target)

**Build Tools**
- Maven: **<TO_BE_INSTALLED>** (no Maven installation detected; required for all build verification)
- Version control: unavailable; changes will remain uncommitted in the working directory

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: N/A (not a Git repository)
- Run tests before and after the upgrade: true

## Upgrade Goals

- Java runtime/compiler target 25 (latest LTS)

## Technology Stack

| Technology/Dependency | Current | Min Compatible Version | Why Incompatible |
| --------------------- | ------- | ---------------------- | ---------------- |
| Java | 17 | 25 | User requested Java 25 LTS |
| Maven | Not installed | 3.9+ | Required to build and test the project |
| maven-compiler-plugin | Maven default | 3.14.1 | Explicit Java 25 compiler support |
| maven-surefire-plugin | Maven default | 3.5.3 | Reliable JUnit 5 execution on modern JDKs |
| Jakarta Servlet API | 6.0.0 | 6.0.0 | Compatible; no change required |
| MySQL Connector/J | 8.3.0 | 8.3.0 | Compatible; no change required |
| JUnit Jupiter | 5.10.0 | 5.10.0 | Compatible; no change required |
| Maven WAR Plugin | 3.4.0 | 3.4.0 | Compatible; no change required |

## Derived Upgrades

- Install JDK 25 because the requested runtime target is not present.
- Install Maven 3.9.x because no Maven executable is present and Maven 3.9+ is recommended for Java 25.
- Configure maven-compiler-plugin 3.14.1 with `release=25` to compile consistently against the requested runtime.
- Configure maven-surefire-plugin 3.5.3 so the existing JUnit 5 test suite executes reliably.
- Update deployment documentation from JDK 17 to JDK 25.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|------------|---------|--------|--------|--------|
| pom.xml | maven-compiler-plugin | Maven default | add | 3.14.1 | Explicit Java 25 compiler support and reproducible builds |
| pom.xml | maven-surefire-plugin | Maven default | add | 3.5.3 | JUnit 5 test execution on modern JDKs |
| Maven installation | Apache Maven | Not installed | add | 3.9.x | Required build tool |
| JDK installation | Java runtime | JDK 25 absent | add | 25 | Requested latest LTS runtime |

### Source Code Changes

| File | Location | Current | Required Change | Reason |
|------|----------|---------|-----------------|--------|
| Source tree | all Java sources | Java 17-compatible APIs; no internal JDK usage found | No source rewrite required | The compatibility scan found no `javax.*`, internal JDK packages, SecurityManager, or reflective JDK access patterns |

### Configuration Changes

| File | Property/Setting | Current | Required Change | Reason |
|------|------------------|---------|-----------------|--------|
| pom.xml | `maven.compiler.source` / `maven.compiler.target` | 17 | Set to 25 and add `maven.compiler.release=25` | Compile and test against Java 25 |

### CI/CD Changes

| File | Location | Current | Required Change |
|------|----------|---------|----------------|
| None found | N/A | No CI/CD configuration detected | No change required |

### Risks & Warnings

- **Runtime JDK availability**: JDK 25 is not installed. **Mitigation**: Install JDK 25 before modifying the build and verify Maven uses it.
- **No baseline JDK**: JDK 17 is unavailable, so a pre-upgrade compile/test baseline cannot be run. **Mitigation**: Use the existing test source and require clean Java 25 compile and full test success after the change.
- **WAR runtime compatibility**: Java 25 compatibility of the external servlet container is outside this repository. **Mitigation**: Preserve Jakarta Servlet 6 configuration and document the Java 25 requirement.
- **No version control**: The workspace is not a Git repository. **Mitigation**: Keep changes minimal and report exact files changed; no commit can be created.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Install the requested JDK and the required Maven build tool before any upgrade verification.
  - **Changes to Make**: Install JDK 25 and Maven 3.9.x.
  - **Verification**: List installed JDKs/Maven; expected JDK 25 and Maven 3.9+ available.

- Step 2: Setup Baseline
  - **Rationale**: Establish pre-upgrade build and test behavior when the current JDK is available.
  - **Changes to Make**: None.
  - **Verification**: Skipped because JDK 17 is unavailable; record this limitation.

- Step 3: Configure Java 25 Build
  - **Rationale**: Update the Maven build to target Java 25 and make compiler/test behavior reproducible.
  - **Changes to Make**: Apply Dependency Changes and Configuration Changes in `pom.xml`; update the JDK requirement in `docs/deployment-guide.md`.
  - **Verification**: `mvn clean test-compile -q` with JDK 25; expected successful main and test compilation.

- Step 4: Final Validation
  - **Rationale**: Confirm the requested target, clean compilation, packaging, and complete test suite.
  - **Changes to Make**: Resolve any Java 25 compilation or test failures found during validation.
  - **Verification**: `mvn clean test` and `mvn clean verify`; expected 100% test pass rate and successful WAR build.

- Step 5: CVE Validation & Fix
  - **Rationale**: Validate direct dependencies after the upgrade and remediate any reported vulnerabilities.
  - **Changes to Make**: Upgrade only vulnerable direct dependency versions when a patched version is available; preserve security pins unless verified safe to change.
  - **Verification**: Dependency extraction, CVE scan, clean test compilation, and a confirming CVE scan.

- Step 6: Final Validation and Summary
  - **Rationale**: Confirm every goal and document the completed upgrade and residual risks.
  - **Changes to Make**: Generate upgrade summary and coverage evidence.
  - **Verification**: All applicable progress steps completed; final build and tests successful.
