# Leave and Payroll Management System (LPMS)

> **College Engineering Design & Innovation (EDI) Mini-Project**  
> Built strictly with Core Java, Java Servlets (Jakarta EE 10 / Tomcat 10+), JDBC, MySQL 8.4, HTML5, CSS3, and Vanilla JavaScript.  
> *No third-party application frameworks (No Spring, No Hibernate, No JSP, No React/Vue/Node, No Bootstrap).*

---

## 1. Project Overview

The **Leave and Payroll Management System (LPMS)** is a comprehensive, multi-tiered enterprise web application engineered for college faculty and institutional workforce administration. The system automates the entire employee lifecycle—from onboarding and role-based directory management to working-day leave tracking, daily biometric attendance, attendance-driven Loss-of-Pay (LOP) calculations, rule-driven payroll calculation with statutory deductions (PF, Professional Tax) and progressive income tax (TDS), printable corporate salary statements (payslips), and audit-logged institutional compliance reports.

---

## 2. Foundational Computer Science & Engineering Concepts

### A. Data Structures & Algorithms
- **Arrays & Dynamic Lists (`ArrayList` / `List`)**: Used for sequential record handling, salary line item aggregations, and tabular projections.
- **Double-Ended FIFO Queues (`Queue` / `ArrayDeque`)**:
  - Implemented in [`LeaveApprovalQueue.java`](file:///src/main/java/com/lpms/service/LeaveApprovalQueue.java) for First-In, First-Out (FIFO) queue processing of pending leave applications and O(N) batch approvals.
- **Associative Arrays (`HashMap` / `Map`)**:
  - Used in [`PayrollRuleEngine.java`](file:///src/main/java/com/lpms/service/PayrollRuleEngine.java) for O(1) lookup of configured salary components, tax slabs, and employee salary definitions.
- **Searching Algorithms**:
  - [`SearchSortUtil.java`](file:///src/main/java/com/lpms/util/SearchSortUtil.java) implements `binarySearch` (O(log N)) with natural ordering and custom comparators, plus `binarySearchEmployeeByCode` for employee lookups.
- **Sorting Algorithms**:
  - [`SearchSortUtil.java`](file:///src/main/java/com/lpms/util/SearchSortUtil.java) implements:
    - **MergeSort**: Stable O(N log N) divide-and-conquer algorithm, integrated into the Monthly Payroll Register (`/api/payroll/register`) to sort by Employee Code, Gross Salary, Net Pay, Days Worked, and TDS Deducted.
    - **QuickSort**: In-place O(N log N) sorting using a median-of-three pivot selection strategy and Lomuto/Hoare partitioning principles.

### B. Object-Oriented Programming (OOP) & Design Patterns
- **Strategy Pattern**: Applied in [`PayrollRuleEngine.java`](file:///src/main/java/com/lpms/service/PayrollRuleEngine.java) via `SalaryCalculationStrategy` with specialized implementations:
  - `PercentageCalculationStrategy`: Computes basic-proportional components (e.g., HRA = 40% of Basic, PF = 12% of Basic).
  - `FlatCalculationStrategy`: Computes fixed allowance/deduction components (e.g., Special Allowance = ₹5,000, Professional Tax = ₹200).
  - `FormulaCalculationStrategy`: Progressive tax bracket evaluation for Income Tax / TDS.
- **Model-View-Controller (MVC) Architecture**:
  - **Model**: POJO domain entities in `com.lpms.model` with encapsulation and validation.
  - **View**: Semantic HTML5 views, CSS3 design system with print media query, and vanilla JS controllers.
  - **Controller**: Pure Jakarta EE Servlets mapping RESTful JSON endpoints in `com.lpms.controller`.
- **Data Access Object (DAO) Pattern**: Complete separation of persistence logic in `com.lpms.dao` with parameterized JDBC operations.

### C. Database Management Systems (DBMS)
- **3NF Relational Database Schema**: 19 normalized tables with explicit primary keys, foreign keys, cascade rules, and functional indexes.
- **ACID Transaction Management**:
  - Payroll execution in [`PayrollService.java`](file:///src/main/java/com/lpms/service/PayrollService.java) runs inside a single database transaction with `conn.setAutoCommit(false)`, `conn.commit()`, and rollback upon any calculation or SQL failure.
  - Duplicate payroll runs for the same year and month are strictly prevented.
- **Audit Logging**: Comprehensive trail in `audit_log` tracking entity modifications, user ID, timestamp, and IP address.

### D. Web Application Security
- **SQL Injection Prevention**: 100% parameterized queries via JDBC `PreparedStatement`.
- **Password Security**: BCrypt password hashing with cost factor 12; dummy verification timing to prevent user enumeration.
- **Brute Force Protection**: IP and username login throttling (`LoginThrottle`) locking accounts after 5 consecutive failures.
- **CSRF Defense**: Custom header enforcement (`X-Requested-With: LPMS`) for all state-changing HTTP requests.
- **Session Fixation Defense**: Immediate invalidation of old sessions upon authentication and issuance of fresh cookies with 30-minute inactivity timeouts.
- **Spreadsheet Formula Injection Defense**: Sanitization and single-quote escaping for exported CSV files preventing `=, +, -, @` execution in Excel.

---

## 3. System Architecture & Module Details

```
+-----------------------------------------------------------------------------------+
|                            Vanilla Frontend (HTML5 / CSS3 / ES6)                  |
|   Dashboard  |  Leave & FIFO  |  Attendance  |  Payslips  |  Payroll  |  Reports  |
+-----------------------------------------------------------------------------------+
                                        |  RESTful JSON / X-Requested-With: LPMS
+-----------------------------------------------------------------------------------+
|                        Authentication & Security Filter                           |
|       AuthenticationFilter  |  LoginThrottle  |  Role-Based Access Control        |
+-----------------------------------------------------------------------------------+
                                        |
+-----------------------------------------------------------------------------------+
|                        Jakarta EE 10 Servlet Controllers                          |
| LoginServlet | EmployeeServlet | LeaveServlet | AttendanceServlet |               |
| PayrollServlet | ReportServlet | AdminServlet | MeServlet | ChangePasswordServlet  |
+-----------------------------------------------------------------------------------+
                                        |
+-----------------------------------------------------------------------------------+
|                            Business & Algorithmic Services                        |
| LeaveApprovalQueue (FIFO) | PayrollRuleEngine (Strategy) | SearchSortUtil (Merge) |
| AuthService | AttendanceService | PayrollService                                  |
+-----------------------------------------------------------------------------------+
                                        |
+-----------------------------------------------------------------------------------+
|                            Data Access Objects (DAO)                              |
| EmployeeDAO | LeaveDAO | AttendanceDAO | PayrollDAO | AdminConfigDAO | AuditDAO   |
+-----------------------------------------------------------------------------------+
                                        |  JDBC (PreparedStatement)
+-----------------------------------------------------------------------------------+
|                                 MySQL 8.4 Database                                |
| 19 Normalized Tables (ACID Transactions, Foreign Keys, Triggers, Indexes)         |
+-----------------------------------------------------------------------------------+
```

### Module Breakdown:
1. **Module 1: Project Setup & Architecture**
   - Maven build configured with Jakarta EE 10 APIs and MySQL connector.
   - Centralized JDBC connection pool management in [`DBUtil.java`](file:///src/main/java/com/lpms/util/DBUtil.java).
2. **Module 2: Authentication & Authorization**
   - Roles: `EMPLOYEE`, `MANAGER`, `HR_ADMIN`.
   - Endpoints: `/api/auth/login`, `/api/auth/logout`, `/api/auth/me`, `/api/auth/change-password`.
3. **Module 3: Employee Management**
   - Full CRUD: Add employee, edit profile, deactivate/activate, change role, reset temporary password.
   - Endpoints: `/api/employees`, `/api/employees/{id}`, `/api/reference`.
4. **Module 4: Leave Management & FIFO Queue**
   - Entitlements, used balances, reserve calculations, weekend exclusion.
   - First-In, First-Out Queue (`ArrayDeque`) with head-of-queue reviewer and one-click Batch Approvals.
   - Endpoints: `/api/leaves`, `/api/leaves/types`, `/api/leaves/balances`, `/api/leaves/queue`, `/api/leaves/queue/next`.
5. **Module 5: Attendance, Policy & Loss-of-Pay Engine**
   - Daily Check-In / Check-Out, monthly attendance ledger, late penalty rules, attendance month locking, CSV attendance import.
   - Endpoints: `/api/attendance/today`, `/api/attendance/history`, `/api/attendance/team-summary`, `/api/attendance/policy`, `/api/attendance/holidays`.
6. **Module 6: Payroll Processing & Rule Engine**
   - Transactional payroll execution computing Basic, HRA, Special Allowance, Overtime, Arrears, Loss-of-Pay (LOP), PF, Professional Tax, and Income Tax (TDS).
   - Employee self-service payslip history and printable corporate payslip modal with `window.print()` styles.
   - Endpoints: `/api/payroll/run`, `/api/payroll/runs`, `/api/payroll/register`, `/api/payroll/payslip`, `/api/payroll/my-payslips`.
7. **Module 7: Reports, Administration & Institutional Exports**
   - Tabular reports with MergeSort sorting and CSV export for Payroll, Leaves, and Attendance.
   - Admin CRUD for Departments, Designations, Leave Types, Salary Components, Tax Slabs, Employee Salary Structures, and Audit Trail.
   - Endpoints: `/api/reports/*`, `/api/admin/*`.

---

## 4. Default Demo Accounts

All seed accounts are initialized with password: `Admin@123`

| Role | Username | Password | Access Capabilities |
| :--- | :--- | :--- | :--- |
| **HR Administrator** | `admin` | `Admin@123` | Full administrative control: payroll runs, employee management, reports, system configuration. |
| **Manager** | `manager` | `Admin@123` | Team management: review team leaves, FIFO queue decisions, batch approvals, team attendance. |
| **Employee** | `employee` | `Admin@123` | Self-service: apply leaves, check-in/out attendance, view historical payslips & print salary statements. |

---

## 5. Technology Stack & Prerequisites

- **Java Development Kit (JDK)**: Java 17 or higher (tested on OpenJDK 25 LTS).
- **Web Server / Servlet Container**: Apache Tomcat 10.1+ (Jakarta EE 10 namespace).
- **Database Server**: MySQL Server 8.4+ (listening on port 3306).
- **Build Tool**: Apache Maven 3.9+.

---

## 6. Setup, Execution & Testing Guide

### Step 1: Database Initialization
Open your MySQL terminal or client and execute the schema and seed scripts:
```sql
SOURCE database/schema.sql;
SOURCE database/seed.sql;
```

### Step 2: Run Automated Unit Tests
Execute the full test suite (46 unit tests covering security, searching, sorting, queues, rules, and payroll):
```powershell
mvn test -o
```
*Expected Result:*
```
[INFO] Results:
[INFO] Tests run: 46, Failures: 0, Errors: 0, Skipped: 0
[INFO] BUILD SUCCESS
```

### Step 3: Package the Web Application Archive (WAR)
```powershell
mvn package -o
```
This generates `target/lpms.war`.

### Step 4: Deploy to Apache Tomcat
Copy `target/lpms.war` to your Tomcat `webapps/` folder:
```powershell
Copy-Item "target/lpms.war" "C:\Tools\apache-tomcat\webapps\lpms.war"
```
Start Tomcat:
```powershell
& "C:\Tools\apache-tomcat\bin\catalina.bat" run
```

### Step 5: Access the Web Application
Open your browser and navigate to:
```
http://localhost:8080/lpms/
```
Log in using any of the demo accounts listed in Section 4.

---

## 7. Verification Summary

- **JUnit 5 Unit Tests**: 46 / 46 passing (`SearchSortUtilTest`, `LeaveApprovalQueueTest`, `PayrollRuleEngineTest`, `AttendancePolicyTest`, `AttendanceRulesTest`, `EmployeeValidatorTest`, `LeaveRulesTest`, `SecurityUtilTest`, `RoleRulesTest`).
- **Live Integration**:
  - Health check at `/health`: `{"app":"UP","database":"UP"}`.
  - Multi-employee payroll execution verified with automated TDS and statutory PF calculations.
  - MergeSort verified on `/api/payroll/register`.
  - Corporate printable payslips verified.
  - CSV exports verified for Payroll, Leaves, and Attendance.
