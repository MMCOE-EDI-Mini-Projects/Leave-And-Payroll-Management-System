package com.lpms.model;

import java.math.BigDecimal;

public class TaxSlab {
    private Long taxSlabId;
    private String taxRegime; // OLD, NEW
    private String financialYear; // e.g. 2025-2026
    private int slabOrder;
    private BigDecimal lowerLimit;
    private BigDecimal upperLimit; // null = no upper cap
    private BigDecimal taxRate; // percentage e.g. 5.00
    private BigDecimal cessRate; // e.g. 4.00

    public TaxSlab() {}

    public Long getTaxSlabId() { return taxSlabId; }
    public void setTaxSlabId(Long taxSlabId) { this.taxSlabId = taxSlabId; }

    public String getTaxRegime() { return taxRegime; }
    public void setTaxRegime(String taxRegime) { this.taxRegime = taxRegime; }

    public String getFinancialYear() { return financialYear; }
    public void setFinancialYear(String financialYear) { this.financialYear = financialYear; }

    public int getSlabOrder() { return slabOrder; }
    public void setSlabOrder(int slabOrder) { this.slabOrder = slabOrder; }

    public BigDecimal getLowerLimit() { return lowerLimit; }
    public void setLowerLimit(BigDecimal lowerLimit) { this.lowerLimit = lowerLimit; }

    public BigDecimal getUpperLimit() { return upperLimit; }
    public void setUpperLimit(BigDecimal upperLimit) { this.upperLimit = upperLimit; }

    public BigDecimal getTaxRate() { return taxRate; }
    public void setTaxRate(BigDecimal taxRate) { this.taxRate = taxRate; }

    public BigDecimal getCessRate() { return cessRate; }
    public void setCessRate(BigDecimal cessRate) { this.cessRate = cessRate; }
}
