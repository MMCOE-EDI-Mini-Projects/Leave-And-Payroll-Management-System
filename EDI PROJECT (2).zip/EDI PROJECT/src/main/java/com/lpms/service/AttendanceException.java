package com.lpms.service;

/** Attendance business-rule failure carrying the HTTP status the servlet should return. */
public class AttendanceException extends LeaveException {
    public AttendanceException(int status, String message) { super(status, message); }
}
