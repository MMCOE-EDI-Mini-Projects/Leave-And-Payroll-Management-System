package com.lpms.service;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.lpms.dao.AttendanceDAO;
import com.lpms.dao.AttendanceDAO.Emp;
import com.lpms.dao.AttendanceDAO.Row;
import com.lpms.dao.AuditDAO;
import com.lpms.util.AttendancePolicy;
import com.lpms.util.AttendanceRules;
import com.lpms.util.AttendanceRules.Day;
import com.lpms.util.AttendanceRules.Leave;
import com.lpms.util.AttendanceRules.Summary;

import java.sql.SQLException;
import java.time.*;
import java.time.format.DateTimeParseException;
import java.util.*;

/**
 * Attendance rules, permissions and monthly summaries.
 * EMPLOYEE: self check-in/out and own history. MANAGER: record/correct direct reports, view team.
 * HR_ADMIN: record anyone, import, holidays, policy, month locks.
 */
public class AttendanceService {
    public static final Set<String> MANUAL_STATUSES = Set.of("PRESENT", "ABSENT", "HALF_DAY");
    public static final int MAX_IMPORT_ROWS = 1000;

    private final AttendanceDAO dao = new AttendanceDAO();
    private final AuditDAO audit = new AuditDAO();

    // ---------- permissions ----------

    public static boolean canView(long me, String role, Emp target) {
        return target.id() == me || "HR_ADMIN".equals(role) || ("MANAGER".equals(role) && Objects.equals(target.managerId(), me));
    }

    /** HR may record anyone; a manager only direct reports (never themselves). */
    public static boolean canRecord(long me, String role, Emp target) {
        if ("HR_ADMIN".equals(role)) return true;
        return "MANAGER".equals(role) && target.id() != me && Objects.equals(target.managerId(), me);
    }

    public Emp requireViewable(long me, String role, long empId) throws SQLException, AttendanceException {
        Emp e = dao.employeeById(empId);
        if (e == null) throw new AttendanceException(404, "Employee not found.");
        if (!canView(me, role, e)) throw new AttendanceException(403, "You are not allowed to view this employee's attendance.");
        return e;
    }

    // ---------- parsing helpers ----------

    public static YearMonth parseMonth(String s, LocalDate today) throws AttendanceException {
        if (s == null || s.isBlank()) return YearMonth.from(today);
        try {
            YearMonth m = YearMonth.parse(s.trim());
            if (m.getYear() < 2000 || m.isAfter(YearMonth.from(today))) throw new AttendanceException(400, "Month must be between 2000-01 and the current month.");
            return m;
        } catch (DateTimeParseException e) {
            throw new AttendanceException(400, "Month must be in yyyy-MM format.");
        }
    }

    private static LocalDateTime time(LocalDate d, String hhmm, String label) throws AttendanceException {
        if (hhmm == null) return null;
        try { return d.atTime(LocalTime.parse(hhmm)); }
        catch (DateTimeParseException e) { throw new AttendanceException(400, label + " must be HH:mm."); }
    }

    // ---------- recording ----------

    /** Shared validation for manual entries and imports. Throws on the first violated rule. */
    private void validateEntry(long me, String role, Emp t, LocalDate date, String status, LocalDateTime in, LocalDateTime out,
                               String remarks, LocalDate today, AttendancePolicy policy, boolean checkBackdate) throws SQLException, AttendanceException {
        if (t == null) throw new AttendanceException(404, "Employee not found.");
        if (!t.active()) throw new AttendanceException(409, "Employee account is inactive.");
        if (!canRecord(me, role, t)) throw new AttendanceException(403, "You are not allowed to record attendance for this employee.");
        if (date == null) throw new AttendanceException(400, "A valid date (yyyy-MM-dd) is required.");
        if (status == null || !MANUAL_STATUSES.contains(status)) throw new AttendanceException(400, "Status must be PRESENT, ABSENT or HALF_DAY.");
        if (date.isAfter(today)) throw new AttendanceException(400, "Attendance cannot be recorded for a future date.");
        if (date.isBefore(t.joined())) throw new AttendanceException(400, "Date is before the employee's joining date.");
        if (t.exited() != null && date.isAfter(t.exited())) throw new AttendanceException(400, "Date is after the employee's exit date.");
        if (AttendanceRules.isWeekend(date) || !dao.holidaySet(date, date).isEmpty())
            throw new AttendanceException(400, "Attendance is only recorded on working days (not weekends or holidays).");
        if ("MANAGER".equals(role) && checkBackdate && date.isBefore(today.minusDays(policy.backdateLimitDays())))
            throw new AttendanceException(403, "Managers can only record attendance up to " + policy.backdateLimitDays() + " days back. Ask HR.");
        if (dao.isMonthLocked(YearMonth.from(date))) throw new AttendanceException(409, "This month is locked.");
        if ("ABSENT".equals(status) && (in != null || out != null)) throw new AttendanceException(400, "Check-in/out times cannot be set for an absent day.");
        if (in != null && out != null && out.isBefore(in)) throw new AttendanceException(400, "Check-out cannot be before check-in.");
        if (out != null && in == null) throw new AttendanceException(400, "Check-out requires a check-in time.");
        if (remarks != null && remarks.length() > 255) throw new AttendanceException(400, "Remarks cannot exceed 255 characters.");
        Leave lv = dao.approvedLeaves(YearMonth.from(date), t.id(), null, Set.of()).getOrDefault(t.id(), Map.of()).get(date);
        if (lv != null && lv.fraction().compareTo(java.math.BigDecimal.ONE) >= 0)
            throw new AttendanceException(409, "Employee is on approved " + lv.name() + " on this date; attendance is derived from leave.");
    }


    private long insertChecked(long me, Emp t, LocalDate date, String status, LocalDateTime in, LocalDateTime out, String remarks,
                               AttendancePolicy policy) throws SQLException, AttendanceException {
        int worked = AttendanceRules.workedMinutes(in, out);
        int ot = AttendanceRules.overtimeMinutes(worked, policy.standardMinutes());
        try {
            long id = dao.insert(t.id(), date, status, in, out, worked, ot, remarks);
            audit.log("attendance", id, "INSERT", me, null, "{\"employeeId\":" + t.id() + ",\"date\":\"" + date + "\",\"status\":\"" + status + "\"}");
            return id;
        } catch (SQLException e) {
            if (e.getErrorCode() == 1062) throw new AttendanceException(409, "Attendance already exists for " + t.code() + " on " + date + ".");
            throw e;
        }
    }

    public long record(long me, String role, long empId, LocalDate date, String status, String inStr, String outStr, String remarks)
            throws SQLException, AttendanceException {
        LocalDate today = LocalDate.now();
        Emp t = dao.employeeById(empId);
        AttendancePolicy policy = AttendancePolicy.of(dao.policyValues());
        LocalDateTime in = date == null ? null : time(date, inStr, "Check-in"), out = date == null ? null : time(date, outStr, "Check-out");
        validateEntry(me, role, t, date, status, in, out, remarks, today, policy, true);
        return insertChecked(me, t, date, status, in, out, remarks, policy);
    }

    public void update(long me, String role, long attendanceId, String status, String inStr, String outStr, String remarks)
            throws SQLException, AttendanceException {
        Row r = dao.findById(attendanceId);
        if (r == null) throw new AttendanceException(404, "Attendance record not found.");
        if (r.locked()) throw new AttendanceException(409, "This record is locked.");
        Emp t = dao.employeeById(r.employeeId());
        AttendancePolicy policy = AttendancePolicy.of(dao.policyValues());
        LocalDateTime in = time(r.date(), inStr, "Check-in"), out = time(r.date(), outStr, "Check-out");
        validateEntry(me, role, t, r.date(), status, in, out, remarks, LocalDate.now(), policy, true);
        int worked = AttendanceRules.workedMinutes(in, out);
        if (!dao.update(attendanceId, status, in, out, worked, AttendanceRules.overtimeMinutes(worked, policy.standardMinutes()), remarks))
            throw new AttendanceException(409, "Record could not be updated (locked or removed).");
        audit.log("attendance", attendanceId, "UPDATE", me, "{\"status\":\"" + r.status() + "\"}", "{\"status\":\"" + status + "\"}");
    }

    /** Self-service check-in for today. */
    public void checkIn(long me) throws SQLException, AttendanceException {
        LocalDate today = LocalDate.now();
        Emp t = dao.employeeById(me);
        if (t == null || !t.active()) throw new AttendanceException(403, "Account is not active.");
        if (AttendanceRules.isWeekend(today) || !dao.holidaySet(today, today).isEmpty()) throw new AttendanceException(400, "Today is not a working day.");
        if (dao.isMonthLocked(YearMonth.from(today))) throw new AttendanceException(409, "This month is locked.");
        Leave lv = dao.approvedLeaves(YearMonth.from(today), me, null, Set.of()).getOrDefault(me, Map.of()).get(today);
        if (lv != null && lv.fraction().compareTo(java.math.BigDecimal.ONE) >= 0) throw new AttendanceException(409, "You are on approved leave today.");
        insertChecked(me, t, today, "PRESENT", LocalDateTime.now().withSecond(0).withNano(0), null, null, AttendancePolicy.of(dao.policyValues()));
    }

    /** Self-service check-out for today's record. */
    public void checkOut(long me) throws SQLException, AttendanceException {
        LocalDate today = LocalDate.now();
        Row r = dao.findByEmployeeDate(me, today);
        if (r == null || r.checkIn() == null) throw new AttendanceException(409, "Check in first.");
        if (r.locked()) throw new AttendanceException(409, "This record is locked.");
        if (r.checkOut() != null) throw new AttendanceException(409, "You have already checked out today.");
        LocalDateTime out = LocalDateTime.now().withSecond(0).withNano(0);
        if (out.isBefore(r.checkIn())) out = r.checkIn();
        AttendancePolicy policy = AttendancePolicy.of(dao.policyValues());
        int worked = AttendanceRules.workedMinutes(r.checkIn(), out);
        dao.update(r.id(), r.status(), r.checkIn(), out, worked, AttendanceRules.overtimeMinutes(worked, policy.standardMinutes()), r.remarks());
        audit.log("attendance", r.id(), "UPDATE", me, null, "{\"checkOut\":\"" + out + "\"}");
    }

    /** HR bulk import. Each row: employeeCode, date, status, checkIn?, checkOut?, remarks?. Returns counts and per-row errors. */
    public JsonObject importRows(long me, String role, JsonArray rows) throws SQLException, AttendanceException {
        if (!"HR_ADMIN".equals(role)) throw new AttendanceException(403, "Only HR can import attendance.");
        if (rows.size() == 0) throw new AttendanceException(400, "No rows to import.");
        if (rows.size() > MAX_IMPORT_ROWS) throw new AttendanceException(400, "Import is limited to " + MAX_IMPORT_ROWS + " rows.");
        AttendancePolicy policy = AttendancePolicy.of(dao.policyValues());
        LocalDate today = LocalDate.now();
        Map<String, Emp> empCache = new HashMap<>();
        Set<String> seen = new HashSet<>();
        JsonArray errors = new JsonArray();
        int imported = 0;
        for (int i = 0; i < rows.size(); i++) {
            int line = i + 1;
            try {
                if (!rows.get(i).isJsonObject()) throw new AttendanceException(400, "Row is not an object.");
                JsonObject o = rows.get(i).getAsJsonObject();
                String code = str(o, "employeeCode");
                String status = str(o, "status");
                if (code == null) throw new AttendanceException(400, "employeeCode is required.");
                LocalDate date;
                try { date = LocalDate.parse(str(o, "date")); } catch (DateTimeParseException | NullPointerException e) { throw new AttendanceException(400, "date must be yyyy-MM-dd."); }
                if (!seen.add(code + "|" + date)) throw new AttendanceException(409, "Duplicate row for " + code + " on " + date + " in this file.");
                Emp t = empCache.containsKey(code) ? empCache.get(code) : dao.employeeByCode(code);
                empCache.put(code, t);
                LocalDateTime in = time(date, str(o, "checkIn"), "Check-in"), out = time(date, str(o, "checkOut"), "Check-out");
                String remarks = str(o, "remarks");
                validateEntry(me, role, t, date, status == null ? null : status.toUpperCase(), in, out, remarks, today, policy, false);
                insertChecked(me, t, date, status.toUpperCase(), in, out, remarks, policy);
                imported++;
            } catch (AttendanceException e) {
                JsonObject er = new JsonObject();
                er.addProperty("row", line);
                er.addProperty("error", e.getMessage());
                errors.add(er);
            }
        }
        JsonObject res = new JsonObject();
        res.addProperty("imported", imported);
        res.addProperty("failed", errors.size());
        res.add("errors", errors);
        audit.log("attendance", 0L, "INSERT", me, null, "{\"import\":" + imported + ",\"failed\":" + errors.size() + "}");
        return res;
    }

    private static String str(JsonObject o, String k) {
        if (!o.has(k) || !o.get(k).isJsonPrimitive()) return null;
        String v = o.get(k).getAsString().trim();
        return v.isEmpty() ? null : v;
    }

    // ---------- admin: policy, holidays, locks ----------

    public void savePolicy(long me, String role, Map<String, String> changes) throws SQLException, AttendanceException {
        if (!"HR_ADMIN".equals(role)) throw new AttendanceException(403, "Only HR can change the attendance policy.");
        for (Map.Entry<String, String> e : changes.entrySet()) {
            String err = AttendancePolicy.validate(e.getKey(), e.getValue());
            if (err != null) throw new AttendanceException(400, err);
        }
        for (Map.Entry<String, String> e : changes.entrySet()) dao.savePolicy(e.getKey(), e.getValue().trim(), me);
    }

    public void lockMonth(long me, String role, YearMonth m, boolean lock) throws SQLException, AttendanceException {
        if (!"HR_ADMIN".equals(role)) throw new AttendanceException(403, "Only HR can lock or unlock a month.");
        dao.setMonthLocked(m, lock, me);
        audit.log("attendance", (long) (m.getYear() * 100 + m.getMonthValue()), "UPDATE", me, null, "{\"month\":\"" + m + "\",\"locked\":" + lock + "}");
    }

    public void addHoliday(long me, String role, LocalDate d, String name) throws SQLException, AttendanceException {
        if (!"HR_ADMIN".equals(role)) throw new AttendanceException(403, "Only HR can manage holidays.");
        if (d == null || name == null || name.length() > 100) throw new AttendanceException(400, "A valid date and a name (max 100 characters) are required.");
        if (dao.isMonthLocked(YearMonth.from(d))) throw new AttendanceException(409, "That month is locked.");
        if (!dao.addHoliday(d, name, me)) throw new AttendanceException(409, "A holiday already exists on " + d + ".");
    }

    public void deleteHoliday(long me, String role, long id) throws SQLException, AttendanceException {
        if (!"HR_ADMIN".equals(role)) throw new AttendanceException(403, "Only HR can manage holidays.");
        if (!dao.deleteHoliday(id)) throw new AttendanceException(404, "Holiday not found.");
    }

    // ---------- summaries & history ----------

    private static String ts(LocalDateTime t) { return t == null ? null : t.toLocalTime().toString(); }

    /** Monthly summaries for the given scope (employeeId and/or managerId; both null = everyone). */
    public JsonArray summaries(YearMonth m, Long employeeId, Long managerId, boolean withDays) throws SQLException {
        LocalDate today = LocalDate.now();
        AttendancePolicy policy = AttendancePolicy.of(dao.policyValues());
        Set<LocalDate> holidays = dao.holidaySet(m.atDay(1), m.atEndOfMonth());
        List<Emp> emps = dao.employeesForMonth(m, employeeId, managerId);
        Map<Long, Map<LocalDate, Row>> rows = dao.rowsForMonth(m, employeeId, managerId);
        Map<Long, Map<LocalDate, Leave>> leaves = dao.approvedLeaves(m, employeeId, managerId, holidays);
        Map<Long, AttendanceDAO.Agg> agg = dao.aggregate(m, employeeId, managerId);
        boolean locked = dao.isMonthLocked(m);
        JsonArray out = new JsonArray();
        for (Emp e : emps) {
            Map<LocalDate, Row> er = rows.getOrDefault(e.id(), Map.of());
            Map<LocalDate, AttendanceRules.Rec> recs = new HashMap<>();
            er.forEach((d, r) -> recs.put(d, new AttendanceRules.Rec(r.status(), r.checkIn() == null ? null : r.checkIn().toLocalTime())));
            Map<LocalDate, Leave> el = leaves.getOrDefault(e.id(), Map.of());
            Summary s = AttendanceRules.summarize(m, e.joined(), e.exited(), today, holidays, recs, el, policy);
            AttendanceDAO.Agg a = agg.getOrDefault(e.id(), new AttendanceDAO.Agg(0, 0, 0, 0, 0));
            JsonObject o = new JsonObject();
            o.addProperty("employeeId", e.id());
            o.addProperty("employeeCode", e.code());
            o.addProperty("employeeName", e.name());
            o.addProperty("month", m.toString());
            o.addProperty("workingDays", s.workingDays);
            o.addProperty("presentDays", s.presentDays);
            o.addProperty("absentDays", s.absentDays);
            o.addProperty("paidLeaveDays", s.paidLeaveDays);
            o.addProperty("unpaidLeaveDays", s.unpaidLeaveDays);
            o.addProperty("approvedLeaveDays", s.approvedLeaveDays());
            o.addProperty("lopDays", s.lopDays);
            o.addProperty("lateLopDays", s.lateLopDays);
            o.addProperty("payableDays", s.payableDays());
            o.addProperty("holidays", s.holidays);
            o.addProperty("lateMarks", s.lateMarks);
            o.addProperty("unrecordedDays", s.unrecordedDays);
            o.addProperty("pendingDays", s.pendingDays);
            o.addProperty("conflictDays", s.conflictDays);
            o.addProperty("recordedPresent", a.present());
            o.addProperty("recordedHalfDay", a.half());
            o.addProperty("recordedAbsent", a.absent());
            o.addProperty("workedMinutes", a.worked());
            o.addProperty("overtimeMinutes", a.overtime());
            o.addProperty("locked", locked);
            if (withDays) {
                JsonArray days = new JsonArray();
                for (Day d : s.days) {
                    JsonObject j = new JsonObject();
                    j.addProperty("date", d.date.toString());
                    j.addProperty("weekday", d.date.getDayOfWeek().toString().substring(0, 3));
                    j.addProperty("effective", d.effective);
                    j.addProperty("lop", d.lop);
                    j.addProperty("late", d.late);
                    j.addProperty("conflict", d.conflict);
                    Row r = er.get(d.date);
                    if (r != null) {
                        j.addProperty("attendanceId", r.id());
                        j.addProperty("recordedStatus", r.status());
                        j.addProperty("checkIn", ts(r.checkIn()));
                        j.addProperty("checkOut", ts(r.checkOut()));
                        j.addProperty("workedMinutes", r.workedMinutes());
                        j.addProperty("overtimeMinutes", r.overtimeMinutes());
                        j.addProperty("remarks", r.remarks());
                        j.addProperty("recordLocked", r.locked());
                    }
                    Leave l = el.get(d.date);
                    if (l != null) j.addProperty("leave", l.name() + (l.paid() ? "" : " (unpaid)") + (l.fraction().compareTo(java.math.BigDecimal.ONE) < 0 ? " - half day" : ""));
                    if (holidays.contains(d.date)) j.addProperty("leave", "Holiday");
                    days.add(j);
                }
                o.add("days", days);
            }
            out.add(o);
        }
        return out;
    }

    public JsonObject policyJson() throws SQLException {
        JsonObject o = new JsonObject();
        AttendancePolicy.of(dao.policyValues()).asMap().forEach(o::addProperty);
        return o;
    }

    public JsonArray holidays(int year) throws SQLException { return dao.holidays(year); }
    public boolean monthLocked(YearMonth m) throws SQLException { return dao.isMonthLocked(m); }
    public Emp employeeByCode(String code) throws SQLException { return dao.employeeByCode(code); }
}
