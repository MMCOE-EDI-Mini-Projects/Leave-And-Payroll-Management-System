package com.lpms.service;

import com.lpms.dao.EmployeeDAO;
import com.lpms.model.Employee;
import com.lpms.util.PasswordPolicy;
import org.mindrot.jbcrypt.BCrypt;

public class AuthService {

    private static final int BCRYPT_COST = 12;
    // Used to burn equal CPU time when a username does not exist (limits user enumeration by timing).
    private static final String DUMMY_HASH = BCrypt.hashpw("lpms-dummy-password", BCrypt.gensalt(BCRYPT_COST));

    private final EmployeeDAO employeeDAO;

    public AuthService() {
        this.employeeDAO = new EmployeeDAO();
    }

    /** @return the Employee if credentials are valid and the account is active, otherwise null. */
    public Employee authenticate(String username, String plainPassword) {
        Employee employee = (username == null) ? null : employeeDAO.findByUsername(username);
        String hash = (employee != null && employee.isActive()) ? employee.getPasswordHash() : DUMMY_HASH;
        boolean ok = verify(plainPassword, hash);
        return (ok && employee != null && employee.isActive()) ? employee : null;
    }

    public boolean verify(String plainPassword, String hash) {
        if (plainPassword == null || hash == null) return false;
        try {
            return BCrypt.checkpw(plainPassword, hash);
        } catch (IllegalArgumentException e) { // malformed hash
            return false;
        }
    }

    public String hashPassword(String plainPassword) {
        return BCrypt.hashpw(plainPassword, BCrypt.gensalt(BCRYPT_COST));
    }

    /** @return null on success, otherwise an error message. */
    public String changePassword(Long employeeId, String currentPassword, String newPassword) {
        Employee e = employeeDAO.findById(employeeId);
        if (e == null || !e.isActive() || !verify(currentPassword, e.getPasswordHash())) {
            return "Current password is incorrect.";
        }
        String policy = PasswordPolicy.validate(newPassword);
        if (policy != null) return policy;
        if (newPassword.equals(currentPassword)) return "New password must differ from the current password.";
        return employeeDAO.updatePasswordHash(employeeId, hashPassword(newPassword))
                ? null : "Failed to update password.";
    }

    /** Fingerprint stored in the session; changes whenever the password changes (invalidates other sessions). */
    public static String stamp(String passwordHash) {
        return passwordHash == null ? "" : Integer.toHexString(passwordHash.hashCode());
    }
}
