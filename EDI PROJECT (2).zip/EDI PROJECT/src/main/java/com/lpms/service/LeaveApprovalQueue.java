package com.lpms.service;

import com.google.gson.JsonObject;
import com.lpms.model.LeaveApplication;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Queue;

/**
 * Foundational Course Data Structures Implementation:
 * Queue and Deque for FIFO processing and batch review of Leave Approvals.
 * 
 * Uses java.util.ArrayDeque implementing both Queue<T> and Deque<T> interfaces.
 * 
 * Actual Application Purpose:
 * When a manager reviews leave requests, they are served in strict First-In-First-Out (FIFO)
 * order based on submission timestamp. The Deque interface also supports pushing an item
 * back to the head of the queue if the manager needs to revisit an application during review.
 * 
 * Operations:
 * - enqueue(app): O(1) time, adds to back of queue.
 * - peekNext(): O(1) time, inspects head of queue.
 * - pollNext(): O(1) time, retrieves and removes head of queue.
 * - requeueAtHead(app): O(1) time, Deque operation for deferred review.
 */
public class LeaveApprovalQueue {

    private final Deque<JsonObject> queue = new ArrayDeque<>();

    public LeaveApprovalQueue() {}

    public LeaveApprovalQueue(List<JsonObject> pendingList) {
        if (pendingList != null) {
            for (JsonObject obj : pendingList) {
                queue.offerLast(obj);
            }
        }
    }

    /**
     * Enqueues a pending leave application at the tail of the approval queue.
     * Time Complexity: O(1)
     */
    public synchronized void enqueue(JsonObject application) {
        if (application != null) {
            queue.offerLast(application);
        }
    }

    /**
     * Peeks at the next pending application without removing it.
     * Time Complexity: O(1)
     */
    public synchronized JsonObject peekNext() {
        return queue.peekFirst();
    }

    /**
     * Polls the next pending application for review.
     * Time Complexity: O(1)
     */
    public synchronized JsonObject pollNext() {
        return queue.pollFirst();
    }

    /**
     * Deque operation: pushes an application back to the head of the queue (e.g. if skipped or deferred).
     * Time Complexity: O(1)
     */
    public synchronized void requeueAtHead(JsonObject application) {
        if (application != null) {
            queue.offerFirst(application);
        }
    }

    /**
     * Returns all currently queued applications as a List in FIFO order.
     */
    public synchronized List<JsonObject> asList() {
        return new ArrayList<>(queue);
    }

    public synchronized int size() {
        return queue.size();
    }

    public synchronized boolean isEmpty() {
        return queue.isEmpty();
    }

    public synchronized void clear() {
        queue.clear();
    }

    /**
     * Batch processes the queue using FIFO order.
     * Approves all applications sequentially in the queue.
     * 
     * @return List of processed application IDs and their decision status
     */
    public synchronized List<JsonObject> processBatch(long approverId, String approverRole, String action, String comments, LeaveService leaveService) {
        List<JsonObject> results = new ArrayList<>();
        boolean isApprove = "APPROVE".equalsIgnoreCase(action);
        while (!queue.isEmpty()) {
            JsonObject item = queue.pollFirst();
            long appId = item.has("leaveApplicationId") ? item.get("leaveApplicationId").getAsLong() : -1L;
            if (appId <= 0) continue;

            JsonObject res = new JsonObject();
            res.addProperty("leaveApplicationId", appId);
            try {
                leaveService.decide(appId, approverId, approverRole, isApprove, comments);
                res.addProperty("status", "SUCCESS");
                res.addProperty("action", isApprove ? "APPROVED" : "REJECTED");
            } catch (LeaveException e) {
                res.addProperty("status", "FAILED");
                res.addProperty("error", e.getMessage());
            }
            results.add(res);
        }
        return results;
    }
}
