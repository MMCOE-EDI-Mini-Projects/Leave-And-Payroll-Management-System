package com.lpms.service;

/** Business-rule failure carrying the HTTP status the servlet should return. */
public class LeaveException extends Exception {
    private final int status;

    public LeaveException(int status, String message) {
        super(message);
        this.status = status;
    }

    public int getStatus() { return status; }
}
