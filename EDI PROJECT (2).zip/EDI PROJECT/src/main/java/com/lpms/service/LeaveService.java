package com.lpms.service;

import com.lpms.dao.AuditDAO;
import com.lpms.dao.LeaveBalanceDAO;
import com.lpms.util.DBUtil;
import com.lpms.util.LeaveRules;

import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;

/**
 * Leave workflow. Every state change (application + balance + history) runs in ONE database transaction.
 * Rows are locked (SELECT ... FOR UPDATE) so concurrent requests cannot overlap or overdraw a balance.
 * Balance rules: only paid leave types are tracked; used days are deducted on approval, and
 * pending days are reserved when applying (available = remaining - pending).
 */
public class LeaveService {

    private interface Work<T> { T run(Connection c) throws SQLException, LeaveException; }

    private final AuditDAO audit = new AuditDAO();

    private <T> T inTx(Work<T> work) throws LeaveException {
        Connection c = null;
        try {
            c = DBUtil.getConnection();
            c.setAutoCommit(false);
            T r = work.run(c);
            c.commit();
            return r;
        } catch (LeaveException e) {
            rollback(c);
            throw e;
        } catch (SQLException e) {
            rollback(c);
            e.printStackTrace();
            throw new LeaveException(500, "Database error while processing the leave request.");
        } catch (RuntimeException e) {
            rollback(c);
            throw e;
        } finally {
            if (c != null) {
                try { c.setAutoCommit(true); } catch (SQLException ignored) { }
                DBUtil.closeConnection(c);
            }
        }
    }

    private static void rollback(Connection c) {
        if (c != null) try { c.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
    }

    private static void addHistory(Connection c, long appId, String action, long by, String comments) throws SQLException {
        try (PreparedStatement st = c.prepareStatement(
                "INSERT INTO leave_history (leave_application_id, action, performed_by, comments) VALUES (?, ?, ?, ?)")) {
            st.setLong(1, appId);
            st.setString(2, action);
            st.setLong(3, by);
            if (comments == null || comments.isEmpty()) st.setNull(4, Types.VARCHAR); else st.setString(4, comments);
            st.executeUpdate();
        }
    }

    /** Locks the balance row; returns {remaining, pending}. */
    private static BigDecimal[] lockBalance(Connection c, long emp, long type, int year) throws SQLException, LeaveException {
        LeaveBalanceDAO.ensure(c, emp, year);
        BigDecimal remaining;
        try (PreparedStatement st = c.prepareStatement(
                "SELECT closing_balance FROM leave_balance WHERE employee_id = ? AND leave_type_id = ? AND leave_year = ? FOR UPDATE")) {
            st.setLong(1, emp); st.setLong(2, type); st.setInt(3, year);
            try (ResultSet rs = st.executeQuery()) {
                if (!rs.next()) throw new LeaveException(409, "No leave balance is configured for this leave type.");
                remaining = rs.getBigDecimal(1);
            }
        }
        BigDecimal pending;
        try (PreparedStatement st = c.prepareStatement(
                "SELECT COALESCE(SUM(total_days), 0) FROM leave_application " +
                "WHERE employee_id = ? AND leave_type_id = ? AND status = 'PENDING' AND YEAR(start_date) = ?")) {
            st.setLong(1, emp); st.setLong(2, type); st.setInt(3, year);
            try (ResultSet rs = st.executeQuery()) { rs.next(); pending = rs.getBigDecimal(1); }
        }
        return new BigDecimal[]{remaining, pending};
    }

    /** Submits a PENDING application. Days are computed server-side. Returns the new application id. */
    public long apply(long empId, long typeId, LocalDate start, LocalDate end, boolean halfDay, String reason) throws LeaveException {
        LocalDate today = LocalDate.now();
        String dateErr = LeaveRules.validateDates(start, end, today);
        if (dateErr != null) throw new LeaveException(400, dateErr);
        if (reason == null || reason.isBlank()) throw new LeaveException(400, "Reason is required.");
        if (reason.length() > 500) throw new LeaveException(400, "Reason must be 500 characters or fewer.");

        long id = inTx(c -> {
            LocalDate joined;
            // Serialises this employee's submissions so the overlap check below cannot race.
            try (PreparedStatement st = c.prepareStatement(
                    "SELECT date_of_joining FROM employee WHERE employee_id = ? AND is_active = TRUE FOR UPDATE")) {
                st.setLong(1, empId);
                try (ResultSet rs = st.executeQuery()) {
                    if (!rs.next()) throw new LeaveException(403, "Your account is not active.");
                    joined = rs.getDate(1).toLocalDate();
                }
            }
            boolean paid, allowsHalf;
            try (PreparedStatement st = c.prepareStatement(
                    "SELECT is_paid, allows_half_day FROM leave_type WHERE leave_type_id = ? AND is_active = TRUE")) {
                st.setLong(1, typeId);
                try (ResultSet rs = st.executeQuery()) {
                    if (!rs.next()) throw new LeaveException(400, "Unknown or inactive leave type.");
                    paid = rs.getBoolean(1);
                    allowsHalf = rs.getBoolean(2);
                }
            }
            if (halfDay && !allowsHalf) throw new LeaveException(400, "This leave type does not allow half days.");
            if (halfDay && !start.equals(end)) throw new LeaveException(400, "A half-day request must be for a single date.");
            if (start.isBefore(joined)) throw new LeaveException(400, "Leave cannot start before your date of joining.");

            BigDecimal days = LeaveRules.countDays(start, end, halfDay);
            if (days.signum() <= 0) throw new LeaveException(400, "The selected dates contain no working days (weekends are excluded).");

            try (PreparedStatement st = c.prepareStatement(
                    "SELECT leave_application_id FROM leave_application WHERE employee_id = ? " +
                    "AND status IN ('PENDING', 'APPROVED') AND start_date <= ? AND end_date >= ? LIMIT 1")) {
                st.setLong(1, empId);
                st.setDate(2, Date.valueOf(end));
                st.setDate(3, Date.valueOf(start));
                try (ResultSet rs = st.executeQuery()) {
                    if (rs.next()) throw new LeaveException(409,
                        "These dates overlap with an existing pending or approved leave request (#" + rs.getLong(1) + ").");
                }
            }

            if (paid) {
                BigDecimal[] b = lockBalance(c, empId, typeId, start.getYear());
                BigDecimal available = b[0].subtract(b[1]);
                if (available.compareTo(days) < 0) throw new LeaveException(409,
                    "Insufficient leave balance: " + available.stripTrailingZeros().toPlainString() + " day(s) available (after pending requests), "
                    + days.stripTrailingZeros().toPlainString() + " requested.");
            }

            long newId;
            try (PreparedStatement st = c.prepareStatement(
                    "INSERT INTO leave_application (employee_id, leave_type_id, start_date, end_date, total_days, reason, status) " +
                    "VALUES (?, ?, ?, ?, ?, ?, 'PENDING')", Statement.RETURN_GENERATED_KEYS)) {
                st.setLong(1, empId); st.setLong(2, typeId);
                st.setDate(3, Date.valueOf(start)); st.setDate(4, Date.valueOf(end));
                st.setBigDecimal(5, days); st.setString(6, reason.trim());
                st.executeUpdate();
                try (ResultSet rs = st.getGeneratedKeys()) { rs.next(); newId = rs.getLong(1); }
            }
            addHistory(c, newId, "SUBMITTED", empId, reason.trim());
            return newId;
        });
        audit.log("leave_application", id, "INSERT", empId, null,
                "{\"status\":\"PENDING\",\"startDate\":\"" + start + "\",\"endDate\":\"" + end + "\"}");
        return id;
    }

    /**
     * Approves or rejects a PENDING request. Authorization is re-checked inside the transaction:
     * approver must be MANAGER/HR_ADMIN, not the applicant, and (unless HR_ADMIN) the applicant's reporting manager.
     */
    public void decide(long appId, long approverId, String approverRole, boolean approve, String comments) throws LeaveException {
        if (!"MANAGER".equals(approverRole) && !"HR_ADMIN".equals(approverRole))
            throw new LeaveException(403, "Only managers or HR can approve or reject leave.");
        if (!approve && (comments == null || comments.isBlank()))
            throw new LeaveException(400, "A comment is required when rejecting a request.");
        if (comments != null && comments.length() > 500) throw new LeaveException(400, "Comments must be 500 characters or fewer.");

        inTx(c -> {
            long emp, type, mgr; LocalDate start; BigDecimal days; String status; boolean paid;
            try (PreparedStatement st = c.prepareStatement(
                    "SELECT la.employee_id, la.leave_type_id, la.start_date, la.total_days, la.status, " +
                    "e.reporting_manager_id, lt.is_paid FROM leave_application la " +
                    "JOIN employee e ON e.employee_id = la.employee_id " +
                    "JOIN leave_type lt ON lt.leave_type_id = la.leave_type_id " +
                    "WHERE la.leave_application_id = ? FOR UPDATE")) {
                st.setLong(1, appId);
                try (ResultSet rs = st.executeQuery()) {
                    if (!rs.next()) throw new LeaveException(404, "Leave application not found.");
                    emp = rs.getLong(1); type = rs.getLong(2); start = rs.getDate(3).toLocalDate();
                    days = rs.getBigDecimal(4); status = rs.getString(5);
                    mgr = rs.getLong(6); if (rs.wasNull()) mgr = 0;
                    paid = rs.getBoolean(7);
                }
            }
            if (emp == approverId) throw new LeaveException(403, "You cannot approve or reject your own leave.");
            if (!"HR_ADMIN".equals(approverRole) && mgr != approverId)
                throw new LeaveException(403, "You can only act on leave requests from your direct reports.");
            if (!"PENDING".equals(status)) throw new LeaveException(409, "Leave application is no longer pending.");

            if (approve && paid) {
                BigDecimal[] b = lockBalance(c, emp, type, start.getYear());
                if (b[0].compareTo(days) < 0) throw new LeaveException(409,
                    "Cannot approve: employee has only " + b[0].stripTrailingZeros().toPlainString() + " day(s) remaining.");
                try (PreparedStatement st = c.prepareStatement(
                        "UPDATE leave_balance SET used = used + ? WHERE employee_id = ? AND leave_type_id = ? AND leave_year = ?")) {
                    st.setBigDecimal(1, days); st.setLong(2, emp); st.setLong(3, type); st.setInt(4, start.getYear());
                    if (st.executeUpdate() != 1) throw new LeaveException(500, "Failed to update leave balance.");
                }
            }
            String newStatus = approve ? "APPROVED" : "REJECTED";
            String cm = comments == null ? null : comments.trim();
            try (PreparedStatement st = c.prepareStatement(
                    "UPDATE leave_application SET status = ?, approver_id = ?, actioned_at = CURRENT_TIMESTAMP, manager_comments = ? " +
                    "WHERE leave_application_id = ? AND status = 'PENDING'")) {
                st.setString(1, newStatus); st.setLong(2, approverId);
                if (cm == null || cm.isEmpty()) st.setNull(3, Types.VARCHAR); else st.setString(3, cm);
                st.setLong(4, appId);
                if (st.executeUpdate() != 1) throw new LeaveException(409, "Leave application is no longer pending.");
            }
            addHistory(c, appId, newStatus, approverId, cm);
            return null;
        });
        audit.log("leave_application", appId, "UPDATE", approverId, "{\"status\":\"PENDING\"}",
                "{\"status\":\"" + (approve ? "APPROVED" : "REJECTED") + "\"}");
    }

    /** Owner cancels: PENDING anytime; APPROVED only if it has not started (balance is restored). */
    public void cancel(long appId, long empId, String comments) throws LeaveException {
        String oldStatus = inTx(c -> {
            long emp, type; LocalDate start; BigDecimal days; String status; boolean paid;
            try (PreparedStatement st = c.prepareStatement(
                    "SELECT la.employee_id, la.leave_type_id, la.start_date, la.total_days, la.status, lt.is_paid " +
                    "FROM leave_application la JOIN leave_type lt ON lt.leave_type_id = la.leave_type_id " +
                    "WHERE la.leave_application_id = ? FOR UPDATE")) {
                st.setLong(1, appId);
                try (ResultSet rs = st.executeQuery()) {
                    if (!rs.next()) throw new LeaveException(404, "Leave application not found.");
                    emp = rs.getLong(1); type = rs.getLong(2); start = rs.getDate(3).toLocalDate();
                    days = rs.getBigDecimal(4); status = rs.getString(5); paid = rs.getBoolean(6);
                }
            }
            if (emp != empId) throw new LeaveException(403, "You can only cancel your own leave requests.");
            if ("APPROVED".equals(status)) {
                if (!start.isAfter(LocalDate.now()))
                    throw new LeaveException(409, "Approved leave that has already started cannot be cancelled. Contact HR.");
                if (paid) {
                    try (PreparedStatement st = c.prepareStatement(
                            "UPDATE leave_balance SET used = GREATEST(used - ?, 0) WHERE employee_id = ? AND leave_type_id = ? AND leave_year = ?")) {
                        st.setBigDecimal(1, days); st.setLong(2, emp); st.setLong(3, type); st.setInt(4, start.getYear());
                        if (st.executeUpdate() != 1) throw new LeaveException(500, "Failed to restore leave balance.");
                    }
                }
            } else if (!"PENDING".equals(status)) {
                throw new LeaveException(409, "Only pending or future approved leave can be cancelled.");
            }
            try (PreparedStatement st = c.prepareStatement(
                    "UPDATE leave_application SET status = 'CANCELLED' WHERE leave_application_id = ? AND status = ?")) {
                st.setLong(1, appId); st.setString(2, status);
                if (st.executeUpdate() != 1) throw new LeaveException(409, "Leave application changed; please refresh.");
            }
            addHistory(c, appId, "CANCELLED", empId, comments == null || comments.isBlank() ? null : comments.trim());
            return status;
        });
        audit.log("leave_application", appId, "UPDATE", empId, "{\"status\":\"" + oldStatus + "\"}", "{\"status\":\"CANCELLED\"}");
    }
}
