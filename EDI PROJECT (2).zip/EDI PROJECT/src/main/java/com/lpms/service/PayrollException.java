package com.lpms.service;

public class PayrollException extends Exception {
    private final int status;

    public PayrollException(int status, String message) {
        super(message);
        this.status = status;
    }

    public int getStatus() {
        return status;
    }
}
