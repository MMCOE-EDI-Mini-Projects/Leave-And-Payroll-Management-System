package com.lpms.service;

import com.lpms.model.EmployeeSalaryDetail;
import com.lpms.model.SalaryComponent;
import com.lpms.model.TaxSlab;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Strategy Pattern and Rule Engine for Salary & Tax Calculations.
 * 
 * Foundational Course Design Patterns & Data Structures:
 * - Strategy Pattern: encapsulates calculation algorithms (FLAT, PERCENTAGE, FORMULA).
 * - HashMap lookup: O(1) lookup of calculation strategy by component calculation method.
 * - BigDecimal: financial arithmetic with explicit scale (2) and RoundingMode.HALF_UP.
 */
public class PayrollRuleEngine {

    /** Strategy interface for component amount calculation. */
    public interface SalaryCalculationStrategy {
        BigDecimal calculate(SalaryComponent component, BigDecimal componentValue, BigDecimal monthlyGross, BigDecimal basicSalary);
    }

    /** Strategy for flat monetary amount. */
    public static class FlatCalculationStrategy implements SalaryCalculationStrategy {
        @Override
        public BigDecimal calculate(SalaryComponent component, BigDecimal componentValue, BigDecimal monthlyGross, BigDecimal basicSalary) {
            return componentValue != null ? componentValue.setScale(2, RoundingMode.HALF_UP) : BigDecimal.ZERO.setScale(2);
        }
    }

    /** Strategy for percentage-based components (HRA, PF, etc.). */
    public static class PercentageCalculationStrategy implements SalaryCalculationStrategy {
        @Override
        public BigDecimal calculate(SalaryComponent component, BigDecimal componentValue, BigDecimal monthlyGross, BigDecimal basicSalary) {
            if (componentValue == null || monthlyGross == null) {
                return BigDecimal.ZERO.setScale(2);
            }
            // For PF calculation, standard Indian payroll applies percentage to Basic Salary if available
            BigDecimal base = monthlyGross;
            if (component != null && component.getComponentCode() != null) {
                String code = component.getComponentCode().toUpperCase();
                if ((code.contains("PF") || component.isPfApplicable()) && basicSalary != null && basicSalary.compareTo(BigDecimal.ZERO) > 0) {
                    base = basicSalary;
                }
            }
            return base.multiply(componentValue)
                       .divide(new BigDecimal("100"), 2, RoundingMode.HALF_UP);
        }
    }

    /** Strategy for formula / dynamic components (Bonus, TDS, etc.). */
    public static class FormulaCalculationStrategy implements SalaryCalculationStrategy {
        @Override
        public BigDecimal calculate(SalaryComponent component, BigDecimal componentValue, BigDecimal monthlyGross, BigDecimal basicSalary) {
            if (component == null || monthlyGross == null) {
                return BigDecimal.ZERO.setScale(2);
            }
            String code = component.getComponentCode() != null ? component.getComponentCode().toUpperCase() : "";
            if ("BONUS".equals(code)) {
                // 5% bonus capped at 5000.00
                BigDecimal bonus = monthlyGross.multiply(new BigDecimal("0.05")).setScale(2, RoundingMode.HALF_UP);
                BigDecimal cap = new BigDecimal("5000.00");
                return bonus.compareTo(cap) > 0 ? cap : bonus;
            }
            if ("TDS".equals(code) && componentValue != null && componentValue.compareTo(BigDecimal.ZERO) > 0) {
                return componentValue.setScale(2, RoundingMode.HALF_UP);
            }
            return BigDecimal.ZERO.setScale(2);
        }
    }

    private final Map<String, SalaryCalculationStrategy> strategies = new HashMap<>();

    public PayrollRuleEngine() {
        strategies.put("FLAT", new FlatCalculationStrategy());
        strategies.put("PERCENTAGE", new PercentageCalculationStrategy());
        strategies.put("FORMULA", new FormulaCalculationStrategy());
    }

    /**
     * Backward-compatible component calculation method.
     */
    public BigDecimal calculateComponentAmount(SalaryComponent component, EmployeeSalaryDetail detail, BigDecimal monthlyGross) {
        return calculateComponentAmount(component, detail, monthlyGross, null);
    }

    /**
     * Calculates component amount with basic salary context.
     * Uses HashMap lookup in O(1) time to dispatch to the appropriate Strategy.
     */
    public BigDecimal calculateComponentAmount(SalaryComponent component, EmployeeSalaryDetail detail, BigDecimal monthlyGross, BigDecimal basicSalary) {
        if (component == null || detail == null || monthlyGross == null) {
            return BigDecimal.ZERO.setScale(2);
        }
        String method = component.getCalculationMethod() != null ? component.getCalculationMethod().toUpperCase() : "FLAT";
        SalaryCalculationStrategy strategy = strategies.getOrDefault(method, strategies.get("FLAT"));
        return strategy.calculate(component, detail.getComponentValue(), monthlyGross, basicSalary);
    }

    /**
     * Calculates Loss of Pay deduction.
     * Per-day deduction = (monthlyGross / workingDays) * lopDays.
     * Explicitly rounds half-up to 2 decimal places.
     */
    public BigDecimal calculateLopDeduction(BigDecimal monthlyGross, BigDecimal workingDays, BigDecimal lopDays) {
        if (monthlyGross == null || workingDays == null || lopDays == null) {
            return BigDecimal.ZERO.setScale(2);
        }
        if (workingDays.compareTo(BigDecimal.ZERO) <= 0 || lopDays.compareTo(BigDecimal.ZERO) <= 0) {
            return BigDecimal.ZERO.setScale(2);
        }
        BigDecimal perDaySalary = monthlyGross.divide(workingDays, 4, RoundingMode.HALF_UP);
        return perDaySalary.multiply(lopDays).setScale(2, RoundingMode.HALF_UP);
    }

    /**
     * Calculates overtime payment:
     * Overtime hourly rate = (monthlyGross / (workingDays * standardWorkHours)) * multiplier.
     */
    public BigDecimal calculateOvertimePay(BigDecimal monthlyGross, BigDecimal workingDays, int overtimeMinutes, BigDecimal multiplier) {
        if (monthlyGross == null || workingDays == null || workingDays.compareTo(BigDecimal.ZERO) <= 0 || overtimeMinutes <= 0) {
            return BigDecimal.ZERO.setScale(2);
        }
        if (multiplier == null || multiplier.compareTo(BigDecimal.ZERO) <= 0) {
            multiplier = new BigDecimal("1.50"); // Default 1.5x standard overtime multiplier
        }
        // Total standard hours in month = workingDays * 8 hours
        BigDecimal totalWorkingHours = workingDays.multiply(new BigDecimal("8.00"));
        BigDecimal hourlyRate = monthlyGross.divide(totalWorkingHours, 4, RoundingMode.HALF_UP);
        BigDecimal overtimeHours = new BigDecimal(overtimeMinutes).divide(new BigDecimal("60.00"), 4, RoundingMode.HALF_UP);
        return hourlyRate.multiply(overtimeHours).multiply(multiplier).setScale(2, RoundingMode.HALF_UP);
    }

    /**
     * Calculates progressive Annual Income Tax using tax slab configuration.
     * 
     * Slabs represent progressive tax brackets:
     * Lower Limit -> Upper Limit @ Tax Rate % + Cess Rate %.
     */
    public BigDecimal calculateAnnualTax(BigDecimal annualTaxableIncome, List<TaxSlab> slabs) {
        if (annualTaxableIncome == null || annualTaxableIncome.compareTo(BigDecimal.ZERO) <= 0 || slabs == null || slabs.isEmpty()) {
            return BigDecimal.ZERO.setScale(2);
        }

        BigDecimal totalTax = BigDecimal.ZERO;
        BigDecimal cessRate = new BigDecimal("4.00"); // Standard 4% health & education cess

        for (TaxSlab slab : slabs) {
            BigDecimal lower = slab.getLowerLimit();
            BigDecimal upper = slab.getUpperLimit();
            BigDecimal rate = slab.getTaxRate();
            if (slab.getCessRate() != null) cessRate = slab.getCessRate();

            if (annualTaxableIncome.compareTo(lower) <= 0) {
                continue;
            }

            BigDecimal taxableInSlab;
            if (upper == null || annualTaxableIncome.compareTo(upper) <= 0) {
                taxableInSlab = annualTaxableIncome.subtract(lower);
            } else {
                taxableInSlab = upper.subtract(lower);
            }

            if (taxableInSlab.compareTo(BigDecimal.ZERO) > 0 && rate.compareTo(BigDecimal.ZERO) > 0) {
                BigDecimal slabTax = taxableInSlab.multiply(rate).divide(new BigDecimal("100"), 4, RoundingMode.HALF_UP);
                totalTax = totalTax.add(slabTax);
            }

            if (upper != null && annualTaxableIncome.compareTo(upper) <= 0) {
                break;
            }
        }

        // Add Cess
        BigDecimal cess = totalTax.multiply(cessRate).divide(new BigDecimal("100"), 2, RoundingMode.HALF_UP);
        return totalTax.add(cess).setScale(2, RoundingMode.HALF_UP);
    }

    /**
     * Calculates monthly TDS by spreading annual tax across 12 months.
     */
    public BigDecimal calculateMonthlyTds(BigDecimal annualTaxableIncome, List<TaxSlab> slabs) {
        BigDecimal annualTax = calculateAnnualTax(annualTaxableIncome, slabs);
        if (annualTax.compareTo(BigDecimal.ZERO) <= 0) {
            return BigDecimal.ZERO.setScale(2);
        }
        return annualTax.divide(new BigDecimal("12"), 2, RoundingMode.HALF_UP);
    }

    /**
     * Calculates arrears for retrospective salary revision:
     * Arrears = (revisedMonthlyGross - previousMonthlyGross) * effectiveMonths.
     */
    public BigDecimal calculateArrears(BigDecimal revisedMonthlyGross, BigDecimal previousMonthlyGross, int effectiveMonths) {
        if (revisedMonthlyGross == null || previousMonthlyGross == null || effectiveMonths <= 0) {
            return BigDecimal.ZERO.setScale(2);
        }
        BigDecimal difference = revisedMonthlyGross.subtract(previousMonthlyGross);
        if (difference.compareTo(BigDecimal.ZERO) <= 0) {
            return BigDecimal.ZERO.setScale(2);
        }
        return difference.multiply(new BigDecimal(effectiveMonths)).setScale(2, RoundingMode.HALF_UP);
    }
}
