package com.lpms.service;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.lpms.dao.AuditDAO;
import com.lpms.dao.PayrollDAO;
import com.lpms.model.EmployeeSalary;
import com.lpms.model.EmployeeSalaryDetail;
import com.lpms.model.SalaryComponent;
import com.lpms.model.TaxSlab;
import com.lpms.util.DBUtil;
import com.lpms.util.SearchSortUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.*;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;

/**
 * Core Payroll Processing Service:
 * Handles transactional execution, salary computation, attendance and LOP integration,
 * duplicate payroll prevention, payslip generation, and sorting algorithms.
 * 
 * Every payroll run is fully ACID compliant:
 * Changes to payroll_run, employee_payroll, payroll_item, and attendance lock
 * are executed within a single transaction with automatic rollback on failure.
 */
public class PayrollService {

    private final PayrollDAO dao = new PayrollDAO();
    private final PayrollRuleEngine ruleEngine = new PayrollRuleEngine();
    private final AttendanceService attendanceService = new AttendanceService();
    private final AuditDAO auditDAO = new AuditDAO();

    /**
     * Executes transactional payroll processing for a given month and year.
     * 
     * @param year The payroll year (e.g. 2026)
     * @param month The payroll month (1-12)
     * @param processorId The employee ID of the HR_ADMIN running payroll
     * @return Summary object with processing counts and total payout
     */
    public JsonObject processPayroll(int year, int month, long processorId) throws PayrollException, SQLException {
        if (month < 1 || month > 12) {
            throw new PayrollException(400, "Invalid month: must be between 1 and 12.");
        }
        if (year < 2000 || year > 2100) {
            throw new PayrollException(400, "Invalid year: must be between 2000 and 2100.");
        }

        // 1. Check for existing payroll run and prevent duplicate processing
        JsonObject existingRun = dao.findPayrollRun(year, month);
        if (existingRun != null) {
            String status = existingRun.get("status").getAsString();
            if ("APPROVED".equalsIgnoreCase(status) || "PAID".equalsIgnoreCase(status)) {
                throw new PayrollException(409, "Payroll for " + year + "-" + String.format("%02d", month) + 
                                           " has already been " + status + " and cannot be modified.");
            }
        }

        YearMonth yearMonth = YearMonth.of(year, month);
        LocalDate monthStart = yearMonth.atDay(1);
        LocalDate monthEnd = yearMonth.atEndOfMonth();

        Connection conn = null;
        try {
            conn = DBUtil.getConnection();
            conn.setAutoCommit(false); // ACID Transaction Start

            long runId;
            if (existingRun != null) {
                runId = existingRun.get("payrollRunId").getAsLong();
                // Clean up previous draft calculation items
                try (PreparedStatement delSt = conn.prepareStatement(
                        "DELETE FROM employee_payroll WHERE payroll_run_id = ?")) {
                    delSt.setLong(1, runId);
                    delSt.executeUpdate();
                }
                // Update run record
                try (PreparedStatement updSt = conn.prepareStatement(
                        "UPDATE payroll_run SET status = 'PROCESSED', processed_by = ?, processed_at = CURRENT_TIMESTAMP WHERE payroll_run_id = ?")) {
                    updSt.setLong(1, processorId);
                    updSt.setLong(2, runId);
                    updSt.executeUpdate();
                }
            } else {
                // Insert new payroll run
                String insertRunSql = "INSERT INTO payroll_run (payroll_year, payroll_month, status, processed_by, processed_at) VALUES (?, ?, 'PROCESSED', ?, CURRENT_TIMESTAMP)";
                try (PreparedStatement insSt = conn.prepareStatement(insertRunSql, Statement.RETURN_GENERATED_KEYS)) {
                    insSt.setInt(1, year);
                    insSt.setInt(2, month);
                    insSt.setLong(3, processorId);
                    insSt.executeUpdate();
                    try (ResultSet rs = insSt.getGeneratedKeys()) {
                        if (!rs.next()) throw new PayrollException(500, "Failed to create payroll run record.");
                        runId = rs.getLong(1);
                    }
                }
            }

            // 2. Load salary components and tax slabs
            List<SalaryComponent> components = dao.getActiveSalaryComponents();
            List<TaxSlab> taxSlabs = dao.getTaxSlabs(null);

            // 3. Query all employees employed during this month
            String empSql = "SELECT employee_id, employee_code, first_name, last_name, date_of_joining, date_of_exit " +
                            "FROM employee WHERE date_of_joining <= ? AND (date_of_exit IS NULL OR date_of_exit >= ?) " +
                            "AND is_active = TRUE ORDER BY employee_id ASC";

            List<Long> employeeIds = new ArrayList<>();
            try (PreparedStatement empSt = conn.prepareStatement(empSql)) {
                empSt.setDate(1, java.sql.Date.valueOf(monthEnd));
                empSt.setDate(2, java.sql.Date.valueOf(monthStart));
                try (ResultSet rs = empSt.executeQuery()) {
                    while (rs.next()) {
                        employeeIds.add(rs.getLong("employee_id"));
                    }
                }
            }

            if (employeeIds.isEmpty()) {
                throw new PayrollException(400, "No active employees found for the payroll period " + year + "-" + month);
            }

            int processedCount = 0;
            BigDecimal totalGrossPayout = BigDecimal.ZERO;
            BigDecimal totalDeductionsPayout = BigDecimal.ZERO;
            BigDecimal totalNetPayout = BigDecimal.ZERO;

            // 4. Process each employee
            for (Long empId : employeeIds) {
                // A. Attendance Integration from Module 4
                BigDecimal workingDays = new BigDecimal("30.00");
                BigDecimal presentDays = new BigDecimal("30.00");
                BigDecimal paidLeaveDays = BigDecimal.ZERO;
                BigDecimal lopDays = BigDecimal.ZERO;

                try {
                    JsonArray attArr = attendanceService.summaries(yearMonth, empId, null, false);
                    if (attArr.size() > 0) {
                        JsonObject attObj = attArr.get(0).getAsJsonObject();
                        if (attObj.has("workingDays")) workingDays = attObj.get("workingDays").getAsBigDecimal();
                        if (attObj.has("presentDays")) presentDays = attObj.get("presentDays").getAsBigDecimal();
                        if (attObj.has("paidLeaveDays")) paidLeaveDays = attObj.get("paidLeaveDays").getAsBigDecimal();
                        if (attObj.has("lopDays")) lopDays = attObj.get("lopDays").getAsBigDecimal();
                    }
                } catch (Exception e) {
                    // Fall back to default working days if attendance summary unavailable
                    e.printStackTrace();
                }

                // B. Load or establish Employee Salary Structure
                BigDecimal monthlyGross = new BigDecimal("50000.00");
                BigDecimal basicSalary = new BigDecimal("25000.00");

                // Check employee_salary table
                String salSql = "SELECT employee_salary_id, annual_ctc, monthly_gross FROM employee_salary " +
                                "WHERE employee_id = ? AND is_active = TRUE LIMIT 1";
                Long empSalaryId = null;
                try (PreparedStatement salSt = conn.prepareStatement(salSql)) {
                    salSt.setLong(1, empId);
                    try (ResultSet rs = salSt.executeQuery()) {
                        if (rs.next()) {
                            empSalaryId = rs.getLong("employee_salary_id");
                            monthlyGross = rs.getBigDecimal("monthly_gross");
                        }
                    }
                }

                // Map of component details (Component ID -> value)
                Map<Long, BigDecimal> componentValues = new HashMap<>();
                if (empSalaryId != null) {
                    String detSql = "SELECT component_id, component_value FROM employee_salary_detail WHERE employee_salary_id = ?";
                    try (PreparedStatement detSt = conn.prepareStatement(detSql)) {
                        detSt.setLong(1, empSalaryId);
                        try (ResultSet rs = detSt.executeQuery()) {
                            while (rs.next()) {
                                componentValues.put(rs.getLong("component_id"), rs.getBigDecimal("component_value"));
                            }
                        }
                    }
                }

                // C. Calculate Earnings and Deductions
                Map<Long, BigDecimal> calculatedItems = new LinkedHashMap<>();
                BigDecimal totalEarnings = BigDecimal.ZERO;
                BigDecimal totalDeductions = BigDecimal.ZERO;

                // 1. Calculate Basic first
                for (SalaryComponent comp : components) {
                    if ("BASIC".equalsIgnoreCase(comp.getComponentCode())) {
                        BigDecimal val = componentValues.getOrDefault(comp.getComponentId(), new BigDecimal("50.00")); // 50% default
                        EmployeeSalaryDetail d = new EmployeeSalaryDetail();
                        d.setComponentValue(val);
                        basicSalary = ruleEngine.calculateComponentAmount(comp, d, monthlyGross);
                        calculatedItems.put(comp.getComponentId(), basicSalary);
                        totalEarnings = totalEarnings.add(basicSalary);
                        break;
                    }
                }

                // 2. Calculate remaining Earnings
                for (SalaryComponent comp : components) {
                    if ("BASIC".equalsIgnoreCase(comp.getComponentCode())) continue;
                    if ("EARNING".equalsIgnoreCase(comp.getComponentType())) {
                        BigDecimal val = componentValues.get(comp.getComponentId());
                        if (val == null) {
                            if ("HRA".equalsIgnoreCase(comp.getComponentCode())) val = new BigDecimal("40.00"); // 40% of basic
                            else if ("SPECIAL".equalsIgnoreCase(comp.getComponentCode())) val = new BigDecimal("5000.00");
                            else val = BigDecimal.ZERO;
                        }
                        EmployeeSalaryDetail d = new EmployeeSalaryDetail();
                        d.setComponentValue(val);
                        BigDecimal amt = ruleEngine.calculateComponentAmount(comp, d, monthlyGross, basicSalary);
                        calculatedItems.put(comp.getComponentId(), amt);
                        totalEarnings = totalEarnings.add(amt);
                    }
                }

                // 3. Calculate Deductions (PF, PT, TDS)
                for (SalaryComponent comp : components) {
                    if ("DEDUCTION".equalsIgnoreCase(comp.getComponentType())) {
                        BigDecimal val = componentValues.get(comp.getComponentId());
                        if (val == null) {
                            if ("PF_EMP".equalsIgnoreCase(comp.getComponentCode())) val = new BigDecimal("12.00"); // 12% PF
                            else if ("PROF_TAX".equalsIgnoreCase(comp.getComponentCode())) val = new BigDecimal("200.00");
                            else val = BigDecimal.ZERO;
                        }
                        EmployeeSalaryDetail d = new EmployeeSalaryDetail();
                        d.setComponentValue(val);
                        BigDecimal amt = ruleEngine.calculateComponentAmount(comp, d, monthlyGross, basicSalary);
                        calculatedItems.put(comp.getComponentId(), amt);
                        totalDeductions = totalDeductions.add(amt);
                    }
                }

                // 4. Calculate LOP Deduction
                BigDecimal lopDeduction = ruleEngine.calculateLopDeduction(monthlyGross, workingDays, lopDays);
                totalDeductions = totalDeductions.add(lopDeduction);

                // 5. Net Pay
                BigDecimal netPay = totalEarnings.subtract(totalDeductions);
                if (netPay.compareTo(BigDecimal.ZERO) < 0) netPay = BigDecimal.ZERO.setScale(2);

                // D. Insert into employee_payroll
                long empPayrollId;
                String insEmpPaySql = "INSERT INTO employee_payroll (payroll_run_id, employee_id, working_days, present_days, " +
                                      "paid_leave_days, lop_days, gross_earnings, lop_deduction, total_deductions, net_pay, payment_status) " +
                                      "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'UNPAID')";
                try (PreparedStatement insEpSt = conn.prepareStatement(insEmpPaySql, Statement.RETURN_GENERATED_KEYS)) {
                    insEpSt.setLong(1, runId);
                    insEpSt.setLong(2, empId);
                    insEpSt.setBigDecimal(3, workingDays);
                    insEpSt.setBigDecimal(4, presentDays);
                    insEpSt.setBigDecimal(5, paidLeaveDays);
                    insEpSt.setBigDecimal(6, lopDays);
                    insEpSt.setBigDecimal(7, totalEarnings);
                    insEpSt.setBigDecimal(8, lopDeduction);
                    insEpSt.setBigDecimal(9, totalDeductions);
                    insEpSt.setBigDecimal(10, netPay);
                    insEpSt.executeUpdate();
                    try (ResultSet rs = insEpSt.getGeneratedKeys()) {
                        if (!rs.next()) throw new PayrollException(500, "Failed to insert employee payroll record.");
                        empPayrollId = rs.getLong(1);
                    }
                }

                // E. Insert line items into payroll_item
                String insItemSql = "INSERT INTO payroll_item (employee_payroll_id, component_id, amount) VALUES (?, ?, ?)";
                try (PreparedStatement itemSt = conn.prepareStatement(insItemSql)) {
                    for (Map.Entry<Long, BigDecimal> entry : calculatedItems.entrySet()) {
                        itemSt.setLong(1, empPayrollId);
                        itemSt.setLong(2, entry.getKey());
                        itemSt.setBigDecimal(3, entry.getValue());
                        itemSt.addBatch();
                    }
                    itemSt.executeBatch();
                }

                processedCount++;
                totalGrossPayout = totalGrossPayout.add(totalEarnings);
                totalDeductionsPayout = totalDeductionsPayout.add(totalDeductions);
                totalNetPayout = totalNetPayout.add(netPay);
            }

            // 5. Lock attendance records for that month
            String lockAttSql = "UPDATE attendance SET is_locked = TRUE WHERE attendance_date BETWEEN ? AND ?";
            try (PreparedStatement lockSt = conn.prepareStatement(lockAttSql)) {
                lockSt.setDate(1, java.sql.Date.valueOf(monthStart));
                lockSt.setDate(2, java.sql.Date.valueOf(monthEnd));
                lockSt.executeUpdate();
            }

            // 6. Record Audit Log
            auditDAO.log("payroll_run", runId, "PROCESSED", processorId, null,
                         "{\"year\":" + year + ",\"month\":" + month + ",\"employees\":" + processedCount + ",\"netPay\":" + totalNetPayout + "}");

            conn.commit(); // Transaction Successfully Committed!

            JsonObject result = new JsonObject();
            result.addProperty("payrollRunId", runId);
            result.addProperty("year", year);
            result.addProperty("month", month);
            result.addProperty("status", "PROCESSED");
            result.addProperty("processedEmployees", processedCount);
            result.addProperty("totalGross", totalGrossPayout);
            result.addProperty("totalDeductions", totalDeductionsPayout);
            result.addProperty("totalNetPay", totalNetPayout);
            result.addProperty("message", "Payroll successfully processed for " + year + "-" + String.format("%02d", month));
            return result;

        } catch (SQLException | PayrollException e) {
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
            throw e;
        } finally {
            if (conn != null) {
                try { conn.setAutoCommit(true); } catch (SQLException ignored) {}
                DBUtil.closeConnection(conn);
            }
        }
    }

    /**
     * Lists all historical payroll runs.
     */
    public JsonArray getPayrollRuns() throws SQLException {
        return dao.findAllPayrollRuns();
    }

    /**
     * Updates payroll status (APPROVE or PAID).
     */
    public boolean updateStatus(long payrollRunId, String status, long approverId) throws SQLException, PayrollException {
        if (!"APPROVED".equalsIgnoreCase(status) && !"PAID".equalsIgnoreCase(status)) {
            throw new PayrollException(400, "Invalid status: must be APPROVED or PAID.");
        }
        boolean ok = dao.updatePayrollRunStatus(payrollRunId, status.toUpperCase(), approverId);
        if (ok) {
            auditDAO.log("payroll_run", payrollRunId, status.toUpperCase(), approverId, null, "{\"status\":\"" + status + "\"}");
        }
        return ok;
    }

    /**
     * Retrieves the monthly payroll register sorted using MergeSort.
     * Demonstrates real algorithmic application of MergeSort: O(N log N) time complexity.
     */
    public JsonArray getPayrollRegister(long payrollRunId, Long departmentId, String sortBy) throws SQLException {
        JsonArray raw = dao.findPayrollRegister(payrollRunId, departmentId);
        List<JsonObject> list = new ArrayList<>();
        for (JsonElement el : raw) {
            list.add(el.getAsJsonObject());
        }

        // Apply MergeSort based on user selection
        Comparator<JsonObject> comp;
        if ("netPayDesc".equalsIgnoreCase(sortBy)) {
            comp = (a, b) -> b.get("netPay").getAsBigDecimal().compareTo(a.get("netPay").getAsBigDecimal());
        } else if ("netPayAsc".equalsIgnoreCase(sortBy)) {
            comp = (a, b) -> a.get("netPay").getAsBigDecimal().compareTo(b.get("netPay").getAsBigDecimal());
        } else if ("name".equalsIgnoreCase(sortBy)) {
            comp = Comparator.comparing(a -> a.get("employeeName").getAsString().toLowerCase());
        } else if ("department".equalsIgnoreCase(sortBy)) {
            comp = Comparator.comparing(a -> a.get("departmentName").getAsString().toLowerCase());
        } else {
            // Default: sort by employeeCode
            comp = Comparator.comparing(a -> a.get("employeeCode").getAsString());
        }

        SearchSortUtil.mergeSort(list, comp);

        JsonArray sorted = new JsonArray();
        for (JsonObject o : list) {
            sorted.add(o);
        }
        return sorted;
    }

    /**
     * Retrieves an individual employee's detailed payslip for a given payroll run.
     */
    public JsonObject getPayslip(long payrollRunId, long employeeId) throws SQLException {
        return dao.findPayslip(payrollRunId, employeeId);
    }

    /**
     * Retrieves an individual employee's detailed payslip by employeePayrollId.
     */
    public JsonObject getPayslipById(long employeePayrollId) throws SQLException {
        return dao.findPayslipById(employeePayrollId);
    }

    /**
     * Retrieves all past payslips for an employee.
     */
    public JsonArray getMyPayslips(long employeeId) throws SQLException {
        return dao.findEmployeePayslips(employeeId);
    }
}
