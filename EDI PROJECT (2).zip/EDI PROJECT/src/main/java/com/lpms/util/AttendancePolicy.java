package com.lpms.util;

import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.LinkedHashMap;
import java.util.Map;

/** Configurable attendance/LOP rules (pure, no I/O). Values are stored as strings in attendance_policy. */
public final class AttendancePolicy {
    public static final String MISSING_DAY = "MISSING_DAY_TREATMENT";
    public static final String LATE_AFTER = "LATE_AFTER_TIME";
    public static final String LATES_PER_HALF = "LATES_PER_HALF_DAY_LOP";
    public static final String STD_MINUTES = "STANDARD_WORK_MINUTES";
    public static final String BACKDATE = "BACKDATE_LIMIT_DAYS";

    public static final Map<String, String> DEFAULTS = new LinkedHashMap<>();
    static {
        DEFAULTS.put(MISSING_DAY, "ABSENT");
        DEFAULTS.put(LATE_AFTER, "09:30");
        DEFAULTS.put(LATES_PER_HALF, "0");
        DEFAULTS.put(STD_MINUTES, "480");
        DEFAULTS.put(BACKDATE, "31");
    }

    private final Map<String, String> values = new LinkedHashMap<>(DEFAULTS);

    public AttendancePolicy() {}

    /** Builds a policy from stored values; unknown/invalid entries fall back to defaults. */
    public static AttendancePolicy of(Map<String, String> stored) {
        AttendancePolicy p = new AttendancePolicy();
        if (stored != null) stored.forEach((k, v) -> { if (validate(k, v) == null) p.values.put(k, v.trim()); });
        return p;
    }

    /** Returns an error message, or null when the key/value pair is acceptable. */
    public static String validate(String key, String value) {
        if (key == null || !DEFAULTS.containsKey(key)) return "Unknown policy key: " + key;
        if (value == null || value.isBlank()) return key + " is required.";
        String v = value.trim();
        try {
            switch (key) {
                case MISSING_DAY:
                    return (v.equals("ABSENT") || v.equals("IGNORE")) ? null : MISSING_DAY + " must be ABSENT or IGNORE.";
                case LATE_AFTER:
                    if (!v.matches("\\d{2}:\\d{2}")) return LATE_AFTER + " must be HH:mm.";
                    LocalTime.parse(v);
                    return null;
                case LATES_PER_HALF: { int n = Integer.parseInt(v); return n >= 0 && n <= 31 ? null : LATES_PER_HALF + " must be 0-31."; }
                case STD_MINUTES: { int n = Integer.parseInt(v); return n >= 60 && n <= 1440 ? null : STD_MINUTES + " must be 60-1440."; }
                default: { int n = Integer.parseInt(v); return n >= 0 && n <= 366 ? null : BACKDATE + " must be 0-366."; }
            }
        } catch (NumberFormatException | DateTimeParseException e) {
            return key + " has an invalid value.";
        }
    }

    public boolean missingDayIsAbsent() { return "ABSENT".equals(values.get(MISSING_DAY)); }
    public LocalTime lateAfter() { return LocalTime.parse(values.get(LATE_AFTER)); }
    public int latesPerHalfDay() { return Integer.parseInt(values.get(LATES_PER_HALF)); }
    public int standardMinutes() { return Integer.parseInt(values.get(STD_MINUTES)); }
    public int backdateLimitDays() { return Integer.parseInt(values.get(BACKDATE)); }
    public Map<String, String> asMap() { return new LinkedHashMap<>(values); }
}
