package com.lpms.util;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Pure monthly attendance / LOP calculation (no I/O) so it can be unit tested.
 *
 * Working week is Monday-Friday (same as LeaveRules); holidays are excluded. For each working day:
 *  - PRESENT record: 1 present day (wins over any leave on that date; flagged as a conflict).
 *  - HALF_DAY record: 0.5 present; the other half is approved leave if a leave covers it, otherwise LOP.
 *  - Approved leave (no present record): paid leave type -> paid leave; unpaid type -> LOP.
 *    Any uncovered remainder of the day (half-day leave) follows the ABSENT/missing rules below.
 *  - ABSENT record, or a past day with no record when MISSING_DAY_TREATMENT=ABSENT: absent + LOP.
 *  - Today with no record is pending (not yet LOP); future days are pending.
 *  - Optionally every N late marks = 0.5 day LOP (LATES_PER_HALF_DAY_LOP).
 * Days before joining or after exit are not counted.
 */
public final class AttendanceRules {
    private AttendanceRules() {}

    public static final BigDecimal HALF = new BigDecimal("0.5");

    /** One attendance record for a date (status: PRESENT/ABSENT/HALF_DAY/ON_LEAVE...). */
    public record Rec(String status, LocalTime checkIn) {}
    /** Approved leave on a date: fraction of the day (1 or 0.5) and whether the leave type is paid. */
    public record Leave(BigDecimal fraction, boolean paid, String name) {}

    public static final class Day {
        public final LocalDate date;
        public String effective;          // PRESENT, HALF_DAY, ABSENT, ON_LEAVE, UNPAID_LEAVE, HOLIDAY, WEEKEND, PENDING, NOT_EMPLOYED, UNRECORDED
        public BigDecimal lop = BigDecimal.ZERO;
        public boolean late, conflict;
        Day(LocalDate d) { date = d; }
    }

    public static final class Summary {
        public int workingDays, holidays, weekends, lateMarks, pendingDays, unrecordedDays, conflictDays;
        public BigDecimal presentDays = BigDecimal.ZERO, absentDays = BigDecimal.ZERO,
                paidLeaveDays = BigDecimal.ZERO, unpaidLeaveDays = BigDecimal.ZERO,
                lopDays = BigDecimal.ZERO, lateLopDays = BigDecimal.ZERO;
        public final List<Day> days = new ArrayList<>();
        public BigDecimal approvedLeaveDays() { return paidLeaveDays.add(unpaidLeaveDays); }
        /** Days payable = working days minus LOP (never negative). */
        public BigDecimal payableDays() { return BigDecimal.valueOf(workingDays).subtract(lopDays).max(BigDecimal.ZERO); }
    }

    public static boolean isWeekend(LocalDate d) {
        return d.getDayOfWeek() == DayOfWeek.SATURDAY || d.getDayOfWeek() == DayOfWeek.SUNDAY;
    }

    public static Summary summarize(YearMonth month, LocalDate joined, LocalDate exited, LocalDate today,
                                    Set<LocalDate> holidays, Map<LocalDate, Rec> records,
                                    Map<LocalDate, Leave> leaves, AttendancePolicy policy) {
        Summary s = new Summary();
        for (LocalDate d = month.atDay(1); !d.isAfter(month.atEndOfMonth()); d = d.plusDays(1)) {
            Day day = new Day(d);
            s.days.add(day);
            if (joined != null && d.isBefore(joined) || exited != null && d.isAfter(exited)) { day.effective = "NOT_EMPLOYED"; continue; }
            if (isWeekend(d)) { day.effective = "WEEKEND"; s.weekends++; continue; }
            if (holidays.contains(d)) { day.effective = "HOLIDAY"; s.holidays++; continue; }
            s.workingDays++;

            Rec r = records.get(d);
            String st = r == null ? null : r.status();
            Leave lv = leaves.get(d);
            BigDecimal leaveFrac = lv == null ? BigDecimal.ZERO : lv.fraction();
            boolean past = d.isBefore(today);

            if ("PRESENT".equals(st)) {
                s.presentDays = s.presentDays.add(BigDecimal.ONE);
                day.effective = "PRESENT";
                if (lv != null) { day.conflict = true; s.conflictDays++; }
                if (r.checkIn() != null && r.checkIn().isAfter(policy.lateAfter())) { day.late = true; s.lateMarks++; }
                continue;
            }
            BigDecimal covered = BigDecimal.ZERO; // part of the day already accounted for
            if ("HALF_DAY".equals(st)) {
                s.presentDays = s.presentDays.add(HALF);
                covered = HALF;
                day.effective = "HALF_DAY";
                if (r.checkIn() != null && r.checkIn().isAfter(policy.lateAfter())) { day.late = true; s.lateMarks++; }
            }
            BigDecimal lf = leaveFrac.min(BigDecimal.ONE.subtract(covered));
            if (lv != null && lf.signum() > 0) {
                if (lv.paid()) s.paidLeaveDays = s.paidLeaveDays.add(lf);
                else { s.unpaidLeaveDays = s.unpaidLeaveDays.add(lf); day.lop = day.lop.add(lf); }
                covered = covered.add(lf);
                if (day.effective == null) day.effective = lv.paid() ? "ON_LEAVE" : "UNPAID_LEAVE";
            }
            BigDecimal rest = BigDecimal.ONE.subtract(covered);
            if (rest.signum() > 0) {
                boolean explicitAbsent = "ABSENT".equals(st);
                if (explicitAbsent || (st == null || "ON_LEAVE".equals(st)) && past && policy.missingDayIsAbsent() || "HALF_DAY".equals(st)) {
                    s.absentDays = s.absentDays.add(rest);
                    day.lop = day.lop.add(rest);
                    if (day.effective == null) day.effective = "ABSENT";
                    if (!explicitAbsent && !"HALF_DAY".equals(st)) s.unrecordedDays++;
                } else if (day.effective == null) {
                    if (past) { day.effective = "UNRECORDED"; s.unrecordedDays++; } else { day.effective = "PENDING"; s.pendingDays++; }
                }
            }
        }
        for (Day d : s.days) s.lopDays = s.lopDays.add(d.lop);
        int n = policy.latesPerHalfDay();
        if (n > 0) {
            BigDecimal extra = HALF.multiply(BigDecimal.valueOf(s.lateMarks / n));
            BigDecimal room = BigDecimal.valueOf(s.workingDays).subtract(s.lopDays).max(BigDecimal.ZERO);
            s.lateLopDays = extra.min(room);
            s.lopDays = s.lopDays.add(s.lateLopDays);
        }
        return s;
    }

    /** Minutes between check-in and check-out; 0 when either is missing or out is before in. */
    public static int workedMinutes(java.time.LocalDateTime in, java.time.LocalDateTime out) {
        if (in == null || out == null || out.isBefore(in)) return 0;
        return (int) java.time.Duration.between(in, out).toMinutes();
    }

    public static int overtimeMinutes(int worked, int standard) { return Math.max(0, worked - standard); }
}
