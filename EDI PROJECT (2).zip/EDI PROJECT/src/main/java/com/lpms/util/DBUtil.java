package com.lpms.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * JDBC connection utility. Configuration precedence:
 * environment variable (LPMS_DB_*) > JVM property (lpms.db.*) > db.properties on classpath > built-in default.
 */
public class DBUtil {
    private static final String URL;
    private static final String USER;
    private static final String PASSWORD;

    static {
        Properties props = new Properties();
        try (InputStream in = DBUtil.class.getClassLoader().getResourceAsStream("db.properties")) {
            if (in != null) props.load(in);
        } catch (IOException e) {
            System.err.println("Could not read db.properties: " + e.getMessage());
        }
        URL = resolve("LPMS_DB_URL", "lpms.db.url", props.getProperty("db.url"),
                "jdbc:mysql://localhost:3306/lpms?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC");
        USER = resolve("LPMS_DB_USER", "lpms.db.user", props.getProperty("db.user"), "root");
        PASSWORD = resolve("LPMS_DB_PASSWORD", "lpms.db.password", props.getProperty("db.password"), "root");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
        }
    }

    private static String resolve(String env, String sysProp, String fileValue, String fallback) {
        String v = System.getenv(env);
        if (v == null || v.isEmpty()) v = System.getProperty(sysProp);
        if (v == null || v.isEmpty()) v = fileValue;
        return (v == null || v.isEmpty()) ? fallback : v;
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    /** Returns true if a connection can be opened and validated. */
    public static boolean isDatabaseAvailable() {
        try (Connection c = getConnection()) {
            return c.isValid(3);
        } catch (SQLException e) {
            return false;
        }
    }

    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                System.err.println("Error closing connection.");
                e.printStackTrace();
            }
        }
    }
}
