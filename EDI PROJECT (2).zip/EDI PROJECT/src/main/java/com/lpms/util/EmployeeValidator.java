package com.lpms.util;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Set;
import java.util.regex.Pattern;

/** Pure input-validation rules for employee data (no I/O, unit-testable). Each method returns null if valid, else a message. */
public final class EmployeeValidator {
    public static final Set<String> GENDERS = Set.of("MALE", "FEMALE", "OTHER");
    public static final Set<String> EMP_TYPES = Set.of("FULL_TIME", "PART_TIME", "PROBATION", "INTERN");
    public static final Set<String> EMP_STATUSES = Set.of("ACTIVE", "ON_LEAVE", "RESIGNED", "TERMINATED");
    public static final Set<String> EXITED = Set.of("RESIGNED", "TERMINATED");

    private static final Pattern CODE = Pattern.compile("^[A-Za-z0-9_-]{3,30}$");
    private static final Pattern NAME = Pattern.compile("^[\\p{L}][\\p{L} .'-]{0,59}$");
    private static final Pattern EMAIL = Pattern.compile("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$");
    private static final Pattern PHONE = Pattern.compile("^\\+?[0-9][0-9 -]{5,18}[0-9]$");
    private static final Pattern USERNAME = Pattern.compile("^[A-Za-z0-9._-]{3,50}$");
    public static final int MIN_AGE = 16, MAX_AGE = 100;

    private EmployeeValidator() {}

    public static String code(String v) {
        return v != null && CODE.matcher(v).matches() ? null : "Employee code must be 3-30 characters: letters, digits, '-' or '_'.";
    }
    public static String name(String v, String label) {
        return v != null && NAME.matcher(v).matches() ? null : label + " must be 1-60 letters (spaces, '.', ''' and '-' allowed).";
    }
    public static String email(String v) {
        return v != null && v.length() <= 255 && EMAIL.matcher(v).matches() ? null : "Invalid email address.";
    }
    /** Optional field: null/blank is valid. Needs 7-15 digits. */
    public static String phone(String v) {
        if (v == null || v.isBlank()) return null;
        if (!PHONE.matcher(v).matches()) return "Invalid phone number.";
        long digits = v.chars().filter(Character::isDigit).count();
        return digits >= 7 && digits <= 15 ? null : "Phone number must have 7-15 digits.";
    }
    public static String username(String v) {
        return v != null && USERNAME.matcher(v).matches() ? null : "Username must be 3-50 characters: letters, digits, '.', '_' or '-'.";
    }
    public static String gender(String v) { return v != null && GENDERS.contains(v) ? null : "Invalid gender."; }
    public static String type(String v) { return v != null && EMP_TYPES.contains(v) ? null : "Invalid employment type."; }
    public static String status(String v) { return v != null && EMP_STATUSES.contains(v) ? null : "Invalid employment status."; }

    /** Strict yyyy-MM-dd parse; null if malformed or not a real date. */
    public static LocalDate parseDate(String v) {
        if (v == null) return null;
        try { return LocalDate.parse(v); } catch (DateTimeParseException e) { return null; }
    }

    /** Cross-field date rules. dob and exit may be null. */
    public static String dates(LocalDate dob, LocalDate joining, LocalDate exit, LocalDate today) {
        if (joining == null) return "Date of joining is required (yyyy-MM-dd).";
        if (joining.isAfter(today.plusYears(1))) return "Date of joining cannot be more than a year in the future.";
        if (dob != null) {
            if (dob.isAfter(today)) return "Date of birth cannot be in the future.";
            if (dob.plusYears(MIN_AGE).isAfter(joining)) return "Employee must be at least " + MIN_AGE + " years old at joining.";
            if (dob.plusYears(MAX_AGE).isBefore(today)) return "Date of birth is not plausible.";
        }
        if (exit != null && exit.isBefore(joining)) return "Exit date cannot be before the joining date.";
        return null;
    }
}
