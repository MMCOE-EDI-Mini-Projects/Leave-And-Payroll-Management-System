package com.lpms.util;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.BufferedReader;
import java.io.IOException;

/** Small helpers for JSON request/response handling in servlets. */
public final class Json {
    private static final Gson GSON = new Gson();

    private Json() {}

    public static void write(HttpServletResponse resp, int status, JsonObject body) throws IOException {
        resp.setStatus(status);
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.getWriter().write(GSON.toJson(body));
    }

    public static void writeArray(HttpServletResponse resp, int status, JsonArray body) throws IOException {
        resp.setStatus(status);
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.getWriter().write(GSON.toJson(body));
    }

    public static void error(HttpServletResponse resp, int status, String message) throws IOException {
        JsonObject o = new JsonObject();
        o.addProperty("error", message);
        write(resp, status, o);
    }

    public static void message(HttpServletResponse resp, int status, String message) throws IOException {
        JsonObject o = new JsonObject();
        o.addProperty("message", message);
        write(resp, status, o);
    }

    /** Parses the request body as a JSON object; returns null if empty or malformed. */
    public static JsonObject readBody(HttpServletRequest req) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = req.getReader()) {
            String line;
            while ((line = reader.readLine()) != null) sb.append(line);
        }
        try {
            return GSON.fromJson(sb.toString(), JsonObject.class);
        } catch (JsonParseException e) {
            return null;
        }
    }

    /** String value of a primitive field, trimmed; null if missing/not a primitive. */
    public static String str(JsonObject o, String key) {
        if (o == null || !o.has(key) || !o.get(key).isJsonPrimitive()) return null;
        String v = o.get(key).getAsString().trim();
        return v.isEmpty() ? null : v;
    }

    /** Raw (untrimmed) string value, e.g. for passwords; null if missing/not a primitive. */
    public static String raw(JsonObject o, String key) {
        if (o == null || !o.has(key) || !o.get(key).isJsonPrimitive()) return null;
        return o.get(key).getAsString();
    }
}
