package com.lpms.util;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDate;

/** Pure leave rules (no I/O) so they can be unit tested. Working days are Monday-Friday. */
public final class LeaveRules {
    public static final int MAX_BACKDATE_DAYS = 30;
    public static final BigDecimal HALF_DAY = new BigDecimal("0.5");

    private LeaveRules() {}

    /** Working days in [start, end]; a half day counts 0.5 (single working day only). Returns 0 if no working days. */
    public static BigDecimal countDays(LocalDate start, LocalDate end, boolean halfDay) {
        if (start == null || end == null || end.isBefore(start)) throw new IllegalArgumentException("Invalid range");
        long n = 0;
        for (LocalDate d = start; !d.isAfter(end); d = d.plusDays(1)) {
            DayOfWeek w = d.getDayOfWeek();
            if (w != DayOfWeek.SATURDAY && w != DayOfWeek.SUNDAY) n++;
        }
        if (n == 0) return BigDecimal.ZERO;
        if (halfDay) {
            if (!start.equals(end)) throw new IllegalArgumentException("Half day needs a single date");
            return HALF_DAY;
        }
        return BigDecimal.valueOf(n);
    }

    /** Returns an error message, or null when the date range is acceptable. */
    public static String validateDates(LocalDate start, LocalDate end, LocalDate today) {
        if (start == null || end == null) return "Start and end dates are required.";
        if (end.isBefore(start)) return "End date cannot be before start date.";
        if (start.getYear() != end.getYear()) return "A leave request cannot span two calendar years. Please submit separate requests.";
        if (start.isBefore(today.minusDays(MAX_BACKDATE_DAYS))) return "Leave cannot be backdated by more than " + MAX_BACKDATE_DAYS + " days.";
        if (start.getYear() > today.getYear() + 1) return "Leave can only be requested up to next calendar year.";
        return null;
    }

    /** Two inclusive ranges overlap when each starts on or before the other ends. */
    public static boolean overlaps(LocalDate s1, LocalDate e1, LocalDate s2, LocalDate e2) {
        return !s1.isAfter(e2) && !s2.isAfter(e1);
    }
}
