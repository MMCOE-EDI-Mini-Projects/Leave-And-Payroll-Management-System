package com.lpms.util;

import java.util.concurrent.ConcurrentHashMap;
import java.util.function.LongSupplier;

/** In-memory brute-force protection: lock a key after MAX_FAILURES failures for LOCK_MS. */
public class LoginThrottle {
    public static final int MAX_FAILURES = 5;
    public static final long LOCK_MS = 15 * 60 * 1000L;

    private static class Entry { int failures; long lockedUntil; }

    private final ConcurrentHashMap<String, Entry> entries = new ConcurrentHashMap<>();
    private final LongSupplier clock;

    public LoginThrottle() { this(System::currentTimeMillis); }
    public LoginThrottle(LongSupplier clock) { this.clock = clock; }

    /** @return remaining lock time in seconds, or 0 if not locked. */
    public long secondsLocked(String key) {
        Entry e = entries.get(key);
        if (e == null) return 0;
        synchronized (e) {
            long left = e.lockedUntil - clock.getAsLong();
            if (left <= 0) {
                if (e.lockedUntil != 0) { e.failures = 0; e.lockedUntil = 0; }
                return 0;
            }
            return (left + 999) / 1000;
        }
    }

    public void recordFailure(String key) {
        Entry e = entries.computeIfAbsent(key, k -> new Entry());
        synchronized (e) {
            if (e.lockedUntil != 0 && e.lockedUntil <= clock.getAsLong()) { e.failures = 0; e.lockedUntil = 0; }
            e.failures++;
            if (e.failures >= MAX_FAILURES) e.lockedUntil = clock.getAsLong() + LOCK_MS;
        }
    }

    public void recordSuccess(String key) { entries.remove(key); }
}
