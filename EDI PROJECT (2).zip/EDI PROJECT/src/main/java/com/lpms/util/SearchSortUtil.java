package com.lpms.util;

import com.lpms.model.Employee;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Foundational Course Data Structures & Algorithms Implementation:
 * Provides verified Search and Sort algorithms applied directly to core domain objects.
 * 
 * Algorithms implemented:
 * 1. Binary Search: O(log N) time, O(1) space. Used for fast lookup on sorted employee/salary lists.
 * 2. Merge Sort: O(N log N) time, O(N) space. Stable sorting used for payroll registers and report generation.
 * 3. Quick Sort: O(N log N) avg time, O(log N) space. In-place sorting used for tabular data display.
 */
public final class SearchSortUtil {

    private SearchSortUtil() {}

    /**
     * Binary Search algorithm on a pre-sorted list.
     * Time Complexity: O(log N)
     * Space Complexity: O(1)
     */
    public static <T> int binarySearch(List<T> list, T key, Comparator<T> comp) {
        if (list == null || key == null || comp == null) return -1;
        int low = 0;
        int high = list.size() - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2;
            int cmp = comp.compare(list.get(mid), key);

            if (cmp < 0) {
                low = mid + 1;
            } else if (cmp > 0) {
                high = mid - 1;
            } else {
                return mid; // Key found
            }
        }
        return -(low + 1); // Key not found (insertion point)
    }

    /**
     * Binary Search specifically for searching an Employee by employee_code in an employee list sorted by code.
     * Time Complexity: O(log N)
     * Space Complexity: O(1)
     */
    public static int binarySearchEmployeeByCode(List<Employee> sortedEmployees, String targetCode) {
        if (sortedEmployees == null || targetCode == null) return -1;
        int low = 0;
        int high = sortedEmployees.size() - 1;
        String normalizedTarget = targetCode.trim();

        while (low <= high) {
            int mid = low + (high - low) / 2;
            Employee midEmp = sortedEmployees.get(mid);
            String midCode = midEmp.getEmployeeCode() != null ? midEmp.getEmployeeCode() : "";
            int cmp = midCode.compareToIgnoreCase(normalizedTarget);

            if (cmp < 0) {
                low = mid + 1;
            } else if (cmp > 0) {
                high = mid - 1;
            } else {
                return mid;
            }
        }
        return -1;
    }

    /**
     * Merge Sort algorithm: Stable, divide-and-conquer sorting.
     * Time Complexity: O(N log N) guaranteed in best, worst, and average cases.
     * Space Complexity: O(N) auxiliary space.
     * Used for payroll registers and report sorting where relative ordering must be preserved.
     */
    public static <T> void mergeSort(List<T> list, Comparator<T> comp) {
        if (list == null || list.size() <= 1 || comp == null) return;
        List<T> aux = new ArrayList<>(list);
        mergeSortInternal(list, aux, 0, list.size() - 1, comp);
    }

    private static <T> void mergeSortInternal(List<T> list, List<T> aux, int low, int high, Comparator<T> comp) {
        if (low >= high) return;
        int mid = low + (high - low) / 2;

        mergeSortInternal(list, aux, low, mid, comp);
        mergeSortInternal(list, aux, mid + 1, high, comp);
        merge(list, aux, low, mid, high, comp);
    }

    private static <T> void merge(List<T> list, List<T> aux, int low, int mid, int high, Comparator<T> comp) {
        for (int k = low; k <= high; k++) {
            aux.set(k, list.get(k));
        }

        int i = low;
        int j = mid + 1;
        for (int k = low; k <= high; k++) {
            if (i > mid) {
                list.set(k, aux.get(j++));
            } else if (j > high) {
                list.set(k, aux.get(i++));
            } else if (comp.compare(aux.get(j), aux.get(i)) < 0) {
                list.set(k, aux.get(j++));
            } else {
                list.set(k, aux.get(i++));
            }
        }
    }

    /**
     * Quick Sort algorithm: Efficient in-place divide-and-conquer sorting.
     * Time Complexity: O(N log N) average case, O(N^2) worst case.
     * Space Complexity: O(log N) stack space.
     */
    public static <T> void quickSort(List<T> list, Comparator<T> comp) {
        if (list == null || list.size() <= 1 || comp == null) return;
        quickSortInternal(list, 0, list.size() - 1, comp);
    }

    private static <T> void quickSortInternal(List<T> list, int low, int high, Comparator<T> comp) {
        if (low < high) {
            int pivotIndex = partition(list, low, high, comp);
            quickSortInternal(list, low, pivotIndex - 1, comp);
            quickSortInternal(list, pivotIndex + 1, high, comp);
        }
    }

    private static <T> int partition(List<T> list, int low, int high, Comparator<T> comp) {
        // Median-of-three pivot selection to avoid worst-case O(N^2) on sorted inputs
        int mid = low + (high - low) / 2;
        if (comp.compare(list.get(low), list.get(mid)) > 0) swap(list, low, mid);
        if (comp.compare(list.get(low), list.get(high)) > 0) swap(list, low, high);
        if (comp.compare(list.get(mid), list.get(high)) > 0) swap(list, mid, high);
        swap(list, mid, high);

        T pivot = list.get(high);
        int i = low - 1;
        for (int j = low; j < high; j++) {
            if (comp.compare(list.get(j), pivot) <= 0) {
                i++;
                swap(list, i, j);
            }
        }
        swap(list, i + 1, high);
        return i + 1;
    }

    private static <T> void swap(List<T> list, int i, int j) {
        T temp = list.get(i);
        list.set(i, list.get(j));
        list.set(j, temp);
    }
}
