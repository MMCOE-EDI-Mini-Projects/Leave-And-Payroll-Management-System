// All API calls go through here: adds the CSRF header and redirects to login on 401.
async function apiFetch(url, opts = {}) {
    opts.headers = Object.assign({ 'X-Requested-With': 'LPMS' }, opts.headers || {});
    const r = await fetch(url, opts);
    if (r.status === 401) { location.replace('login.html'); }
    return r;
}

function esc(v) {
    return String(v == null ? '' : v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

function fmtCur(amt) {
    return '₹' + Number(amt || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

document.addEventListener('DOMContentLoaded', () => {
    const $ = id => document.getElementById(id);
    const jsonHdr = { 'Content-Type': 'application/json' };

    // DOM Elements - Shell
    const logoutBtn = $('logoutBtn');
    const userNameDisplay = $('userNameDisplay');
    const pageTitle = $('pageTitle');

    // Navigation Links
    const navDashboard = $('nav-dashboard');
    const navLeave = $('nav-leave');
    const navAttendance = $('nav-attendance');
    const navPayslips = $('nav-payslips');
    const navPayroll = $('nav-payroll');
    const navReports = $('nav-reports');
    const navEmployees = $('nav-employees');
    const navAdmin = $('nav-admin');
    const navAccount = $('nav-account');
    const navLinks = [navDashboard, navLeave, navAttendance, navPayslips, navPayroll, navReports, navEmployees, navAdmin, navAccount];

    // Views
    const viewDashboard = $('view-dashboard');
    const viewLeave = $('view-leave');
    const viewAttendance = $('view-attendance');
    const viewPayslips = $('view-payslips');
    const viewPayroll = $('view-payroll');
    const viewReports = $('view-reports');
    const viewEmployees = $('view-employees');
    const viewAdmin = $('view-admin');
    const viewAccount = $('view-account');
    const views = [viewDashboard, viewLeave, viewAttendance, viewPayslips, viewPayroll, viewReports, viewEmployees, viewAdmin, viewAccount];

    // State
    let currentUser = null;

    // View Manager
    function switchView(viewId, title, activeNav) {
        views.forEach(v => { if (v) v.classList.add('hidden'); });
        const targetView = $(viewId);
        if (targetView) targetView.classList.remove('hidden');
        
        navLinks.forEach(n => { if (n) n.classList.remove('active'); });
        if (activeNav) activeNav.classList.add('active');
        
        if (pageTitle) pageTitle.textContent = title;
        
        if (viewId === 'view-dashboard') loadDashboardView();
        if (viewId === 'view-leave') loadLeaveView();
        if (viewId === 'view-attendance') loadAttendanceView();
        if (viewId === 'view-payslips') loadMyPayslipsView();
        if (viewId === 'view-payroll') loadPayrollView();
        if (viewId === 'view-reports') loadReportsView();
        if (viewId === 'view-employees') loadEmployees();
        if (viewId === 'view-admin') loadAdminView();
    }

    if (navDashboard) navDashboard.addEventListener('click', (e) => { e.preventDefault(); switchView('view-dashboard', 'Dashboard', navDashboard); });
    if (navLeave) navLeave.addEventListener('click', (e) => { e.preventDefault(); switchView('view-leave', 'Leave Management', navLeave); });
    if (navAttendance) navAttendance.addEventListener('click', (e) => { e.preventDefault(); switchView('view-attendance', 'Attendance', navAttendance); });
    if (navPayslips) navPayslips.addEventListener('click', (e) => { e.preventDefault(); switchView('view-payslips', 'My Payslips', navPayslips); });
    if (navPayroll) navPayroll.addEventListener('click', (e) => { e.preventDefault(); switchView('view-payroll', 'Payroll Processing', navPayroll); });
    if (navReports) navReports.addEventListener('click', (e) => { e.preventDefault(); switchView('view-reports', 'Reports & Exports', navReports); });
    if (navEmployees) navEmployees.addEventListener('click', (e) => { e.preventDefault(); switchView('view-employees', 'Employees', navEmployees); });
    if (navAdmin) navAdmin.addEventListener('click', (e) => { e.preventDefault(); switchView('view-admin', 'Administration & Configuration', navAdmin); });
    if (navAccount) navAccount.addEventListener('click', (e) => { e.preventDefault(); switchView('view-account', 'My Account', navAccount); });

    // --- Authentication / Session Bootstrap ---
    (async function bootstrap() {
        try {
            const r = await apiFetch('/lpms/api/auth/me');
            if (!r.ok) { location.replace('login.html'); return; }
            currentUser = await r.json();
        } catch (e) { location.replace('login.html'); return; }

        if (userNameDisplay) userNameDisplay.textContent = `Welcome, ${currentUser.firstName} (${currentUser.role})`;
        
        if (currentUser.role === 'HR_ADMIN') {
            document.querySelectorAll('.admin-only').forEach(el => el.classList.remove('hidden'));
        }
        if (currentUser.role === 'HR_ADMIN' || currentUser.role === 'MANAGER') {
            document.querySelectorAll('.staff-only').forEach(el => el.classList.remove('hidden'));
        }
        
        switchView('view-dashboard', 'Dashboard', navDashboard);
    })();

    if (logoutBtn) {
        logoutBtn.addEventListener('click', async () => {
            try { await apiFetch('/lpms/api/auth/logout', { method: 'POST' }); } catch (e) {}
            currentUser = null;
            location.replace('login.html');
        });
    }

    // --- Change Password ---
    const pwForm = $('pwForm');
    if (pwForm) {
        pwForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const msg = $('pwMsg');
            const r = await apiFetch('/lpms/api/auth/change-password', {
                method: 'POST', headers: jsonHdr,
                body: JSON.stringify({ currentPassword: $('pwCurrent').value,
                                       newPassword: $('pwNew').value })
            });
            const d = await r.json();
            msg.className = r.ok ? 'text-success' : 'text-danger';
            msg.textContent = d.message || d.error;
            if (r.ok) e.target.reset();
        });
    }

    // Helper: generic JSON fetcher
    async function getJson(url) {
        const r = await apiFetch(url);
        if (!r.ok) {
            const d = await r.json().catch(() => ({}));
            throw new Error(d.error || 'Request failed');
        }
        return r.json();
    }

    // ==========================================
    // 1. DASHBOARD VIEW
    // ==========================================
    async function loadDashboardView() {
        // Quick Action Buttons
        $('dashBtnApplyLeave').onclick = () => switchView('view-leave', 'Leave Management', navLeave);
        $('dashBtnMarkAtt').onclick = () => switchView('view-attendance', 'Attendance', navAttendance);
        $('dashBtnMyPayslips').onclick = () => switchView('view-payslips', 'My Payslips', navPayslips);
        if ($('dashBtnRunPayroll')) {
            $('dashBtnRunPayroll').onclick = () => switchView('view-payroll', 'Payroll Processing', navPayroll);
        }

        // Fetch Leave Balance Stat
        try {
            const balances = await getJson('/lpms/api/leaves/balances');
            let totalAvail = 0;
            balances.forEach(b => { totalAvail += Number(b.available || 0); });
            $('dashLeaveBal').textContent = `${totalAvail} Days`;
        } catch (e) { $('dashLeaveBal').textContent = 'N/A'; }

        // Fetch Attendance Stat
        try {
            const curMonth = new Date().toISOString().slice(0, 7);
            const att = await getJson(`/lpms/api/attendance/history?employeeId=${currentUser.employeeId}&month=${curMonth}`);
            $('dashAttDays').textContent = `${att.presentDays || 0} / ${att.workingDays || 0}`;
        } catch (e) { $('dashAttDays').textContent = '0'; }

        // Fetch Recent Net Pay
        try {
            const payslips = await getJson('/lpms/api/payroll/my-payslips');
            if (payslips.length > 0) {
                $('dashNetPay').textContent = fmtCur(payslips[0].netSalary);
            } else {
                $('dashNetPay').textContent = 'None yet';
            }
        } catch (e) { $('dashNetPay').textContent = 'N/A'; }

        // Fetch Pending Leaves (Queue)
        if (currentUser.role === 'MANAGER' || currentUser.role === 'HR_ADMIN') {
            try {
                const queue = await getJson('/lpms/api/leaves/queue');
                $('dashPendingLeaves').textContent = `${queue.length} Pending`;
            } catch (e) { $('dashPendingLeaves').textContent = '0'; }
        } else {
            try {
                const myLeaves = await getJson('/lpms/api/leaves/my');
                const pendingCount = myLeaves.filter(l => l.status === 'PENDING').length;
                $('dashPendingLeaves').textContent = `${pendingCount} Applied`;
            } catch (e) { $('dashPendingLeaves').textContent = '0'; }
        }
    }

    // ==========================================
    // 2. EMPLOYEES VIEW
    // ==========================================
    const empMsg = $('empMsg');
    const empForm = $('empForm');
    let editingId = null;
    let refData = null;
    let empCache = [];

    function fillSelect(id, items, blank) {
        const el = $(id);
        if (!el) return;
        el.innerHTML = (blank ? `<option value="">${blank}</option>` : '') +
            items.map(i => `<option value="${esc(i.id)}">${esc(i.name)}</option>`).join('');
    }

    async function loadReference() {
        const ref = await apiFetch('/lpms/api/reference');
        if (!ref.ok) return;
        refData = await ref.json();
        const keepSel = ['eDept', 'eDesig', 'eMgr'].map(id => $(id) ? $(id).value : '');
        fillSelect('eDept', refData.departments, 'Select department');
        fillSelect('eDesig', refData.designations, 'Select designation');
        fillSelect('eMgr', refData.managers, '(No reporting manager)');
        ['eDept', 'eDesig', 'eMgr'].forEach((id, i) => { if ($(id)) $(id).value = keepSel[i]; });
        if ($('fDept')) {
            const keep = $('fDept').value;
            fillSelect('fDept', refData.departments, 'All departments');
            $('fDept').value = keep;
        }
    }

    async function loadEmployees() {
        const hr = currentUser.role === 'HR_ADMIN';
        if ($('empListTitle')) $('empListTitle').textContent = hr ? 'All Employees' : 'My Team';
        if (hr && !refData) await loadReference();
        await runSearch();
    }

    async function runSearch() {
        const box = $('empTable');
        if (!box) return;
        const hr = currentUser.role === 'HR_ADMIN';
        const p = new URLSearchParams();
        if ($('fQuery') && $('fQuery').value.trim()) p.set('q', $('fQuery').value.trim());
        if (hr && $('fDept') && $('fDept').value) p.set('departmentId', $('fDept').value);
        if ($('fStatus') && $('fStatus').value) p.set('status', $('fStatus').value);
        if ($('fActive') && $('fActive').value) p.set('active', $('fActive').value);
        const r = await apiFetch('/lpms/api/employees?' + p.toString());
        if (!r.ok) { box.innerHTML = '<p class="text-danger">Failed to load employees.</p>'; return; }
        empCache = await r.json();
        if (!empCache.length) { box.innerHTML = '<p>No employees found.</p>'; return; }
        let h = '<table class="data-table"><tr><th>ID</th><th>Name</th><th>Department</th><th>Designation</th><th>Manager</th><th>Joined</th><th>Status</th><th>Account</th><th>Actions</th></tr>';
        empCache.forEach(e => {
            const self = e.employeeId === currentUser.employeeId;
            h += `<tr><td>${esc(e.employeeCode)}</td><td>${esc(e.firstName)} ${esc(e.lastName)}</td>
                <td>${esc(e.departmentName)}</td><td>${esc(e.designationName)}</td><td>${esc(e.managerName || '-')}</td>
                <td>${esc(e.dateOfJoining)}</td><td>${esc(e.employmentStatus)}</td>
                <td><span class="badge ${e.isActive ? 'ok' : 'off'}">${e.isActive ? 'Active' : 'Inactive'}</span></td>
                <td><button class="btn btn-primary btn-sm" data-act="view" data-id="${e.employeeId}">View</button>`;
            if (hr) {
                h += `<button class="btn btn-primary btn-sm" data-act="edit" data-id="${e.employeeId}">Edit</button>`;
                if (!self) {
                    h += `<button class="btn btn-primary btn-sm" data-act="status" data-id="${e.employeeId}" data-active="${!e.isActive}">${e.isActive ? 'Deactivate' : 'Activate'}</button>
                    <button class="btn btn-primary btn-sm" data-act="role" data-id="${e.employeeId}" data-role="${esc(e.role)}">Role</button>
                    <button class="btn btn-primary btn-sm" data-act="reset" data-id="${e.employeeId}">Reset PW</button>
                    <button class="btn btn-danger btn-sm" data-act="delete" data-id="${e.employeeId}">Delete</button>`;
                }
            }
            h += '</td></tr>';
        });
        box.innerHTML = h + '</table>';
    }

    let searchTimer = null;
    if ($('fQuery')) $('fQuery').addEventListener('input', () => { clearTimeout(searchTimer); searchTimer = setTimeout(runSearch, 300); });
    ['fDept', 'fStatus', 'fActive'].forEach(id => { if ($(id)) $(id).addEventListener('change', runSearch); });

    function showDetails(e) {
        const row = (k, v) => `<div><dt>${esc(k)}</dt><dd>${esc(v == null || v === '' ? '-' : v)}</dd></div>`;
        $('empModalTitle').textContent = `${e.firstName} ${e.lastName} (${e.employeeCode})`;
        $('empModalBody').innerHTML = '<dl class="detail-grid">' +
            row('Employee ID', e.employeeCode) + row('Username', e.username) + row('Email', e.email) + row('Phone', e.phone) +
            row('Gender', e.gender) + row('Date of birth', e.dateOfBirth) + row('Department', e.departmentName) +
            row('Designation', e.designationName) + row('Reporting manager', e.managerName) + row('Role', e.role) +
            row('Employment type', e.employmentType) + row('Employment status', e.employmentStatus) +
            row('Date of joining', e.dateOfJoining) + row('Date of exit', e.dateOfExit) +
            row('Account', e.isActive ? 'Active' : 'Inactive') + row('Last login', e.lastLoginAt) + '</dl>';
        $('empModal').classList.remove('hidden');
    }
    if ($('empModalClose')) $('empModalClose').addEventListener('click', () => $('empModal').classList.add('hidden'));
    if ($('empModal')) $('empModal').addEventListener('click', ev => { if (ev.target === $('empModal')) $('empModal').classList.add('hidden'); });

    function setFormMode(editing) {
        if (!$('empFormTitle')) return;
        $('empFormTitle').textContent = editing ? 'Edit Employee' : 'Add Employee';
        $('empSubmit').textContent = editing ? 'Save Changes' : 'Add Employee';
        $('empCancel').classList.toggle('hidden', !editing);
        $('eAuthRow').classList.toggle('hidden', editing);
        $('eCode').disabled = editing;
        $('eUser').required = $('ePass').required = !editing;
    }

    function resetEmpForm() {
        editingId = null;
        if (empForm) empForm.reset();
        setFormMode(false);
    }
    if ($('empCancel')) $('empCancel').addEventListener('click', () => { resetEmpForm(); empMsg.textContent = ''; });

    function startEdit(e) {
        editingId = e.employeeId;
        setFormMode(true);
        const ensureOption = (sel, id, name) => {
            if (id != null && ![...$(sel).options].some(o => o.value === String(id))) {
                $(sel).insertAdjacentHTML('beforeend', `<option value="${esc(id)}">${esc(name || id)}</option>`);
            }
        };
        ensureOption('eDept', e.departmentId, e.departmentName);
        ensureOption('eDesig', e.designationId, e.designationName);
        ensureOption('eMgr', e.reportingManagerId, e.managerName);
        $('eCode').value = e.employeeCode; $('eFirst').value = e.firstName; $('eLast').value = e.lastName;
        $('eEmail').value = e.email; $('ePhone').value = e.phone || ''; $('eGender').value = e.gender;
        $('eDob').value = e.dateOfBirth || ''; $('eJoin').value = e.dateOfJoining || ''; $('eExit').value = e.dateOfExit || '';
        $('eDept').value = e.departmentId; $('eDesig').value = e.designationId; $('eMgr').value = e.reportingManagerId || '';
        $('eType').value = e.employmentType; $('eStatus').value = e.employmentStatus;
        empMsg.textContent = '';
        empForm.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    if ($('empTable')) {
        $('empTable').addEventListener('click', async (ev) => {
            const b = ev.target.closest('button[data-act]');
            if (!b) return;
            const id = Number(b.dataset.id);
            const emp = empCache.find(x => x.employeeId === id);
            let r;
            if (b.dataset.act === 'view') { showDetails(emp); return; }
            if (b.dataset.act === 'edit') { startEdit(emp); return; }
            if (b.dataset.act === 'status') {
                const activate = b.dataset.active === 'true';
                const body = { active: activate };
                if (!activate) {
                    const s = prompt('Employment status after deactivation (RESIGNED or TERMINATED):', 'RESIGNED');
                    if (!s) return;
                    body.employmentStatus = s.trim().toUpperCase();
                }
                r = await apiFetch(`/lpms/api/employees/${id}/status`, { method: 'PUT', headers: jsonHdr, body: JSON.stringify(body) });
            } else if (b.dataset.act === 'role') {
                const role = prompt('New role (EMPLOYEE, MANAGER, HR_ADMIN):', b.dataset.role);
                if (!role) return;
                r = await apiFetch(`/lpms/api/employees/${id}/role`, { method: 'PUT', headers: jsonHdr, body: JSON.stringify({ role: role.trim().toUpperCase() }) });
            } else if (b.dataset.act === 'delete') {
                if (!confirm(`Permanently delete ${emp.firstName} ${emp.lastName} (${emp.employeeCode})? This cannot be undone.\nEmployees with history can only be deactivated.`)) return;
                r = await apiFetch(`/lpms/api/employees/${id}`, { method: 'DELETE' });
                if (r.ok && editingId === id) resetEmpForm();
            } else {
                const pw = prompt('New temporary password (8+ chars, letter + digit):');
                if (!pw) return;
                r = await apiFetch(`/lpms/api/employees/${id}/reset-password`, { method: 'POST', headers: jsonHdr, body: JSON.stringify({ newPassword: pw }) });
            }
            const d = await r.json();
            alert(d.message || d.error);
            refData = null;
            loadEmployees();
        });
    }

    if (empForm) {
        empForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const v = id => $(id).value.trim();
            const body = { firstName: v('eFirst'), lastName: v('eLast'), gender: v('eGender'), email: v('eEmail'),
                dateOfJoining: v('eJoin'), employmentType: v('eType'), employmentStatus: v('eStatus'),
                departmentId: v('eDept'), designationId: v('eDesig') };
            if (v('ePhone')) body.phone = v('ePhone');
            if (v('eDob')) body.dateOfBirth = v('eDob');
            if (v('eMgr')) body.reportingManagerId = v('eMgr');
            let r;
            if (editingId) {
                if (v('eExit')) body.dateOfExit = v('eExit');
                r = await apiFetch(`/lpms/api/employees/${editingId}`, { method: 'PUT', headers: jsonHdr, body: JSON.stringify(body) });
            } else {
                body.employeeCode = v('eCode'); body.username = v('eUser'); body.password = $('ePass').value; body.role = v('eRole');
                r = await apiFetch('/lpms/api/employees', { method: 'POST', headers: jsonHdr, body: JSON.stringify(body) });
            }
            const d = await r.json();
            empMsg.className = r.ok ? 'text-success' : 'text-danger';
            empMsg.textContent = d.message || d.error;
            if (r.ok) { resetEmpForm(); refData = null; loadEmployees(); }
        });
        setFormMode(false);
    }

    // ==========================================
    // 3. LEAVE MANAGEMENT VIEW (With FIFO Queue)
    // ==========================================
    const leaveForm = $('leaveForm');
    const leaveMsg = $('leaveMsg');
    const isStaff = () => currentUser.role === 'MANAGER' || currentUser.role === 'HR_ADMIN';
    const num = v => Number(v).toString();
    let leaveTypes = [];
    const statusBadge = st => `<span class="badge ${st === 'APPROVED' ? 'ok' : (st === 'REJECTED' || st === 'CANCELLED') ? 'off' : ''}">${esc(st)}</span>`;
    const range = l => l.startDate === l.endDate ? esc(l.startDate) : `${esc(l.startDate)} to ${esc(l.endDate)}`;

    async function loadLeaveView() {
        if ($('balYear')) $('balYear').textContent = '(' + new Date().getFullYear() + ')';
        try {
            if (!leaveTypes.length) {
                leaveTypes = await getJson('/lpms/api/leaves/types');
                $('leaveType').innerHTML = leaveTypes.map(t => `<option value="${esc(t.leaveTypeId)}">${esc(t.leaveName)}</option>`).join('');
            }
        } catch (e) { if (leaveMsg) { leaveMsg.className = 'text-danger'; leaveMsg.textContent = e.message; } }
        loadBalances();
        loadMyLeaves();
        updateDaysPreview();
        if (isStaff()) {
            $('managerLeaveSection').classList.remove('hidden');
            $('decidedLeaveSection').classList.remove('hidden');
            fetchPendingLeaves();
            fetchDecidedLeaves();
        }
    }

    async function loadBalances() {
        const box = $('leaveBalances');
        if (!box) return;
        try {
            const rows = await getJson('/lpms/api/leaves/balances');
            if (!rows.length) { box.innerHTML = '<p>No leave balances configured.</p>'; return; }
            let h = '<table class="data-table"><tr><th>Leave type</th><th>Entitlement</th><th>Used</th><th>Remaining</th><th>Pending</th><th>Available</th></tr>';
            rows.forEach(b => {
                h += `<tr><td>${esc(b.leaveName)}</td><td>${num(+b.opening + +b.entitlement)}</td><td>${num(b.used)}</td>
                    <td>${num(b.remaining)}</td><td>${num(b.pending)}</td><td><strong>${num(b.available)}</strong></td></tr>`;
            });
            box.innerHTML = h + '</table><p class="field">Remaining = entitlement - used (approved). Available also reserves days in pending requests. Unpaid leave is not balance-limited.</p>';
        } catch (e) { box.innerHTML = `<p class="text-danger">${esc(e.message)}</p>`; }
    }

    async function loadMyLeaves() {
        const box = $('leaveHistoryTable');
        if (!box) return;
        try {
            const rows = await getJson('/lpms/api/leaves/my');
            if (!rows.length) { box.innerHTML = '<p>You have not applied for any leave yet.</p>'; return; }
            const today = new Date().toISOString().split('T')[0];
            let h = '<table class="data-table"><tr><th>#</th><th>Type</th><th>Dates</th><th>Days</th><th>Reason</th><th>Status</th><th>Decision</th><th>Actions</th></tr>';
            rows.forEach(l => {
                const cancellable = l.status === 'PENDING' || (l.status === 'APPROVED' && l.startDate > today);
                h += `<tr><td>${l.leaveApplicationId}</td><td>${esc(l.leaveName)}</td><td>${range(l)}</td><td>${num(l.totalDays)}</td>
                    <td>${esc(l.reason)}</td><td>${statusBadge(l.status)}</td>
                    <td>${l.approverName ? esc(l.approverName) + (l.managerComments ? ': ' + esc(l.managerComments) : '') : '-'}</td>
                    <td><button class="btn btn-primary btn-sm" data-act="history" data-id="${l.leaveApplicationId}">History</button>
                    ${cancellable ? `<button class="btn btn-danger btn-sm" data-act="cancel" data-id="${l.leaveApplicationId}">Cancel</button>` : ''}</td></tr>`;
            });
            box.innerHTML = h + '</table>';
        } catch (e) { box.innerHTML = `<p class="text-danger">${esc(e.message)}</p>`; }
    }

    async function showLeaveHistory(id) {
        try {
            const rows = await getJson(`/lpms/api/leaves/${id}/history`);
            $('leaveModalTitle').textContent = `Leave request #${id}`;
            $('leaveModalBody').innerHTML = rows.length ?
                '<table class="data-table"><tr><th>When</th><th>Action</th><th>By</th><th>Comments</th></tr>' +
                rows.map(h => `<tr><td>${esc(h.performedAt)}</td><td>${statusBadge(h.action === 'SUBMITTED' ? 'PENDING' : h.action)} ${esc(h.action)}</td><td>${esc(h.performedBy)}</td><td>${esc(h.comments || '-')}</td></tr>`).join('') + '</table>'
                : '<p>No history recorded.</p>';
            $('leaveModal').classList.remove('hidden');
        } catch (e) { alert(e.message); }
    }
    if ($('leaveModalClose')) $('leaveModalClose').addEventListener('click', () => $('leaveModal').classList.add('hidden'));
    if ($('leaveModal')) $('leaveModal').addEventListener('click', ev => { if (ev.target === $('leaveModal')) $('leaveModal').classList.add('hidden'); });

    async function postLeave(body) {
        const r = await apiFetch('/lpms/api/leaves/action', { method: 'POST', headers: jsonHdr, body: JSON.stringify(body) });
        const d = await r.json().catch(() => ({}));
        return { ok: r.ok, text: d.message || d.error || 'Request failed' };
    }

    if ($('leaveHistoryTable')) {
        $('leaveHistoryTable').addEventListener('click', async (ev) => {
            const b = ev.target.closest('button[data-act]');
            if (!b) return;
            const id = Number(b.dataset.id);
            if (b.dataset.act === 'history') { showLeaveHistory(id); return; }
            if (!confirm('Cancel this leave request?')) return;
            const res = await postLeave({ action: 'CANCEL', leaveApplicationId: id });
            alert(res.text);
            loadBalances(); loadMyLeaves();
            if (isStaff()) { fetchPendingLeaves(); fetchDecidedLeaves(); }
        });
    }

    function previewDays(s, e, half) {
        if (!s || !e) return null;
        const a = new Date(s + 'T00:00:00'), z = new Date(e + 'T00:00:00');
        if (z < a) return null;
        let n = 0;
        for (let d = new Date(a); d <= z; d.setDate(d.getDate() + 1)) { const w = d.getDay(); if (w !== 0 && w !== 6) n++; }
        return half ? (n ? 0.5 : 0) : n;
    }
    function updateDaysPreview() {
        if (!$('leaveHalf') || !$('leaveDaysPreview')) return;
        const half = $('leaveHalf').checked;
        const n = previewDays($('leaveStart').value, $('leaveEnd').value, half);
        $('leaveDaysPreview').textContent = n === null ? '' : `Working days requested: ${n} (weekends excluded)`;
    }
    ['leaveStart', 'leaveEnd', 'leaveHalf'].forEach(id => {
        if ($(id)) $(id).addEventListener('change', () => {
            if (id === 'leaveStart' && !$('leaveEnd').value) $('leaveEnd').value = $('leaveStart').value;
            if ($('leaveHalf').checked && $('leaveStart').value) $('leaveEnd').value = $('leaveStart').value;
            updateDaysPreview();
        });
    });

    if (leaveForm) {
        leaveForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const start = $('leaveStart').value, end = $('leaveEnd').value;
            if (end < start) {
                leaveMsg.className = 'text-danger';
                leaveMsg.textContent = 'End date cannot be before start date.';
                return;
            }
            if ($('leaveHalf').checked && start !== end) {
                leaveMsg.className = 'text-danger';
                leaveMsg.textContent = 'A half-day request must be for a single date.';
                return;
            }
            try {
                const res = await postLeave({ action: 'APPLY', leaveTypeId: $('leaveType').value, startDate: start, endDate: end,
                                              halfDay: $('leaveHalf').checked, reason: $('leaveReason').value });
                leaveMsg.className = res.ok ? 'text-success' : 'text-danger';
                leaveMsg.textContent = res.text;
                if (res.ok) { leaveForm.reset(); updateDaysPreview(); loadBalances(); loadMyLeaves(); }
            } catch (error) {
                leaveMsg.className = 'text-danger';
                leaveMsg.textContent = 'Connection error';
            }
        });
    }

    // Pending requests & FIFO Queue
    async function fetchPendingLeaves() {
        const container = $('pendingLeavesContainer');
        if (!container) return;
        try {
            const queue = await getJson('/lpms/api/leaves/queue');
            if ($('queueCountBadge')) $('queueCountBadge').textContent = queue.length;
            if (!queue.length) {
                container.innerHTML = '<p>No pending leaves to approve.</p>';
                return;
            }
            let h = '<table class="data-table"><tr><th>Queue #</th><th>Employee</th><th>Type</th><th>Dates</th><th>Days</th><th>Balance left</th><th>Reason</th><th>Comment</th><th>Action</th></tr>';
            queue.forEach((l, idx) => {
                h += `<tr><td><strong>#${idx + 1}</strong></td><td>${esc(l.employeeName)} (${esc(l.employeeCode)})</td><td>${esc(l.leaveName)}</td><td>${range(l)}</td><td>${num(l.totalDays)}</td>
                    <td>${l.balanceRemaining == null ? '-' : num(l.balanceRemaining)}</td><td>${esc(l.reason)}</td>
                    <td><input class="form-control" maxlength="500" placeholder="Required to reject" data-comment="${l.leaveApplicationId}"></td>
                    <td><button class="btn btn-primary btn-sm" data-act="APPROVE" data-id="${l.leaveApplicationId}">Approve</button>
                    <button class="btn btn-danger btn-sm" data-act="REJECT" data-id="${l.leaveApplicationId}">Reject</button></td></tr>`;
            });
            container.innerHTML = h + '</table>';
        } catch (e) { container.innerHTML = `<p class="text-danger">${esc(e.message)}</p>`; }
    }

    async function fetchDecidedLeaves() {
        const container = $('decidedLeavesContainer');
        if (!container) return;
        try {
            const leaves = await getJson('/lpms/api/leaves/decided');
            if (!leaves.length) { container.innerHTML = '<p>No decisions yet.</p>'; return; }
            let h = '<table class="data-table"><tr><th>Employee</th><th>Type</th><th>Dates</th><th>Days</th><th>Status</th><th>Decided by</th><th>When</th><th>Comments</th><th></th></tr>';
            leaves.forEach(l => {
                h += `<tr><td>${esc(l.employeeName)}</td><td>${esc(l.leaveName)}</td><td>${range(l)}</td><td>${num(l.totalDays)}</td><td>${statusBadge(l.status)}</td>
                    <td>${esc(l.approverName || '-')}</td><td>${esc(l.actionedAt || '-')}</td><td>${esc(l.managerComments || '-')}</td>
                    <td><button class="btn btn-primary btn-sm" data-act="history" data-id="${l.leaveApplicationId}">History</button></td></tr>`;
            });
            container.innerHTML = h + '</table>';
        } catch (e) { container.innerHTML = `<p class="text-danger">${esc(e.message)}</p>`; }
    }

    if ($('decidedLeavesContainer')) {
        $('decidedLeavesContainer').addEventListener('click', ev => {
            const b = ev.target.closest('button[data-act="history"]');
            if (b) showLeaveHistory(Number(b.dataset.id));
        });
    }

    if ($('pendingLeavesContainer')) {
        $('pendingLeavesContainer').addEventListener('click', async (ev) => {
            const b = ev.target.closest('button[data-act]');
            if (!b) return;
            const id = Number(b.dataset.id);
            const comments = ($('pendingLeavesContainer').querySelector(`input[data-comment="${id}"]`) || {}).value || '';
            if (b.dataset.act === 'REJECT' && !comments.trim()) { alert('Please enter a comment explaining the rejection.'); return; }
            b.disabled = true;
            const res = await postLeave({ action: b.dataset.act, leaveApplicationId: id, comments: comments.trim() });
            alert(res.text);
            fetchPendingLeaves(); fetchDecidedLeaves(); loadBalances();
        });
    }

    // Queue Navigation & Batch Approval
    if ($('queueNextBtn')) {
        $('queueNextBtn').addEventListener('click', async () => {
            try {
                const nextItem = await getJson('/lpms/api/leaves/queue/next');
                if (!nextItem || !nextItem.leaveApplicationId) {
                    alert('FIFO Leave Queue is empty! All pending requests have been processed.');
                    return;
                }
                const decision = confirm(`FIFO Head Request:\nEmployee: ${nextItem.employeeName} (${nextItem.employeeCode})\nLeave: ${nextItem.leaveName} (${nextItem.totalDays} days: ${nextItem.startDate} to ${nextItem.endDate})\nReason: ${nextItem.reason}\n\nClick OK to APPROVE or Cancel to REJECT.`);
                const comment = prompt('Enter decision comment (required for rejection):', decision ? 'Approved in FIFO sequence' : 'Rejected in FIFO sequence');
                if (!decision && (!comment || !comment.trim())) { alert('Rejection requires a comment.'); return; }
                const res = await postLeave({
                    action: decision ? 'APPROVE' : 'REJECT',
                    leaveApplicationId: nextItem.leaveApplicationId,
                    comments: comment || ''
                });
                alert(res.text);
                fetchPendingLeaves(); fetchDecidedLeaves(); loadBalances();
            } catch (e) { alert(e.message); }
        });
    }

    if ($('batchApproveBtn')) {
        $('batchApproveBtn').addEventListener('click', async () => {
            const queue = await getJson('/lpms/api/leaves/queue').catch(() => []);
            if (!queue.length) {
                alert('No pending leaves to batch approve.');
                return;
            }
            if (!confirm(`Are you sure you want to batch approve all ${queue.length} pending leave requests in the queue?`)) return;
            const r = await apiFetch('/lpms/api/leaves/action', {
                method: 'POST', headers: jsonHdr,
                body: JSON.stringify({ action: 'BATCH_APPROVE', comments: 'Batch approved by manager' })
            });
            const d = await r.json();
            alert(d.message || d.error);
            fetchPendingLeaves(); fetchDecidedLeaves(); loadBalances();
        });
    }

    // ==========================================
    // 4. ATTENDANCE VIEW
    // ==========================================
    const attMsg = $('attendanceMsg');
    const attEmp = $('attEmp'), attMonth = $('attMonth');
    const hm = m => `${Math.floor(m / 60)}h ${m % 60}m`;
    const EFF = { PRESENT: 'ok', HALF_DAY: '', ON_LEAVE: '', UNPAID_LEAVE: 'off', ABSENT: 'off', UNRECORDED: 'off' };
    let attEditing = null, attDays = [], attTeamCache = [];
    const canRecordFor = () => isStaff();
    const flash = (el, r, d) => { if (!el) return; el.className = r.ok ? 'text-success' : 'text-danger'; el.textContent = d.message || d.error || 'Request failed'; };
    const attPost = async body => { const r = await apiFetch('/lpms/api/attendance/', { method: 'POST', headers: jsonHdr, body: JSON.stringify(body) }); return { r, d: await r.json().catch(() => ({})) }; };

    async function loadAttendanceView() {
        if (attMonth && !attMonth.value) attMonth.value = new Date().toISOString().slice(0, 7);
        if (isStaff() && attEmp && !attEmp.options.length) await loadAttendanceEmployees();
        loadAttToday();
        loadAttSelected();
        if (isStaff()) loadAttTeam();
        if (currentUser.role === 'HR_ADMIN') { loadPolicy(); loadHolidays(); }
    }

    async function loadAttendanceEmployees() {
        const r = await apiFetch('/lpms/api/employees?active=true');
        const list = r.ok ? await r.json() : [];
        const opts = list.filter(e => e.employeeId !== currentUser.employeeId || currentUser.role === 'HR_ADMIN')
            .map(e => `<option value="${e.employeeId}">${esc(e.employeeCode)} - ${esc(e.firstName)} ${esc(e.lastName)}</option>`).join('');
        if ($('recEmp')) $('recEmp').innerHTML = opts;
        if (attEmp) {
            attEmp.innerHTML = `<option value="${currentUser.employeeId}">Myself</option>` + list.filter(e => e.employeeId !== currentUser.employeeId)
                .map(e => `<option value="${e.employeeId}">${esc(e.employeeCode)} - ${esc(e.firstName)} ${esc(e.lastName)}</option>`).join('');
        }
        if ($('attTeamTitle')) $('attTeamTitle').textContent = currentUser.role === 'HR_ADMIN' ? 'All Employees - Monthly Summary' : 'Team Monthly Summary';
    }

    async function loadAttToday() {
        try {
            const t = await getJson('/lpms/api/attendance/today');
            const eff = t.effective || 'No data';
            $('attToday').innerHTML = `<p>${esc(new Date().toDateString())}: <span class="badge ${EFF[eff] || ''}">${esc(eff)}</span>` +
                (t.checkIn ? ` in ${esc(t.checkIn)}` : '') + (t.checkOut ? `, out ${esc(t.checkOut)}` : '') + (t.leave ? ` (${esc(t.leave)})` : '') + '</p>';
        } catch (e) { $('attToday').innerHTML = `<p class="text-danger">${esc(e.message)}</p>`; }
    }

    async function loadAttSelected() {
        const id = isStaff() && attEmp && attEmp.value ? attEmp.value : currentUser.employeeId;
        const box = $('attSummary'), hist = $('attHistory');
        if (!box || !hist) return;
        try {
            const s = await getJson(`/lpms/api/attendance/history?employeeId=${id}&month=${attMonth.value}`);
            attDays = s.days;
            box.innerHTML = `<table class="data-table"><tr><th>Working days</th><th>Present</th><th>Absent</th><th>Approved leave (paid / unpaid)</th><th>LOP</th><th>Payable days</th><th>Late marks</th><th>Worked</th><th>Overtime</th><th>Not yet recorded</th></tr>
                <tr><td>${num(s.workingDays)}</td><td>${num(s.presentDays)}</td><td>${num(s.absentDays)}</td>
                <td>${num(s.approvedLeaveDays)} (${num(s.paidLeaveDays)} / ${num(s.unpaidLeaveDays)})</td>
                <td><b>${num(s.lopDays)}</b>${s.lateLopDays > 0 ? ` (late: ${num(s.lateLopDays)})` : ''}</td><td>${num(s.payableDays)}</td>
                <td>${s.lateMarks}</td><td>${hm(s.workedMinutes)}</td><td>${hm(s.overtimeMinutes)}</td><td>${s.pendingDays + s.unrecordedDays}</td></tr></table>
                <p class="field">${esc(s.employeeName)} (${esc(s.employeeCode)}), ${esc(s.month)}${s.locked ? ' - month locked' : ''}${s.conflictDays ? ` - ${s.conflictDays} day(s) present despite approved leave` : ''}</p>`;
            const canEdit = canRecordFor() && Number(id) !== currentUser.employeeId || currentUser.role === 'HR_ADMIN';
            let h = '<table class="data-table"><tr><th>Date</th><th>Day</th><th>Status</th><th>In</th><th>Out</th><th>Worked</th><th>LOP</th><th>Notes</th>' + (canEdit ? '<th></th>' : '') + '</tr>';
            s.days.forEach((d, i) => {
                if (d.effective === 'NOT_EMPLOYED') return;
                const notes = [d.leave, d.remarks, d.late ? 'late' : '', d.conflict ? 'present on leave day' : ''].filter(Boolean).map(esc).join('; ');
                h += `<tr><td>${esc(d.date)}</td><td>${esc(d.weekday)}</td><td><span class="badge ${EFF[d.effective] || ''}">${esc(d.effective)}</span></td>
                    <td>${esc(d.checkIn || '')}</td><td>${esc(d.checkOut || '')}</td><td>${d.workedMinutes ? hm(d.workedMinutes) : ''}</td><td>${d.lop > 0 ? num(d.lop) : ''}</td><td>${notes}</td>`;
                if (canEdit) h += '<td>' + (d.attendanceId && !d.recordLocked ? `<button class="btn btn-primary btn-sm" data-act="edit" data-i="${i}">Edit</button>` : '') + '</td>';
                h += '</tr>';
            });
            hist.innerHTML = h + '</table>';
        } catch (e) { box.innerHTML = `<p class="text-danger">${esc(e.message)}</p>`; hist.innerHTML = ''; }
    }
    if (attMonth) attMonth.addEventListener('change', () => { loadAttSelected(); if (isStaff()) loadAttTeam(); });
    if (attEmp) attEmp.addEventListener('change', loadAttSelected);

    if ($('attHistory')) {
        $('attHistory').addEventListener('click', ev => {
            const b = ev.target.closest('button[data-act="edit"]');
            if (!b) return;
            const d = attDays[Number(b.dataset.i)];
            attEditing = d.attendanceId;
            $('recEmp').value = attEmp.value; $('recEmp').disabled = true;
            $('recDate').value = d.date; $('recDate').disabled = true;
            $('recStatus').value = d.recordedStatus; $('recIn').value = d.checkIn || ''; $('recOut').value = d.checkOut || ''; $('recRemarks').value = d.remarks || '';
            $('attRecTitle').textContent = 'Correct Attendance'; $('recSubmit').textContent = 'Save changes'; $('recCancel').classList.remove('hidden');
            $('attRecForm').scrollIntoView({ behavior: 'smooth' });
        });
    }

    function resetRecForm() {
        attEditing = null;
        if ($('attRecForm')) $('attRecForm').reset();
        if ($('recEmp')) $('recEmp').disabled = false;
        if ($('recDate')) $('recDate').disabled = false;
        if ($('attRecTitle')) $('attRecTitle').textContent = 'Record Attendance';
        if ($('recSubmit')) $('recSubmit').textContent = 'Record';
        if ($('recCancel')) $('recCancel').classList.add('hidden');
    }
    if ($('recCancel')) $('recCancel').addEventListener('click', resetRecForm);
    if ($('attRecForm')) {
        $('attRecForm').addEventListener('submit', async e => {
            e.preventDefault();
            const v = id => $(id).value.trim();
            const body = { status: v('recStatus'), checkIn: v('recIn'), checkOut: v('recOut'), remarks: v('recRemarks') };
            if (attEditing) { body.action = 'UPDATE'; body.attendanceId = attEditing; }
            else { body.action = 'RECORD'; body.employeeId = v('recEmp'); body.date = v('recDate'); }
            const { r, d } = await attPost(body);
            flash($('recMsg'), r, d);
            if (r.ok) { resetRecForm(); $('recMsg').className = 'text-success'; $('recMsg').textContent = d.message; loadAttSelected(); loadAttTeam(); loadAttToday(); }
        });
    }

    async function loadAttTeam() {
        const box = $('attTeam');
        if (!box) return;
        try {
            attTeamCache = await getJson('/lpms/api/attendance/team-summary?month=' + attMonth.value);
            if (!attTeamCache.length) { box.innerHTML = '<p>No employees.</p>'; return; }
            let h = '<table class="data-table"><tr><th>ID</th><th>Name</th><th>Working</th><th>Present</th><th>Absent</th><th>Leave (paid/unpaid)</th><th>LOP</th><th>Payable</th><th>Late</th><th>Unrecorded</th></tr>';
            attTeamCache.forEach(s => h += `<tr><td>${esc(s.employeeCode)}</td><td>${esc(s.employeeName)}</td><td>${num(s.workingDays)}</td><td>${num(s.presentDays)}</td><td>${num(s.absentDays)}</td>
                <td>${num(s.paidLeaveDays)} / ${num(s.unpaidLeaveDays)}</td><td><b>${num(s.lopDays)}</b></td><td>${num(s.payableDays)}</td><td>${s.lateMarks}</td><td>${s.unrecordedDays}</td></tr>`);
            box.innerHTML = h + '</table>';
        } catch (e) { box.innerHTML = `<p class="text-danger">${esc(e.message)}</p>`; }
    }

    if ($('btnCheckIn')) {
        $('btnCheckIn').addEventListener('click', async () => {
            const { r, d } = await attPost({ action: 'CHECK_IN' }); flash(attMsg, r, d); loadAttToday(); loadAttSelected();
        });
    }
    if ($('btnCheckOut')) {
        $('btnCheckOut').addEventListener('click', async () => {
            const { r, d } = await attPost({ action: 'CHECK_OUT' }); flash(attMsg, r, d); loadAttToday(); loadAttSelected();
        });
    }

    // CSV Import
    function parseCsv(text) {
        const rows = []; let row = [], cur = '', q = false;
        for (let i = 0; i < text.length; i++) {
            const c = text[i];
            if (q) { if (c === '"' && text[i + 1] === '"') { cur += '"'; i++; } else if (c === '"') q = false; else cur += c; }
            else if (c === '"') q = true;
            else if (c === ',') { row.push(cur); cur = ''; }
            else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cur); cur = ''; if (row.some(x => x.trim())) rows.push(row); row = []; }
            else cur += c;
        }
        row.push(cur); if (row.some(x => x.trim())) rows.push(row);
        return rows;
    }
    if ($('impBtn')) {
        $('impBtn').addEventListener('click', async () => {
            const f = $('impFile').files[0], msg = $('impMsg'), errs = $('impErrors');
            errs.innerHTML = '';
            if (!f) { msg.className = 'text-danger'; msg.textContent = 'Choose a CSV file.'; return; }
            const rows = parseCsv(await f.text());
            const head = (rows.shift() || []).map(x => x.trim());
            if (!['employeeCode', 'date', 'status'].every(k => head.includes(k))) { msg.className = 'text-danger'; msg.textContent = 'Header must include employeeCode, date, status.'; return; }
            const data = rows.map(r => Object.fromEntries(head.map((k, i) => [k, (r[i] || '').trim()])));
            const { r, d } = await attPost({ action: 'IMPORT', rows: data });
            if (!r.ok) { flash(msg, r, d); return; }
            msg.className = d.failed ? 'text-danger' : 'text-success';
            msg.textContent = `Imported ${d.imported}, failed ${d.failed}.`;
            if (d.failed) errs.innerHTML = '<table class="data-table"><tr><th>Row</th><th>Error</th></tr>' + d.errors.map(x => `<tr><td>${x.row}</td><td>${esc(x.error)}</td></tr>`).join('') + '</table>';
            $('impFile').value = ''; loadAttSelected(); loadAttTeam();
        });
    }

    // Attendance Policy & Lock
    async function loadPolicy() {
        try {
            const p = await getJson('/lpms/api/attendance/policy');
            $('polMissing').value = p.MISSING_DAY_TREATMENT; $('polLate').value = p.LATE_AFTER_TIME; $('polLates').value = p.LATES_PER_HALF_DAY_LOP;
            $('polStd').value = p.STANDARD_WORK_MINUTES; $('polBack').value = p.BACKDATE_LIMIT_DAYS;
        } catch (e) { if ($('polMsg')) $('polMsg').textContent = e.message; }
    }
    if ($('polForm')) {
        $('polForm').addEventListener('submit', async e => {
            e.preventDefault();
            const { r, d } = await attPost({ action: 'SAVE_POLICY', MISSING_DAY_TREATMENT: $('polMissing').value, LATE_AFTER_TIME: $('polLate').value,
                LATES_PER_HALF_DAY_LOP: $('polLates').value, STANDARD_WORK_MINUTES: $('polStd').value, BACKDATE_LIMIT_DAYS: $('polBack').value });
            flash($('polMsg'), r, d); if (r.ok) { loadAttSelected(); loadAttTeam(); }
        });
    }
    [['lockBtn', 'LOCK'], ['unlockBtn', 'UNLOCK']].forEach(([id, act]) => {
        if ($(id)) {
            $(id).addEventListener('click', async () => {
                if (!confirm(`${act === 'LOCK' ? 'Lock' : 'Unlock'} attendance for ${attMonth.value}?`)) return;
                const { r, d } = await attPost({ action: act, month: attMonth.value }); flash($('polMsg'), r, d); loadAttSelected();
            });
        }
    });

    async function loadHolidays() {
        if (!$('holYear')) return;
        if (!$('holYear').value) $('holYear').value = new Date().getFullYear();
        try {
            const l = await getJson('/lpms/api/attendance/holidays?year=' + $('holYear').value);
            $('holList').innerHTML = l.length ? '<table class="data-table"><tr><th>Date</th><th>Holiday</th><th>Action</th></tr>' + l.map(h => `<tr><td>${esc(h.date)}</td><td>${esc(h.name)}</td>
                <td><button class="btn btn-danger btn-sm" data-id="${h.holidayId}">Remove</button></td></tr>`).join('') + '</table>' : '<p>No holidays defined.</p>';
        } catch (e) { $('holList').innerHTML = `<p class="text-danger">${esc(e.message)}</p>`; }
    }
    if ($('holYear')) $('holYear').addEventListener('change', loadHolidays);
    if ($('holForm')) {
        $('holForm').addEventListener('submit', async e => {
            e.preventDefault();
            const { r, d } = await attPost({ action: 'ADD_HOLIDAY', date: $('holDate').value, name: $('holName').value.trim() });
            flash($('polMsg'), r, d); if (r.ok) { e.target.reset(); loadHolidays(); loadAttSelected(); }
        });
    }
    if ($('holList')) {
        $('holList').addEventListener('click', async ev => {
            const b = ev.target.closest('button[data-id]'); if (!b) return;
            const { r, d } = await attPost({ action: 'DELETE_HOLIDAY', holidayId: b.dataset.id });
            flash($('polMsg'), r, d); loadHolidays(); loadAttSelected();
        });
    }

    // ==========================================
    // 5. MY PAYSLIPS VIEW & MODAL
    // ==========================================
    async function loadMyPayslipsView() {
        const box = $('myPayslipsTable');
        if (!box) return;
        try {
            const slips = await getJson('/lpms/api/payroll/my-payslips');
            if (!slips.length) {
                box.innerHTML = '<p>No payslips found for your account.</p>';
                return;
            }
            let h = '<table class="data-table"><thead><tr><th>Month / Year</th><th>Days Worked</th><th>LOP Days</th><th>Gross Earnings</th><th>Total Deductions</th><th>Net Take-Home Pay</th><th>Status</th><th>Actions</th></tr></thead><tbody>';
            slips.forEach(s => {
                const monthNames = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
                const period = `${monthNames[s.payrollMonth] || s.payrollMonth} ${s.payrollYear}`;
                h += `<tr><td><strong>${period}</strong></td><td>${s.daysWorked}</td><td>${s.lopDays}</td><td>${fmtCur(s.grossEarnings)}</td><td>${fmtCur(s.totalDeductions)}</td>
                    <td><strong style="color: #15803d;">${fmtCur(s.netSalary)}</strong></td>
                    <td><span class="badge ${s.status === 'PAID' ? 'paid' : 'draft'}">${esc(s.status)}</span></td>
                    <td><button class="btn btn-primary btn-sm" data-act="view-slip" data-id="${s.employeePayrollId}">View &amp; Print Payslip</button></td></tr>`;
            });
            h += '</tbody></table>';
            box.innerHTML = h;
        } catch (e) {
            box.innerHTML = `<p class="text-danger">${esc(e.message)}</p>`;
        }
    }

    if ($('myPayslipsTable')) {
        $('myPayslipsTable').addEventListener('click', ev => {
            const b = ev.target.closest('button[data-act="view-slip"]');
            if (b) showCorporatePayslip(Number(b.dataset.id));
        });
    }

    async function showCorporatePayslip(payrollId) {
        try {
            const p = await getJson(`/lpms/api/payroll/payslip?payrollId=${payrollId}`);
            const monthNames = ['', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
            const period = `${monthNames[p.payrollMonth] || p.payrollMonth} ${p.payrollYear}`;

            // Metadata Grid
            const empName = p.employeeName || `${p.firstName || ''} ${p.lastName || ''}`.trim();
            const daysWorked = p.workingDays != null ? p.workingDays : p.daysWorked;
            $('slipMeta').innerHTML = `
                <div class="payslip-meta-row"><span class="label">Employee Name:</span><span class="val">${esc(empName)}</span></div>
                <div class="payslip-meta-row"><span class="label">Employee ID:</span><span class="val">${esc(p.employeeCode)}</span></div>
                <div class="payslip-meta-row"><span class="label">Department:</span><span class="val">${esc(p.departmentName || 'General')}</span></div>
                <div class="payslip-meta-row"><span class="label">Designation:</span><span class="val">${esc(p.designationName || 'Staff')}</span></div>
                <div class="payslip-meta-row"><span class="label">Pay Period:</span><span class="val">${period}</span></div>
                <div class="payslip-meta-row"><span class="label">Days Worked:</span><span class="val">${daysWorked} (LOP: ${p.lopDays})</span></div>
            `;

            // Filter items into Earnings & Deductions
            const earnings = p.earnings || (p.items || []).filter(i => (i.itemType || i.type) === 'EARNING');
            const deductions = p.deductions || (p.items || []).filter(i => (i.itemType || i.type) === 'DEDUCTION');

            let eHtml = '';
            earnings.forEach(i => {
                eHtml += `<tr><td>${esc(i.name || i.componentName)}</td><td class="amt">${fmtCur(i.amount)}</td></tr>`;
            });
            eHtml += `<tr class="payslip-total-row"><td>Gross Earnings</td><td class="amt">${fmtCur(p.grossEarnings)}</td></tr>`;
            $('slipEarningsTable').querySelector('tbody').innerHTML = eHtml;

            let dHtml = '';
            deductions.forEach(i => {
                dHtml += `<tr><td>${esc(i.name || i.componentName)}</td><td class="amt">${fmtCur(i.amount)}</td></tr>`;
            });
            dHtml += `<tr class="payslip-total-row"><td>Total Deductions</td><td class="amt">${fmtCur(p.totalDeductions)}</td></tr>`;
            $('slipDeductionsTable').querySelector('tbody').innerHTML = dHtml;

            $('slipNetTotal').textContent = fmtCur(p.netPay != null ? p.netPay : p.netSalary);
            $('slipStatusText').textContent = `Disbursement Status: ${p.paymentStatus || p.status || 'PAID'} | Transfer Ref #${p.employeePayrollId}`;

            $('payslipModal').classList.remove('hidden');
        } catch (e) {
            alert('Failed to load payslip: ' + e.message);
        }
    }

    if ($('btnSlipClose')) $('btnSlipClose').addEventListener('click', () => $('payslipModal').classList.add('hidden'));
    if ($('btnSlipPrint')) $('btnSlipPrint').addEventListener('click', () => window.print());

    // ==========================================
    // 6. PAYROLL MANAGEMENT VIEW (Admin)
    // ==========================================
    let cachedPayrollRuns = [];

    function switchPayrollSubTab(activeTabId) {
        const tabs = [
            { btn: $('tabPayrollRuns'), panel: $('panelPayrollRuns') },
            { btn: $('tabPayrollProcess'), panel: $('panelPayrollProcess') },
            { btn: $('tabPayrollRegister'), panel: $('panelPayrollRegister') }
        ];
        tabs.forEach(t => {
            if (t.btn && t.panel) {
                if (t.btn.id === activeTabId) {
                    t.btn.classList.add('active');
                    t.panel.classList.remove('hidden');
                } else {
                    t.btn.classList.remove('active');
                    t.panel.classList.add('hidden');
                }
            }
        });
    }

    if ($('tabPayrollRuns')) $('tabPayrollRuns').addEventListener('click', () => switchPayrollSubTab('tabPayrollRuns'));
    if ($('tabPayrollProcess')) $('tabPayrollProcess').addEventListener('click', () => switchPayrollSubTab('tabPayrollProcess'));
    if ($('tabPayrollRegister')) $('tabPayrollRegister').addEventListener('click', () => switchPayrollSubTab('tabPayrollRegister'));

    async function loadPayrollView() {
        await loadPayrollRuns();
    }

    async function loadPayrollRuns() {
        const box = $('payrollRunsTable');
        if (!box) return;
        try {
            cachedPayrollRuns = await getJson('/lpms/api/payroll/runs');
            if (!cachedPayrollRuns.length) {
                box.innerHTML = '<p>No payroll runs processed yet. Go to "Process New Payroll" tab to run payroll.</p>';
                return;
            }
            let h = '<table class="data-table"><thead><tr><th>Run #</th><th>Period</th><th>Status</th><th>Total Gross</th><th>Total Deductions</th><th>Total Net Disbursed</th><th>Processed At</th><th>Actions</th></tr></thead><tbody>';
            cachedPayrollRuns.forEach(r => {
                const monthNames = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                h += `<tr><td><strong>#${r.runId}</strong></td><td>${monthNames[r.payrollMonth] || r.payrollMonth} ${r.payrollYear}</td>
                    <td><span class="badge ${r.status === 'COMPLETED' ? 'ok' : ''}">${esc(r.status)}</span></td>
                    <td>${fmtCur(r.totalGross)}</td><td>${fmtCur(r.totalDeductions)}</td>
                    <td><strong style="color: #15803d;">${fmtCur(r.totalNet)}</strong></td>
                    <td>${esc(r.processedAt || '-')}</td>
                    <td><button class="btn btn-primary btn-sm" data-act="view-reg" data-run="${r.runId}">View Register</button></td></tr>`;
            });
            h += '</tbody></table>';
            box.innerHTML = h;

            // Update run dropdown for register
            if ($('regRunSelect')) {
                $('regRunSelect').innerHTML = cachedPayrollRuns.map(r => `<option value="${r.runId}">Run #${r.runId} (${r.payrollYear}-${r.payrollMonth}) - ${r.status}</option>`).join('');
            }
        } catch (e) {
            box.innerHTML = `<p class="text-danger">${esc(e.message)}</p>`;
        }
    }

    if ($('btnRefreshRuns')) $('btnRefreshRuns').addEventListener('click', loadPayrollRuns);

    if ($('payrollRunsTable')) {
        $('payrollRunsTable').addEventListener('click', ev => {
            const b = ev.target.closest('button[data-act="view-reg"]');
            if (b) {
                const runId = b.dataset.run;
                switchPayrollSubTab('tabPayrollRegister');
                if ($('regRunSelect')) $('regRunSelect').value = runId;
                loadPayrollRegister(runId);
            }
        });
    }

    // Process Payroll Form
    if ($('payrollForm')) {
        $('payrollForm').addEventListener('submit', async e => {
            e.preventDefault();
            const year = $('payrollYear').value;
            const month = $('payrollMonth').value;
            const notes = $('payrollNotes') ? $('payrollNotes').value : '';
            const msg = $('payrollMsg');
            msg.className = ''; msg.textContent = 'Processing payroll across all active employees...';

            try {
                const r = await apiFetch('/lpms/api/payroll/run', {
                    method: 'POST', headers: jsonHdr,
                    body: JSON.stringify({ payrollYear: year, payrollMonth: month, notes })
                });
                const d = await r.json();
                msg.className = r.ok ? 'text-success' : 'text-danger';
                msg.textContent = d.message || d.error;
                if (r.ok) {
                    await loadPayrollRuns();
                    setTimeout(() => switchPayrollSubTab('tabPayrollRuns'), 1500);
                }
            } catch (err) {
                msg.className = 'text-danger';
                msg.textContent = 'Connection error: ' + err.message;
            }
        });
    }

    // Payroll Register & MergeSort
    async function loadPayrollRegister(runId) {
        const box = $('payrollRegisterContainer');
        if (!box) return;
        if (!runId && $('regRunSelect')) runId = $('regRunSelect').value;
        if (!runId) { box.innerHTML = '<p>No payroll run selected.</p>'; return; }
        const sortBy = $('regSortSelect') ? $('regSortSelect').value : 'code';

        try {
            const list = await getJson(`/lpms/api/payroll/register?runId=${runId}&sortBy=${sortBy}`);
            if (!list.length) { box.innerHTML = '<p>No records found in this payroll run.</p>'; return; }
            let h = '<table class="data-table"><thead><tr><th>Employee ID</th><th>Employee Name</th><th>Days</th><th>LOP</th><th>Basic</th><th>Gross Earnings</th><th>PF</th><th>PT</th><th>TDS</th><th>Total Deductions</th><th>Net Salary</th><th>Payslip</th></tr></thead><tbody>';
            list.forEach(p => {
                h += `<tr><td><strong>${esc(p.employeeCode)}</strong></td><td>${esc(p.firstName)} ${esc(p.lastName)}</td>
                    <td>${p.daysWorked}</td><td>${p.lopDays}</td><td>${fmtCur(p.basicSalary)}</td>
                    <td>${fmtCur(p.grossEarnings)}</td><td>${fmtCur(p.pfDeduction)}</td><td>${fmtCur(p.professionalTax)}</td>
                    <td>${fmtCur(p.taxDeducted)}</td><td>${fmtCur(p.totalDeductions)}</td>
                    <td><strong style="color: #15803d;">${fmtCur(p.netSalary)}</strong></td>
                    <td><button class="btn btn-primary btn-sm" data-act="view-slip" data-id="${p.employeePayrollId}">View</button></td></tr>`;
            });
            h += '</tbody></table>';
            box.innerHTML = h;
        } catch (e) {
            box.innerHTML = `<p class="text-danger">${esc(e.message)}</p>`;
        }
    }

    if ($('regRunSelect')) $('regRunSelect').addEventListener('change', () => loadPayrollRegister($('regRunSelect').value));
    if ($('regSortSelect')) $('regSortSelect').addEventListener('change', () => loadPayrollRegister($('regRunSelect').value));
    if ($('payrollRegisterContainer')) {
        $('payrollRegisterContainer').addEventListener('click', ev => {
            const b = ev.target.closest('button[data-act="view-slip"]');
            if (b) showCorporatePayslip(Number(b.dataset.id));
        });
    }

    if ($('btnExportRegisterCSV')) {
        $('btnExportRegisterCSV').addEventListener('click', () => {
            const selRun = cachedPayrollRuns.find(r => String(r.runId) === String($('regRunSelect').value));
            if (!selRun) { alert('Please select a valid payroll run.'); return; }
            window.location.href = `/lpms/api/reports/payroll/export?year=${selRun.payrollYear}&month=${selRun.payrollMonth}`;
        });
    }

    // ==========================================
    // 7. REPORTS & EXPORTS VIEW
    // ==========================================
    function switchReportsSubTab(activeTabId) {
        const tabs = [
            { btn: $('tabRepPayroll'), panel: $('panelRepPayroll') },
            { btn: $('tabRepLeaves'), panel: $('panelRepLeaves') },
            { btn: $('tabRepAtt'), panel: $('panelRepAtt') }
        ];
        tabs.forEach(t => {
            if (t.btn && t.panel) {
                if (t.btn.id === activeTabId) {
                    t.btn.classList.add('active');
                    t.panel.classList.remove('hidden');
                } else {
                    t.btn.classList.remove('active');
                    t.panel.classList.add('hidden');
                }
            }
        });
    }

    if ($('tabRepPayroll')) $('tabRepPayroll').addEventListener('click', () => switchReportsSubTab('tabRepPayroll'));
    if ($('tabRepLeaves')) $('tabRepLeaves').addEventListener('click', () => switchReportsSubTab('tabRepLeaves'));
    if ($('tabRepAtt')) $('tabRepAtt').addEventListener('click', () => switchReportsSubTab('tabRepAtt'));

    async function loadReportsView() {
        if ($('repAttMonth') && !$('repAttMonth').value) $('repAttMonth').value = new Date().toISOString().slice(0, 7);
        fetchReportPayroll();
    }

    async function fetchReportPayroll() {
        const box = $('repPayContainer');
        if (!box) return;
        const year = $('repPayYear').value;
        const month = $('repPayMonth').value;
        try {
            const list = await getJson(`/lpms/api/reports/payroll?year=${year}&month=${month}`);
            if (!list.length) { box.innerHTML = '<p>No payroll data found for this period.</p>'; return; }
            let h = '<table class="data-table"><thead><tr><th>ID</th><th>Name</th><th>Dept</th><th>Worked</th><th>LOP</th><th>Gross</th><th>PF</th><th>PT</th><th>TDS</th><th>Deductions</th><th>Net</th></tr></thead><tbody>';
            list.forEach(r => {
                h += `<tr><td>${esc(r.employeeCode)}</td><td>${esc(r.firstName)} ${esc(r.lastName)}</td><td>${esc(r.departmentName)}</td>
                    <td>${r.daysWorked}</td><td>${r.lopDays}</td><td>${fmtCur(r.grossEarnings)}</td><td>${fmtCur(r.pfDeduction)}</td>
                    <td>${fmtCur(r.professionalTax)}</td><td>${fmtCur(r.taxDeducted)}</td><td>${fmtCur(r.totalDeductions)}</td>
                    <td><strong style="color:#15803d;">${fmtCur(r.netSalary)}</strong></td></tr>`;
            });
            h += '</tbody></table>';
            box.innerHTML = h;
        } catch (e) { box.innerHTML = `<p class="text-danger">${esc(e.message)}</p>`; }
    }
    if ($('btnFetchRepPay')) $('btnFetchRepPay').addEventListener('click', fetchReportPayroll);
    if ($('btnExportRepPay')) $('btnExportRepPay').addEventListener('click', () => {
        const y = $('repPayYear').value, m = $('repPayMonth').value;
        window.location.href = `/lpms/api/reports/payroll/export?year=${y}&month=${m}`;
    });

    async function fetchReportLeaves() {
        const box = $('repLeaveContainer');
        if (!box) return;
        const year = $('repLeaveYear').value;
        try {
            const list = await getJson(`/lpms/api/reports/leaves?year=${year}`);
            if (!list.length) { box.innerHTML = '<p>No leave data found for this year.</p>'; return; }
            let h = '<table class="data-table"><thead><tr><th>ID</th><th>Employee Name</th><th>Department</th><th>Leave Type</th><th>Entitlement</th><th>Used</th><th>Remaining</th><th>Pending</th></tr></thead><tbody>';
            list.forEach(r => {
                h += `<tr><td>${esc(r.employeeCode)}</td><td>${esc(r.employeeName)}</td><td>${esc(r.departmentName)}</td>
                    <td>${esc(r.leaveName)}</td><td>${r.entitlement}</td><td>${r.used}</td><td><strong>${r.remaining}</strong></td><td>${r.pending}</td></tr>`;
            });
            h += '</tbody></table>';
            box.innerHTML = h;
        } catch (e) { box.innerHTML = `<p class="text-danger">${esc(e.message)}</p>`; }
    }
    if ($('btnFetchRepLeave')) $('btnFetchRepLeave').addEventListener('click', fetchReportLeaves);
    if ($('btnExportRepLeave')) $('btnExportRepLeave').addEventListener('click', () => {
        const y = $('repLeaveYear').value;
        window.location.href = `/lpms/api/reports/leaves/export?year=${y}`;
    });

    async function fetchReportAttendance() {
        const box = $('repAttContainer');
        if (!box) return;
        const month = $('repAttMonth').value;
        try {
            const list = await getJson(`/lpms/api/reports/attendance?month=${month}`);
            if (!list.length) { box.innerHTML = '<p>No attendance data found for this month.</p>'; return; }
            let h = '<table class="data-table"><thead><tr><th>ID</th><th>Employee Name</th><th>Department</th><th>Working</th><th>Present</th><th>Absent</th><th>Paid Leave</th><th>Unpaid Leave</th><th>LOP Days</th><th>Payable Days</th><th>Late Marks</th></tr></thead><tbody>';
            list.forEach(r => {
                h += `<tr><td>${esc(r.employeeCode)}</td><td>${esc(r.employeeName)}</td><td>${esc(r.departmentName)}</td>
                    <td>${r.workingDays}</td><td>${r.presentDays}</td><td>${r.absentDays}</td><td>${r.paidLeaveDays}</td><td>${r.unpaidLeaveDays}</td>
                    <td><strong style="color:#991b1b;">${r.lopDays}</strong></td><td>${r.payableDays}</td><td>${r.lateMarks}</td></tr>`;
            });
            h += '</tbody></table>';
            box.innerHTML = h;
        } catch (e) { box.innerHTML = `<p class="text-danger">${esc(e.message)}</p>`; }
    }
    if ($('btnFetchRepAtt')) $('btnFetchRepAtt').addEventListener('click', fetchReportAttendance);
    if ($('btnExportRepAtt')) $('btnExportRepAtt').addEventListener('click', () => {
        const m = $('repAttMonth').value;
        window.location.href = `/lpms/api/reports/attendance/export?month=${m}`;
    });

    // ==========================================
    // 8. ADMINISTRATION VIEW (HR Admin)
    // ==========================================
    function switchAdminSubTab(activeTabId) {
        const tabs = [
            { btn: $('tabAdminDepts'), panel: $('panelAdminDepts') },
            { btn: $('tabAdminDesigs'), panel: $('panelAdminDesigs') },
            { btn: $('tabAdminLeaves'), panel: $('panelAdminLeaves') },
            { btn: $('tabAdminComps'), panel: $('panelAdminComps') },
            { btn: $('tabAdminTax'), panel: $('panelAdminTax') },
            { btn: $('tabAdminSalary'), panel: $('panelAdminSalary') },
            { btn: $('tabAdminAudit'), panel: $('panelAdminAudit') }
        ];
        tabs.forEach(t => {
            if (t.btn && t.panel) {
                if (t.btn.id === activeTabId) {
                    t.btn.classList.add('active');
                    t.panel.classList.remove('hidden');
                } else {
                    t.btn.classList.remove('active');
                    t.panel.classList.add('hidden');
                }
            }
        });
    }

    if ($('tabAdminDepts')) $('tabAdminDepts').addEventListener('click', () => { switchAdminSubTab('tabAdminDepts'); loadAdminDepts(); });
    if ($('tabAdminDesigs')) $('tabAdminDesigs').addEventListener('click', () => { switchAdminSubTab('tabAdminDesigs'); loadAdminDesigs(); });
    if ($('tabAdminLeaves')) $('tabAdminLeaves').addEventListener('click', () => { switchAdminSubTab('tabAdminLeaves'); loadAdminLeaves(); });
    if ($('tabAdminComps')) $('tabAdminComps').addEventListener('click', () => { switchAdminSubTab('tabAdminComps'); loadAdminComps(); });
    if ($('tabAdminTax')) $('tabAdminTax').addEventListener('click', () => { switchAdminSubTab('tabAdminTax'); loadAdminTax(); });
    if ($('tabAdminSalary')) $('tabAdminSalary').addEventListener('click', () => { switchAdminSubTab('tabAdminSalary'); loadAdminSalaryStructures(); });
    if ($('tabAdminAudit')) $('tabAdminAudit').addEventListener('click', () => { switchAdminSubTab('tabAdminAudit'); loadAdminAudit(); });

    async function loadAdminView() {
        await loadAdminDepts();
    }

    // A. Departments CRUD
    let editingDeptId = null;
    async function loadAdminDepts() {
        const box = $('adminDeptsTable');
        if (!box) return;
        try {
            const list = await getJson('/lpms/api/admin/departments');
            let h = '<table class="data-table"><thead><tr><th>ID</th><th>Code</th><th>Name</th><th>Created At</th><th>Actions</th></tr></thead><tbody>';
            list.forEach(d => {
                h += `<tr><td>${d.departmentId}</td><td><strong>${esc(d.departmentCode)}</strong></td><td>${esc(d.departmentName)}</td><td>${esc(d.createdAt)}</td>
                    <td><button class="btn btn-primary btn-sm" data-act="edit-dept" data-id="${d.departmentId}" data-code="${esc(d.departmentCode)}" data-name="${esc(d.departmentName)}">Edit</button>
                    <button class="btn btn-danger btn-sm" data-act="del-dept" data-id="${d.departmentId}">Delete</button></td></tr>`;
            });
            h += '</tbody></table>';
            box.innerHTML = h;
        } catch (e) { box.innerHTML = `<p class="text-danger">${esc(e.message)}</p>`; }
    }

    if ($('adminDeptForm')) {
        $('adminDeptForm').addEventListener('submit', async e => {
            e.preventDefault();
            const id = $('adminDeptId').value;
            const body = { departmentCode: $('adminDeptCode').value.trim(), departmentName: $('adminDeptName').value.trim() };
            const r = await apiFetch('/lpms/api/admin/departments' + (id ? `?id=${id}` : ''), {
                method: id ? 'PUT' : 'POST', headers: jsonHdr, body: JSON.stringify(body)
            });
            const d = await r.json();
            alert(d.message || d.error);
            if (r.ok) { $('adminDeptForm').reset(); $('adminDeptId').value = ''; $('adminDeptCancel').classList.add('hidden'); loadAdminDepts(); }
        });
        $('adminDeptCancel').addEventListener('click', () => {
            $('adminDeptForm').reset(); $('adminDeptId').value = ''; $('adminDeptCancel').classList.add('hidden');
        });
    }

    if ($('adminDeptsTable')) {
        $('adminDeptsTable').addEventListener('click', async ev => {
            const b = ev.target.closest('button[data-act]');
            if (!b) return;
            const id = b.dataset.id;
            if (b.dataset.act === 'edit-dept') {
                $('adminDeptId').value = id;
                $('adminDeptCode').value = b.dataset.code;
                $('adminDeptName').value = b.dataset.name;
                $('adminDeptCancel').classList.remove('hidden');
            } else if (b.dataset.act === 'del-dept') {
                if (!confirm('Delete department #' + id + '?')) return;
                const r = await apiFetch(`/lpms/api/admin/departments?id=${id}`, { method: 'DELETE' });
                const d = await r.json();
                alert(d.message || d.error);
                loadAdminDepts();
            }
        });
    }

    // B. Designations CRUD
    async function loadAdminDesigs() {
        const box = $('adminDesigsTable');
        if (!box) return;
        try {
            const list = await getJson('/lpms/api/admin/designations');
            let h = '<table class="data-table"><thead><tr><th>ID</th><th>Title</th><th>Grade / Level</th><th>Actions</th></tr></thead><tbody>';
            list.forEach(d => {
                h += `<tr><td>${d.designationId}</td><td><strong>${esc(d.title)}</strong></td><td>${esc(d.gradeLevel || '-')}</td>
                    <td><button class="btn btn-primary btn-sm" data-act="edit-desig" data-id="${d.designationId}" data-title="${esc(d.title)}" data-grade="${esc(d.gradeLevel || '')}">Edit</button>
                    <button class="btn btn-danger btn-sm" data-act="del-desig" data-id="${d.designationId}">Delete</button></td></tr>`;
            });
            h += '</tbody></table>';
            box.innerHTML = h;
        } catch (e) { box.innerHTML = `<p class="text-danger">${esc(e.message)}</p>`; }
    }

    if ($('adminDesigForm')) {
        $('adminDesigForm').addEventListener('submit', async e => {
            e.preventDefault();
            const id = $('adminDesigId').value;
            const body = { title: $('adminDesigTitle').value.trim(), gradeLevel: $('adminDesigGrade').value.trim() };
            const r = await apiFetch('/lpms/api/admin/designations' + (id ? `?id=${id}` : ''), {
                method: id ? 'PUT' : 'POST', headers: jsonHdr, body: JSON.stringify(body)
            });
            const d = await r.json();
            alert(d.message || d.error);
            if (r.ok) { $('adminDesigForm').reset(); $('adminDesigId').value = ''; $('adminDesigCancel').classList.add('hidden'); loadAdminDesigs(); }
        });
        $('adminDesigCancel').addEventListener('click', () => {
            $('adminDesigForm').reset(); $('adminDesigId').value = ''; $('adminDesigCancel').classList.add('hidden');
        });
    }

    if ($('adminDesigsTable')) {
        $('adminDesigsTable').addEventListener('click', async ev => {
            const b = ev.target.closest('button[data-act]');
            if (!b) return;
            const id = b.dataset.id;
            if (b.dataset.act === 'edit-desig') {
                $('adminDesigId').value = id;
                $('adminDesigTitle').value = b.dataset.title;
                $('adminDesigGrade').value = b.dataset.grade;
                $('adminDesigCancel').classList.remove('hidden');
            } else if (b.dataset.act === 'del-desig') {
                if (!confirm('Delete designation #' + id + '?')) return;
                const r = await apiFetch(`/lpms/api/admin/designations?id=${id}`, { method: 'DELETE' });
                const d = await r.json();
                alert(d.message || d.error);
                loadAdminDesigs();
            }
        });
    }

    // C. Leave Types CRUD
    async function loadAdminLeaves() {
        const box = $('adminLeaveTypesTable');
        if (!box) return;
        try {
            const list = await getJson('/lpms/api/admin/leave-types');
            let h = '<table class="data-table"><thead><tr><th>ID</th><th>Code</th><th>Name</th><th>Days/Year</th><th>Paid</th><th>Carry Forward</th><th>Actions</th></tr></thead><tbody>';
            list.forEach(t => {
                h += `<tr><td>${t.leaveTypeId}</td><td><strong>${esc(t.leaveCode)}</strong></td><td>${esc(t.leaveName)}</td><td>${t.daysAllowedPerYear}</td>
                    <td><span class="badge ${t.isPaid ? 'ok' : 'off'}">${t.isPaid ? 'Paid' : 'Unpaid'}</span></td>
                    <td>${t.carryForward ? 'Yes' : 'No'}</td>
                    <td><button class="btn btn-primary btn-sm" data-act="edit-leave" data-id="${t.leaveTypeId}" data-code="${esc(t.leaveCode)}" data-name="${esc(t.leaveName)}" data-days="${t.daysAllowedPerYear}" data-paid="${t.isPaid}" data-carry="${t.carryForward}">Edit</button>
                    <button class="btn btn-danger btn-sm" data-act="del-leave" data-id="${t.leaveTypeId}">Delete</button></td></tr>`;
            });
            h += '</tbody></table>';
            box.innerHTML = h;
        } catch (e) { box.innerHTML = `<p class="text-danger">${esc(e.message)}</p>`; }
    }

    if ($('adminLeaveTypeForm')) {
        $('adminLeaveTypeForm').addEventListener('submit', async e => {
            e.preventDefault();
            const id = $('adminLeaveTypeId').value;
            const body = {
                leaveCode: $('adminLeaveCode').value.trim(),
                leaveName: $('adminLeaveName').value.trim(),
                daysAllowedPerYear: Number($('adminLeaveDays').value),
                isPaid: $('adminLeavePaid').checked,
                carryForward: $('adminLeaveCarry').checked
            };
            const r = await apiFetch('/lpms/api/admin/leave-types' + (id ? `?id=${id}` : ''), {
                method: id ? 'PUT' : 'POST', headers: jsonHdr, body: JSON.stringify(body)
            });
            const d = await r.json();
            alert(d.message || d.error);
            if (r.ok) { $('adminLeaveTypeForm').reset(); $('adminLeaveTypeId').value = ''; $('adminLeaveCancel').classList.add('hidden'); loadAdminLeaves(); }
        });
        $('adminLeaveCancel').addEventListener('click', () => {
            $('adminLeaveTypeForm').reset(); $('adminLeaveTypeId').value = ''; $('adminLeaveCancel').classList.add('hidden');
        });
    }

    if ($('adminLeaveTypesTable')) {
        $('adminLeaveTypesTable').addEventListener('click', async ev => {
            const b = ev.target.closest('button[data-act]');
            if (!b) return;
            const id = b.dataset.id;
            if (b.dataset.act === 'edit-leave') {
                $('adminLeaveTypeId').value = id;
                $('adminLeaveCode').value = b.dataset.code;
                $('adminLeaveName').value = b.dataset.name;
                $('adminLeaveDays').value = b.dataset.days;
                $('adminLeavePaid').checked = b.dataset.paid === 'true';
                $('adminLeaveCarry').checked = b.dataset.carry === 'true';
                $('adminLeaveCancel').classList.remove('hidden');
            } else if (b.dataset.act === 'del-leave') {
                if (!confirm('Delete leave type #' + id + '?')) return;
                const r = await apiFetch(`/lpms/api/admin/leave-types?id=${id}`, { method: 'DELETE' });
                const d = await r.json();
                alert(d.message || d.error);
                loadAdminLeaves();
            }
        });
    }

    // D. Salary Components CRUD
    async function loadAdminComps() {
        const box = $('adminCompsTable');
        if (!box) return;
        try {
            const list = await getJson('/lpms/api/admin/salary-components');
            let h = '<table class="data-table"><thead><tr><th>ID</th><th>Code</th><th>Name</th><th>Type</th><th>Calculation</th><th>Default Value</th><th>Taxable</th><th>Actions</th></tr></thead><tbody>';
            list.forEach(c => {
                h += `<tr><td>${c.componentId}</td><td><strong>${esc(c.componentCode)}</strong></td><td>${esc(c.componentName)}</td>
                    <td><span class="badge ${c.componentType === 'EARNING' ? 'ok' : 'off'}">${esc(c.componentType)}</span></td>
                    <td>${esc(c.calculationType)}</td><td>${c.defaultValue}</td><td>${c.isTaxable ? 'Yes' : 'No'}</td>
                    <td><button class="btn btn-primary btn-sm" data-act="edit-comp" data-id="${c.componentId}" data-code="${esc(c.componentCode)}" data-name="${esc(c.componentName)}" data-type="${c.componentType}" data-calc="${c.calculationType}" data-val="${c.defaultValue}" data-tax="${c.isTaxable}">Edit</button>
                    <button class="btn btn-danger btn-sm" data-act="del-comp" data-id="${c.componentId}">Delete</button></td></tr>`;
            });
            h += '</tbody></table>';
            box.innerHTML = h;
        } catch (e) { box.innerHTML = `<p class="text-danger">${esc(e.message)}</p>`; }
    }

    if ($('adminCompForm')) {
        $('adminCompForm').addEventListener('submit', async e => {
            e.preventDefault();
            const id = $('adminCompId').value;
            const body = {
                componentCode: $('adminCompCode').value.trim(),
                componentName: $('adminCompName').value.trim(),
                componentType: $('adminCompType').value,
                calculationType: $('adminCompCalc').value,
                defaultValue: Number($('adminCompVal').value),
                isTaxable: $('adminCompTaxable').checked
            };
            const r = await apiFetch('/lpms/api/admin/salary-components' + (id ? `?id=${id}` : ''), {
                method: id ? 'PUT' : 'POST', headers: jsonHdr, body: JSON.stringify(body)
            });
            const d = await r.json();
            alert(d.message || d.error);
            if (r.ok) { $('adminCompForm').reset(); $('adminCompId').value = ''; $('adminCompCancel').classList.add('hidden'); loadAdminComps(); }
        });
        $('adminCompCancel').addEventListener('click', () => {
            $('adminCompForm').reset(); $('adminCompId').value = ''; $('adminCompCancel').classList.add('hidden');
        });
    }

    if ($('adminCompsTable')) {
        $('adminCompsTable').addEventListener('click', async ev => {
            const b = ev.target.closest('button[data-act]');
            if (!b) return;
            const id = b.dataset.id;
            if (b.dataset.act === 'edit-comp') {
                $('adminCompId').value = id;
                $('adminCompCode').value = b.dataset.code;
                $('adminCompName').value = b.dataset.name;
                $('adminCompType').value = b.dataset.type;
                $('adminCompCalc').value = b.dataset.calc;
                $('adminCompVal').value = b.dataset.val;
                $('adminCompTaxable').checked = b.dataset.tax === 'true';
                $('adminCompCancel').classList.remove('hidden');
            } else if (b.dataset.act === 'del-comp') {
                if (!confirm('Delete component #' + id + '?')) return;
                const r = await apiFetch(`/lpms/api/admin/salary-components?id=${id}`, { method: 'DELETE' });
                const d = await r.json();
                alert(d.message || d.error);
                loadAdminComps();
            }
        });
    }

    // E. Tax Slabs (TDS)
    async function loadAdminTax() {
        const box = $('adminTaxTable');
        if (!box) return;
        const fy = $('adminTaxFy').value.trim() || '2025-2026';
        try {
            const list = await getJson(`/lpms/api/admin/tax-slabs?financialYear=${fy}`);
            let h = '<table class="data-table"><thead><tr><th>ID</th><th>FY</th><th>Min Income (₹)</th><th>Max Income (₹)</th><th>Rate %</th><th>Description</th><th>Action</th></tr></thead><tbody>';
            list.forEach(t => {
                h += `<tr><td>${t.slabId}</td><td>${esc(t.financialYear)}</td><td>${fmtCur(t.minIncome)}</td><td>${t.maxIncome ? fmtCur(t.maxIncome) : 'No Upper Limit'}</td>
                    <td><strong>${t.taxRate}%</strong></td><td>${esc(t.description || '-')}</td>
                    <td><button class="btn btn-danger btn-sm" data-act="del-tax" data-id="${t.slabId}">Delete</button></td></tr>`;
            });
            h += '</tbody></table>';
            box.innerHTML = h;
        } catch (e) { box.innerHTML = `<p class="text-danger">${esc(e.message)}</p>`; }
    }

    if ($('adminTaxForm')) {
        $('adminTaxForm').addEventListener('submit', async e => {
            e.preventDefault();
            const body = {
                financialYear: $('adminTaxFy').value.trim(),
                minIncome: Number($('adminTaxMin').value),
                maxIncome: $('adminTaxMax').value ? Number($('adminTaxMax').value) : null,
                taxRate: Number($('adminTaxRate').value),
                description: $('adminTaxDesc').value.trim()
            };
            const r = await apiFetch('/lpms/api/admin/tax-slabs', {
                method: 'POST', headers: jsonHdr, body: JSON.stringify(body)
            });
            const d = await r.json();
            alert(d.message || d.error);
            if (r.ok) { $('adminTaxMin').value = ''; $('adminTaxMax').value = ''; $('adminTaxRate').value = ''; $('adminTaxDesc').value = ''; loadAdminTax(); }
        });
    }

    if ($('adminTaxTable')) {
        $('adminTaxTable').addEventListener('click', async ev => {
            const b = ev.target.closest('button[data-act="del-tax"]');
            if (!b) return;
            const id = b.dataset.id;
            if (!confirm('Delete tax slab #' + id + '?')) return;
            const r = await apiFetch(`/lpms/api/admin/tax-slabs?id=${id}`, { method: 'DELETE' });
            const d = await r.json();
            alert(d.message || d.error);
            loadAdminTax();
        });
    }

    // F. Employee Salary Structure Assignment
    let availableComponents = [];
    async function loadAdminSalaryStructures() {
        const empSel = $('adminSalEmpSelect');
        if (!empSel) return;
        try {
            availableComponents = await getJson('/lpms/api/admin/salary-components');
            const emps = await getJson('/lpms/api/employees?active=true');
            empSel.innerHTML = emps.map(e => `<option value="${e.employeeId}">${esc(e.employeeCode)} - ${esc(e.firstName)} ${esc(e.lastName)}</option>`).join('');
            if (emps.length) loadEmployeeStructure(emps[0].employeeId);
        } catch (e) { alert(e.message); }
    }

    async function loadEmployeeStructure(employeeId) {
        const box = $('adminSalComponentsList');
        if (!box) return;
        try {
            const struct = await getJson(`/lpms/api/admin/salary-structures?employeeId=${employeeId}`);
            $('adminSalCtc').value = struct.annualCtc || 0;
            $('adminSalBasic').value = struct.monthlyBasic || 0;

            const assignedMap = {};
            (struct.components || []).forEach(c => { assignedMap[c.componentId] = c.monthlyAmount; });

            let h = '<table class="data-table"><thead><tr><th>Component</th><th>Type</th><th>Calc Mode</th><th>Assigned Monthly Amount (₹)</th></tr></thead><tbody>';
            availableComponents.forEach(c => {
                const curVal = assignedMap[c.componentId] != null ? assignedMap[c.componentId] : c.defaultValue;
                h += `<tr><td><strong>${esc(c.componentName)} (${esc(c.componentCode)})</strong></td>
                    <td><span class="badge ${c.componentType === 'EARNING' ? 'ok' : 'off'}">${esc(c.componentType)}</span></td>
                    <td>${esc(c.calculationType)}</td>
                    <td><input type="number" step="0.01" class="form-control" style="max-width:180px;" data-comp-id="${c.componentId}" value="${curVal}"></td></tr>`;
            });
            h += '</tbody></table>';
            box.innerHTML = h;
        } catch (e) { box.innerHTML = `<p class="text-danger">${esc(e.message)}</p>`; }
    }

    if ($('adminSalEmpSelect')) {
        $('adminSalEmpSelect').addEventListener('change', () => loadEmployeeStructure($('adminSalEmpSelect').value));
    }

    if ($('adminSalaryForm')) {
        $('adminSalaryForm').addEventListener('submit', async e => {
            e.preventDefault();
            const employeeId = $('adminSalEmpSelect').value;
            const annualCtc = Number($('adminSalCtc').value);
            const monthlyBasic = Number($('adminSalBasic').value);
            const components = [];
            $('adminSalComponentsList').querySelectorAll('input[data-comp-id]').forEach(inp => {
                components.push({
                    componentId: Number(inp.dataset.compId),
                    monthlyAmount: Number(inp.value)
                });
            });
            const r = await apiFetch('/lpms/api/admin/salary-structures', {
                method: 'POST', headers: jsonHdr,
                body: JSON.stringify({ employeeId, annualCtc, monthlyBasic, components })
            });
            const d = await r.json();
            const msg = $('adminSalMsg');
            msg.className = r.ok ? 'text-success' : 'text-danger';
            msg.textContent = d.message || d.error;
        });
    }

    // G. Audit Trail
    async function loadAdminAudit() {
        const box = $('adminAuditTable');
        if (!box) return;
        try {
            const logs = await getJson('/lpms/api/admin/audit?limit=100');
            if (!logs.length) { box.innerHTML = '<p>No audit trail logs recorded yet.</p>'; return; }
            let h = '<table class="data-table"><thead><tr><th>Timestamp</th><th>User</th><th>Action</th><th>Entity</th><th>Entity ID</th><th>IP Address</th></tr></thead><tbody>';
            logs.forEach(l => {
                h += `<tr><td>${esc(l.createdAt)}</td><td><strong>${esc(l.performedBy || 'System')}</strong></td>
                    <td><span class="badge ${l.action.includes('DELETE') ? 'off' : l.action.includes('INSERT') || l.action.includes('APPROVE') ? 'ok' : ''}">${esc(l.action)}</span></td>
                    <td>${esc(l.entityName)}</td><td>${esc(l.entityId || '-')}</td><td>${esc(l.ipAddress || '-')}</td></tr>`;
            });
            h += '</tbody></table>';
            box.innerHTML = h;
        } catch (e) { box.innerHTML = `<p class="text-danger">${esc(e.message)}</p>`; }
    }
    if ($('btnRefreshAudit')) $('btnRefreshAudit').addEventListener('click', loadAdminAudit);

});
