(function () {
    const err = document.getElementById('loginError');
    const uInp = document.getElementById('username');
    const pInp = document.getElementById('password');
    const H = { 'Content-Type': 'application/json', 'X-Requested-With': 'LPMS' };

    // Already logged in? Go straight to the app.
    fetch('/lpms/api/auth/me').then(r => { if (r.ok) location.replace('index.html'); }).catch(() => {});

    // Demo fill helpers
    const setDemo = (u, p) => {
        if (uInp) uInp.value = u;
        if (pInp) pInp.value = p;
        if (err) err.textContent = '';
    };

    const btnAdmin = document.getElementById('btnDemoAdmin');
    if (btnAdmin) btnAdmin.onclick = () => setDemo('admin', 'Admin@123');

    const btnMgr = document.getElementById('btnDemoManager');
    if (btnMgr) btnMgr.onclick = () => setDemo('manager', 'Admin@123');

    const btnEmp = document.getElementById('btnDemoEmployee');
    if (btnEmp) btnEmp.onclick = () => setDemo('employee', 'Admin@123');

    document.getElementById('loginForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        err.textContent = '';
        try {
            const r = await fetch('/lpms/api/auth/login', {
                method: 'POST', headers: H,
                body: JSON.stringify({
                    username: uInp.value.trim(),
                    password: pInp.value
                })
            });
            const data = await r.json();
            if (r.ok) location.replace('index.html');
            else err.textContent = data.error || 'Login failed';
        } catch (x) {
            err.textContent = 'Server connection error';
        }
    });
})();
