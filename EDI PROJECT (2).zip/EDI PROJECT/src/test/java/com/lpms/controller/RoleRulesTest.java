package com.lpms.controller;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RoleRulesTest {
    @Test
    void payrollAndReferenceAreHrOnly() {
        assertTrue(AuthenticationFilter.allowed("/api/payroll/run", "HR_ADMIN"));
        assertFalse(AuthenticationFilter.allowed("/api/payroll/run", "MANAGER"));
        assertFalse(AuthenticationFilter.allowed("/api/payroll/run", "EMPLOYEE"));
        assertFalse(AuthenticationFilter.allowed("/api/reference", "MANAGER"));
        assertFalse(AuthenticationFilter.allowed("/api/admin/x", "EMPLOYEE"));
    }

    @Test
    void managerPathsAllowManagerAndHr() {
        assertTrue(AuthenticationFilter.allowed("/api/manager/x", "MANAGER"));
        assertTrue(AuthenticationFilter.allowed("/api/manager/x", "HR_ADMIN"));
        assertFalse(AuthenticationFilter.allowed("/api/manager/x", "EMPLOYEE"));
    }

    @Test
    void selfServicePathsOpenToAll() {
        assertTrue(AuthenticationFilter.allowed("/api/attendance/mark", "EMPLOYEE"));
        assertTrue(AuthenticationFilter.allowed("/api/leaves/apply", "EMPLOYEE"));
    }
}
