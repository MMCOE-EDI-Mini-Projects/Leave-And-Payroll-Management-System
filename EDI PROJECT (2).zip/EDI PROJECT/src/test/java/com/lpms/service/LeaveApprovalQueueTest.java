package com.lpms.service;

import com.google.gson.JsonObject;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class LeaveApprovalQueueTest {

    @Test
    void testQueueFifoOrder() {
        LeaveApprovalQueue queue = new LeaveApprovalQueue();
        assertTrue(queue.isEmpty());

        JsonObject app1 = new JsonObject();
        app1.addProperty("leaveApplicationId", 101L);
        app1.addProperty("reason", "Vacation");

        JsonObject app2 = new JsonObject();
        app2.addProperty("leaveApplicationId", 102L);
        app2.addProperty("reason", "Medical");

        JsonObject app3 = new JsonObject();
        app3.addProperty("leaveApplicationId", 103L);
        app3.addProperty("reason", "Family emergency");

        queue.enqueue(app1);
        queue.enqueue(app2);
        queue.enqueue(app3);

        assertEquals(3, queue.size());
        assertEquals(101L, queue.peekNext().get("leaveApplicationId").getAsLong());

        JsonObject polled1 = queue.pollNext();
        assertEquals(101L, polled1.get("leaveApplicationId").getAsLong());
        assertEquals(2, queue.size());

        JsonObject polled2 = queue.pollNext();
        assertEquals(102L, polled2.get("leaveApplicationId").getAsLong());

        // Deque operation: requeue polled2 at head
        queue.requeueAtHead(polled2);
        assertEquals(2, queue.size());
        assertEquals(102L, queue.peekNext().get("leaveApplicationId").getAsLong());

        JsonObject polledAgain = queue.pollNext();
        assertEquals(102L, polledAgain.get("leaveApplicationId").getAsLong());

        JsonObject polled3 = queue.pollNext();
        assertEquals(103L, polled3.get("leaveApplicationId").getAsLong());

        assertTrue(queue.isEmpty());
    }

    @Test
    void testInitialListLoading() {
        List<JsonObject> list = new ArrayList<>();
        JsonObject a = new JsonObject(); a.addProperty("leaveApplicationId", 1L);
        JsonObject b = new JsonObject(); b.addProperty("leaveApplicationId", 2L);
        list.add(a);
        list.add(b);

        LeaveApprovalQueue queue = new LeaveApprovalQueue(list);
        assertEquals(2, queue.size());
        assertEquals(1L, queue.pollNext().get("leaveApplicationId").getAsLong());
        assertEquals(2L, queue.pollNext().get("leaveApplicationId").getAsLong());
        assertTrue(queue.isEmpty());
    }
}
