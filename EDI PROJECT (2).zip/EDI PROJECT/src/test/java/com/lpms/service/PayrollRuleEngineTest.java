package com.lpms.service;

import com.lpms.model.EmployeeSalaryDetail;
import com.lpms.model.SalaryComponent;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;

class PayrollRuleEngineTest {

    private PayrollRuleEngine engine;

    @BeforeEach
    void setUp() {
        engine = new PayrollRuleEngine();
    }

    @Test
    void testCalculateFlatComponent() {
        SalaryComponent component = new SalaryComponent();
        component.setCalculationMethod("FLAT");
        
        EmployeeSalaryDetail detail = new EmployeeSalaryDetail();
        detail.setComponentValue(new BigDecimal("2000.00")); // e.g., Flat 2000 allowance

        BigDecimal result = engine.calculateComponentAmount(component, detail, new BigDecimal("50000.00"));
        assertEquals(new BigDecimal("2000.00"), result);
    }

    @Test
    void testCalculatePercentageComponent() {
        SalaryComponent component = new SalaryComponent();
        component.setCalculationMethod("PERCENTAGE");
        
        EmployeeSalaryDetail detail = new EmployeeSalaryDetail();
        detail.setComponentValue(new BigDecimal("12.00")); // e.g., 12% PF

        // 12% of 50000 = 6000
        BigDecimal result = engine.calculateComponentAmount(component, detail, new BigDecimal("50000.00"));
        assertEquals(new BigDecimal("6000.00"), result);
    }

    @Test
    void testCalculateLopDeduction() {
        // Gross: 60000, Working Days: 30, LOP: 2 days. 
        // per day = 2000. 2 days = 4000
        BigDecimal gross = new BigDecimal("60000.00");
        BigDecimal workingDays = new BigDecimal("30");
        BigDecimal lopDays = new BigDecimal("2");

        BigDecimal result = engine.calculateLopDeduction(gross, workingDays, lopDays);
        assertEquals(new BigDecimal("4000.00"), result);
    }

    @Test
    void testCalculateOvertime() {
        // Gross: 48000, 20 working days, 120 overtime minutes (2 hours).
        // Standard hours: 20 * 8 = 160 hours. Hourly rate: 48000 / 160 = 300/hr.
        // Overtime at 1.5x multiplier: 2 hours * 300 * 1.5 = 900.00
        BigDecimal gross = new BigDecimal("48000.00");
        BigDecimal workingDays = new BigDecimal("20");
        int overtimeMinutes = 120;
        BigDecimal multiplier = new BigDecimal("1.50");

        BigDecimal ot = engine.calculateOvertimePay(gross, workingDays, overtimeMinutes, multiplier);
        assertEquals(new BigDecimal("900.00"), ot);
    }

    @Test
    void testCalculateArrears() {
        // Revised: 60000, Previous: 50000, 3 months effective.
        // Difference: 10000 * 3 = 30000.00
        BigDecimal revised = new BigDecimal("60000.00");
        BigDecimal prev = new BigDecimal("50000.00");

        BigDecimal arrears = engine.calculateArrears(revised, prev, 3);
        assertEquals(new BigDecimal("30000.00"), arrears);
    }

    @Test
    void testCalculateTaxSlabs() {
        java.util.List<com.lpms.model.TaxSlab> slabs = new java.util.ArrayList<>();

        com.lpms.model.TaxSlab s1 = new com.lpms.model.TaxSlab();
        s1.setLowerLimit(BigDecimal.ZERO);
        s1.setUpperLimit(new BigDecimal("300000.00"));
        s1.setTaxRate(BigDecimal.ZERO);
        s1.setCessRate(new BigDecimal("4.00"));
        slabs.add(s1);

        com.lpms.model.TaxSlab s2 = new com.lpms.model.TaxSlab();
        s2.setLowerLimit(new BigDecimal("300000.00"));
        s2.setUpperLimit(new BigDecimal("700000.00"));
        s2.setTaxRate(new BigDecimal("5.00"));
        s2.setCessRate(new BigDecimal("4.00"));
        slabs.add(s2);

        // Taxable income = 500,000. Tax on 200,000 @ 5% = 10,000. Cess 4% = 400. Total = 10,400.00
        BigDecimal income = new BigDecimal("500000.00");
        BigDecimal annualTax = engine.calculateAnnualTax(income, slabs);
        assertEquals(new BigDecimal("10400.00"), annualTax);

        // Monthly TDS = 10400 / 12 = 866.67
        BigDecimal monthlyTds = engine.calculateMonthlyTds(income, slabs);
        assertEquals(new BigDecimal("866.67"), monthlyTds);
    }
}
