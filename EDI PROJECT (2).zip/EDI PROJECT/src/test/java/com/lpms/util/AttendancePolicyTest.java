package com.lpms.util;

import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class AttendancePolicyTest {
    @Test
    void defaultsApplyWhenNothingStored() {
        AttendancePolicy p = new AttendancePolicy();
        assertTrue(p.missingDayIsAbsent());
        assertEquals(0, p.latesPerHalfDay());
        assertEquals(480, p.standardMinutes());
        assertEquals(31, p.backdateLimitDays());
    }

    @Test
    void validatesKeysAndValues() {
        assertNull(AttendancePolicy.validate(AttendancePolicy.MISSING_DAY, "IGNORE"));
        assertNotNull(AttendancePolicy.validate(AttendancePolicy.MISSING_DAY, "MAYBE"));
        assertNull(AttendancePolicy.validate(AttendancePolicy.LATE_AFTER, "09:45"));
        assertNotNull(AttendancePolicy.validate(AttendancePolicy.LATE_AFTER, "25:99"));
        assertNotNull(AttendancePolicy.validate(AttendancePolicy.LATES_PER_HALF, "-1"));
        assertNotNull(AttendancePolicy.validate(AttendancePolicy.STD_MINUTES, "abc"));
        assertNotNull(AttendancePolicy.validate("LOCK:2026-10", "Y")); // lock rows are not policy values
        assertNotNull(AttendancePolicy.validate("BOGUS", "1"));
    }

    @Test
    void invalidStoredValuesFallBackToDefaults() {
        AttendancePolicy p = AttendancePolicy.of(Map.of(AttendancePolicy.STD_MINUTES, "9999", AttendancePolicy.LATES_PER_HALF, "4", "LOCK:2026-10", "Y"));
        assertEquals(480, p.standardMinutes());
        assertEquals(4, p.latesPerHalfDay());
    }
}
