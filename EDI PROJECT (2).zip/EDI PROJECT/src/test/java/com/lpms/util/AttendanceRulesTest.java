package com.lpms.util;

import com.lpms.util.AttendanceRules.Leave;
import com.lpms.util.AttendanceRules.Rec;
import com.lpms.util.AttendanceRules.Summary;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class AttendanceRulesTest {
    // October 2026: starts Thursday; 22 weekdays (Oct 1-2, 5-9, 12-16, 19-23, 26-30)
    private static final YearMonth OCT = YearMonth.of(2026, 10);
    private static final LocalDate JOINED = LocalDate.of(2020, 1, 1);
    private static final LocalDate AFTER = LocalDate.of(2026, 11, 5); // "today" after the month: all days are past
    private final AttendancePolicy policy = new AttendancePolicy();

    private static BigDecimal bd(String s) { return new BigDecimal(s); }
    private static LocalDate oct(int d) { return LocalDate.of(2026, 10, d); }

    private Summary run(LocalDate today, Set<LocalDate> hol, Map<LocalDate, Rec> recs, Map<LocalDate, Leave> leaves, AttendancePolicy p) {
        return AttendanceRules.summarize(OCT, JOINED, null, today, hol, recs, leaves, p);
    }

    private Map<LocalDate, Rec> allPresent() {
        Map<LocalDate, Rec> m = new HashMap<>();
        for (int d = 1; d <= 31; d++) if (!AttendanceRules.isWeekend(oct(d))) m.put(oct(d), new Rec("PRESENT", LocalTime.of(9, 0)));
        return m;
    }

    @Test
    void fullAttendanceHasNoLop() {
        Summary s = run(AFTER, Set.of(), allPresent(), Map.of(), policy);
        assertEquals(22, s.workingDays);
        assertEquals(0, bd("22").compareTo(s.presentDays));
        assertEquals(0, BigDecimal.ZERO.compareTo(s.lopDays));
        assertEquals(0, bd("22").compareTo(s.payableDays()));
    }

    @Test
    void holidaysAreNotWorkingDays() {
        Summary s = run(AFTER, Set.of(oct(2)), allPresent(), Map.of(), policy);
        assertEquals(21, s.workingDays);
        assertEquals(1, s.holidays);
        assertEquals(9, s.weekends);
    }

    @Test
    void absentAndMissingDaysAreLop() {
        Map<LocalDate, Rec> r = allPresent();
        r.put(oct(5), new Rec("ABSENT", null)); // explicit absent
        r.remove(oct(6));                         // missing record, treated as absent by default
        Summary s = run(AFTER, Set.of(), r, Map.of(), policy);
        assertEquals(0, bd("2").compareTo(s.absentDays));
        assertEquals(0, bd("2").compareTo(s.lopDays));
        assertEquals(1, s.unrecordedDays);
        assertEquals(0, bd("20").compareTo(s.payableDays()));
    }

    @Test
    void missingDayCanBeIgnoredByPolicy() {
        AttendancePolicy p = AttendancePolicy.of(Map.of(AttendancePolicy.MISSING_DAY, "IGNORE"));
        Map<LocalDate, Rec> r = allPresent();
        r.remove(oct(6));
        Summary s = run(AFTER, Set.of(), r, Map.of(), p);
        assertEquals(0, BigDecimal.ZERO.compareTo(s.lopDays));
        assertEquals(1, s.unrecordedDays);
    }

    @Test
    void paidLeaveIsNotLopButUnpaidLeaveIs() {
        Map<LocalDate, Rec> r = allPresent();
        r.remove(oct(7)); r.remove(oct(8));
        Map<LocalDate, Leave> l = new HashMap<>();
        l.put(oct(7), new Leave(BigDecimal.ONE, true, "Casual Leave"));
        l.put(oct(8), new Leave(BigDecimal.ONE, false, "Loss of Pay"));
        Summary s = run(AFTER, Set.of(), r, l, policy);
        assertEquals(0, bd("1").compareTo(s.paidLeaveDays));
        assertEquals(0, bd("1").compareTo(s.unpaidLeaveDays));
        assertEquals(0, bd("1").compareTo(s.lopDays));
        assertEquals(0, BigDecimal.ZERO.compareTo(s.absentDays));
    }

    @Test
    void approvedLeaveOverridesAbsentRecord() {
        Map<LocalDate, Rec> r = allPresent();
        r.put(oct(7), new Rec("ABSENT", null));
        Summary s = run(AFTER, Set.of(), r, Map.of(oct(7), new Leave(BigDecimal.ONE, true, "Sick Leave")), policy);
        assertEquals(0, BigDecimal.ZERO.compareTo(s.lopDays));
        assertEquals(0, bd("1").compareTo(s.paidLeaveDays));
    }

    @Test
    void presentOnLeaveDayIsPresentAndFlagged() {
        Summary s = run(AFTER, Set.of(), allPresent(), Map.of(oct(7), new Leave(BigDecimal.ONE, true, "Casual Leave")), policy);
        assertEquals(0, bd("22").compareTo(s.presentDays));
        assertEquals(0, BigDecimal.ZERO.compareTo(s.paidLeaveDays));
        assertEquals(1, s.conflictDays);
    }

    @Test
    void halfDayRecordLeavesHalfLopUnlessCoveredByHalfLeave() {
        Map<LocalDate, Rec> r = allPresent();
        r.put(oct(7), new Rec("HALF_DAY", LocalTime.of(9, 0)));
        r.put(oct(8), new Rec("HALF_DAY", LocalTime.of(9, 0)));
        Summary s = run(AFTER, Set.of(), r, Map.of(oct(8), new Leave(AttendanceRules.HALF, true, "Casual Leave")), policy);
        assertEquals(0, bd("0.5").compareTo(s.lopDays));      // only Oct 7's other half
        assertEquals(0, bd("0.5").compareTo(s.paidLeaveDays));
        assertEquals(0, bd("21").compareTo(s.presentDays));   // 20 full + 2 halves
    }

    @Test
    void halfDayLeaveWithNoAttendanceLeavesHalfAbsent() {
        Map<LocalDate, Rec> r = allPresent();
        r.remove(oct(7));
        Summary s = run(AFTER, Set.of(), r, Map.of(oct(7), new Leave(AttendanceRules.HALF, true, "Casual Leave")), policy);
        assertEquals(0, bd("0.5").compareTo(s.lopDays));
        assertEquals(0, bd("0.5").compareTo(s.paidLeaveDays));
    }

    @Test
    void todayAndFutureDaysArePendingNotLop() {
        LocalDate today = oct(14);
        Map<LocalDate, Rec> r = new HashMap<>();
        for (int d = 1; d <= 13; d++) if (!AttendanceRules.isWeekend(oct(d))) r.put(oct(d), new Rec("PRESENT", LocalTime.of(9, 0)));
        Summary s = run(today, Set.of(), r, Map.of(), policy);
        assertEquals(0, BigDecimal.ZERO.compareTo(s.lopDays));
        assertEquals(13, s.pendingDays); // Oct 14-16, 19-23, 26-30
    }

    @Test
    void joiningAndExitLimitTheWorkingDays() {
        Summary s = AttendanceRules.summarize(OCT, oct(19), oct(23), AFTER, Set.of(), allPresent(), Map.of(), policy);
        assertEquals(5, s.workingDays);
        Map<LocalDate, Rec> none = new HashMap<>();
        s = AttendanceRules.summarize(OCT, oct(19), null, AFTER, Set.of(), none, Map.of(), policy);
        assertEquals(10, s.workingDays);
        assertEquals(0, bd("10").compareTo(s.lopDays));
    }

    @Test
    void lateMarksConvertToHalfDayLopWhenConfigured() {
        AttendancePolicy p = AttendancePolicy.of(Map.of(AttendancePolicy.LATES_PER_HALF, "3", AttendancePolicy.LATE_AFTER, "09:30"));
        Map<LocalDate, Rec> r = allPresent();
        for (int d : new int[]{1, 2, 5, 6, 7, 8, 9}) r.put(oct(d), new Rec("PRESENT", LocalTime.of(10, 0))); // 7 late marks
        Summary s = run(AFTER, Set.of(), r, Map.of(), p);
        assertEquals(7, s.lateMarks);
        assertEquals(0, bd("1.0").compareTo(s.lopDays)); // floor(7/3)=2 -> 1.0 day
        assertEquals(0, bd("1.0").compareTo(s.lateLopDays));
    }

    @Test
    void lateRuleDisabledByDefaultAndGraceTimeIsInclusive() {
        Map<LocalDate, Rec> r = allPresent();
        r.put(oct(1), new Rec("PRESENT", LocalTime.of(9, 30))); // exactly at threshold: not late
        r.put(oct(2), new Rec("PRESENT", LocalTime.of(11, 0)));
        Summary s = run(AFTER, Set.of(), r, Map.of(), policy);
        assertEquals(1, s.lateMarks);
        assertEquals(0, BigDecimal.ZERO.compareTo(s.lopDays));
    }

    @Test
    void workedAndOvertimeMinutes() {
        LocalDateTime in = LocalDateTime.of(2026, 10, 1, 9, 0);
        assertEquals(570, AttendanceRules.workedMinutes(in, in.plusMinutes(570)));
        assertEquals(0, AttendanceRules.workedMinutes(in, in.minusMinutes(5)));
        assertEquals(90, AttendanceRules.overtimeMinutes(570, 480));
        assertEquals(0, AttendanceRules.overtimeMinutes(400, 480));
    }
}
