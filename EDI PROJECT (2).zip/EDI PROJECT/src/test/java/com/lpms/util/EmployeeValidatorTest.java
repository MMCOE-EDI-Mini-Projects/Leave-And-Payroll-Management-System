package com.lpms.util;

import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class EmployeeValidatorTest {
    private static final LocalDate TODAY = LocalDate.of(2026, 10, 18);

    @Test
    void codeNameEmailUsername() {
        assertNull(EmployeeValidator.code("EMP0002"));
        assertNotNull(EmployeeValidator.code("E"));
        assertNotNull(EmployeeValidator.code("EMP 02"));
        assertNull(EmployeeValidator.name("Mary-Ann", "First name"));
        assertNull(EmployeeValidator.name("O'Brien", "Last name"));
        assertNotNull(EmployeeValidator.name("R2D2", "First name"));
        assertNotNull(EmployeeValidator.name("", "First name"));
        assertNull(EmployeeValidator.email("a@b.com"));
        assertNotNull(EmployeeValidator.email("not-an-email"));
        assertNull(EmployeeValidator.username("john.doe"));
        assertNotNull(EmployeeValidator.username("a b"));
    }

    @Test
    void phoneIsOptionalButChecked() {
        assertNull(EmployeeValidator.phone(null));
        assertNull(EmployeeValidator.phone(""));
        assertNull(EmployeeValidator.phone("+91 98765 43210"));
        assertNotNull(EmployeeValidator.phone("12345"));
        assertNotNull(EmployeeValidator.phone("abc1234567"));
    }

    @Test
    void enumsAreWhitelisted() {
        assertNull(EmployeeValidator.gender("OTHER"));
        assertNotNull(EmployeeValidator.gender("male"));
        assertNull(EmployeeValidator.type("INTERN"));
        assertNotNull(EmployeeValidator.type("CONTRACT"));
        assertNull(EmployeeValidator.status("ON_LEAVE"));
        assertNotNull(EmployeeValidator.status("FIRED"));
    }

    @Test
    void parseDateIsStrict() {
        assertEquals(LocalDate.of(2024, 2, 29), EmployeeValidator.parseDate("2024-02-29"));
        assertNull(EmployeeValidator.parseDate("2025-02-29"));
        assertNull(EmployeeValidator.parseDate("29/02/2024"));
        assertNull(EmployeeValidator.parseDate(null));
    }

    @Test
    void dateRules() {
        LocalDate join = LocalDate.of(2024, 1, 10);
        assertNull(EmployeeValidator.dates(LocalDate.of(1995, 5, 5), join, null, TODAY));
        assertNotNull(EmployeeValidator.dates(null, null, null, TODAY));
        assertNotNull(EmployeeValidator.dates(TODAY.plusDays(1), join, null, TODAY));           // DOB in future
        assertNotNull(EmployeeValidator.dates(LocalDate.of(2015, 1, 1), join, null, TODAY));    // under 16 at joining
        assertNotNull(EmployeeValidator.dates(null, join, join.minusDays(1), TODAY));           // exit before joining
        assertNull(EmployeeValidator.dates(null, join, join, TODAY));
        assertNotNull(EmployeeValidator.dates(null, TODAY.plusYears(2), null, TODAY));          // joining too far ahead
    }
}
