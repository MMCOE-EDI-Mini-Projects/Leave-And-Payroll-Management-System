package com.lpms.util;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

class LeaveRulesTest {
    // 2026-10-19 is a Monday
    private static final LocalDate MON = LocalDate.of(2026, 10, 19);

    @Test
    void countsOnlyWorkingDays() {
        assertEquals(0, new BigDecimal("5").compareTo(LeaveRules.countDays(MON, MON.plusDays(6), false))); // Mon..Sun
        assertEquals(0, BigDecimal.ZERO.compareTo(LeaveRules.countDays(MON.plusDays(5), MON.plusDays(6), false))); // Sat..Sun
        assertEquals(0, new BigDecimal("1").compareTo(LeaveRules.countDays(MON, MON, false)));
    }

    @Test
    void halfDayIsSingleDateOnly() {
        assertEquals(0, new BigDecimal("0.5").compareTo(LeaveRules.countDays(MON, MON, true)));
        assertThrows(IllegalArgumentException.class, () -> LeaveRules.countDays(MON, MON.plusDays(1), true));
    }

    @Test
    void rejectsInvalidRanges() {
        LocalDate today = LocalDate.of(2026, 10, 18);
        assertNull(LeaveRules.validateDates(MON, MON.plusDays(2), today));
        assertNotNull(LeaveRules.validateDates(MON.plusDays(2), MON, today));                 // end before start
        assertNotNull(LeaveRules.validateDates(LocalDate.of(2026, 12, 30), LocalDate.of(2027, 1, 2), today)); // spans years
        assertNotNull(LeaveRules.validateDates(today.minusDays(31), today, today));            // too far back
        assertNull(LeaveRules.validateDates(today.minusDays(30), today, today));
        assertNotNull(LeaveRules.validateDates(null, MON, today));
    }

    @Test
    void detectsOverlap() {
        assertTrue(LeaveRules.overlaps(MON, MON.plusDays(2), MON.plusDays(2), MON.plusDays(4)));  // share one day
        assertFalse(LeaveRules.overlaps(MON, MON.plusDays(1), MON.plusDays(2), MON.plusDays(4))); // adjacent
        assertTrue(LeaveRules.overlaps(MON, MON.plusDays(9), MON.plusDays(2), MON.plusDays(3)));  // contained
    }
}
