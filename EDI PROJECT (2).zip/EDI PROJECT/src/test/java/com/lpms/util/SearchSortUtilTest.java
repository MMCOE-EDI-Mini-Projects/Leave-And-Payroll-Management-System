package com.lpms.util;

import com.lpms.model.Employee;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SearchSortUtilTest {

    @Test
    void testBinarySearchEmployeeByCode() {
        List<Employee> employees = new ArrayList<>();
        Employee e1 = new Employee(); e1.setEmployeeCode("EMP0001");
        Employee e2 = new Employee(); e2.setEmployeeCode("EMP0002");
        Employee e3 = new Employee(); e3.setEmployeeCode("EMP0003");
        Employee e4 = new Employee(); e4.setEmployeeCode("EMP0004");
        employees.addAll(Arrays.asList(e1, e2, e3, e4));

        int index = SearchSortUtil.binarySearchEmployeeByCode(employees, "EMP0003");
        assertEquals(2, index);

        int missing = SearchSortUtil.binarySearchEmployeeByCode(employees, "EMP9999");
        assertEquals(-1, missing);
    }

    @Test
    void testMergeSortNumbers() {
        List<Integer> numbers = new ArrayList<>(Arrays.asList(45, 12, 85, 32, 89, 39, 69, 44, 42, 1, 6, 8));
        SearchSortUtil.mergeSort(numbers, Comparator.naturalOrder());

        List<Integer> expected = Arrays.asList(1, 6, 8, 12, 32, 39, 42, 44, 45, 69, 85, 89);
        assertEquals(expected, numbers);
    }

    @Test
    void testQuickSortStrings() {
        List<String> words = new ArrayList<>(Arrays.asList("Payroll", "Attendance", "Leave", "Employee", "Department", "Designation"));
        SearchSortUtil.quickSort(words, Comparator.naturalOrder());

        List<String> expected = Arrays.asList("Attendance", "Department", "Designation", "Employee", "Leave", "Payroll");
        assertEquals(expected, words);
    }

    @Test
    void testMergeSortStableOnDuplicateKeys() {
        List<String> items = new ArrayList<>(Arrays.asList("apple", "banana", "apricot", "blueberry"));
        // Sort by length
        SearchSortUtil.mergeSort(items, Comparator.comparingInt(String::length));

        // apple (5), apricot (7), banana (6), blueberry (9)
        assertEquals("apple", items.get(0));
        assertEquals("banana", items.get(1));
        assertEquals("apricot", items.get(2));
        assertEquals("blueberry", items.get(3));
    }
}
