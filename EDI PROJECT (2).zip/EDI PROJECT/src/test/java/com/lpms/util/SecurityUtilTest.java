package com.lpms.util;

import com.lpms.service.AuthService;
import org.junit.jupiter.api.Test;

import java.util.concurrent.atomic.AtomicLong;

import static org.junit.jupiter.api.Assertions.*;

class SecurityUtilTest {

    @Test
    void passwordPolicyRules() {
        assertNotNull(PasswordPolicy.validate(null));
        assertNotNull(PasswordPolicy.validate("short1"));
        assertNotNull(PasswordPolicy.validate("onlyletters"));
        assertNotNull(PasswordPolicy.validate("12345678"));
        assertNotNull(PasswordPolicy.validate("a1".repeat(40)));
        assertNull(PasswordPolicy.validate("Admin@123"));
    }

    @Test
    void throttleLocksAfterFiveFailuresAndExpires() {
        AtomicLong now = new AtomicLong(1_000);
        LoginThrottle t = new LoginThrottle(now::get);
        for (int i = 0; i < LoginThrottle.MAX_FAILURES - 1; i++) t.recordFailure("u");
        assertEquals(0, t.secondsLocked("u"));
        t.recordFailure("u");
        assertTrue(t.secondsLocked("u") > 0);
        assertEquals(0, t.secondsLocked("other"));
        now.addAndGet(LoginThrottle.LOCK_MS + 1);
        assertEquals(0, t.secondsLocked("u"));
    }

    @Test
    void throttleResetsOnSuccess() {
        LoginThrottle t = new LoginThrottle();
        for (int i = 0; i < 4; i++) t.recordFailure("u");
        t.recordSuccess("u");
        t.recordFailure("u");
        assertEquals(0, t.secondsLocked("u"));
    }

    @Test
    void bcryptHashAndVerify() {
        AuthService s = new AuthService();
        String h = s.hashPassword("Secret123");
        assertNotEquals("Secret123", h);
        assertTrue(s.verify("Secret123", h));
        assertFalse(s.verify("Wrong123", h));
        assertFalse(s.verify("x", "not-a-bcrypt-hash"));
        assertFalse(s.verify(null, h));
    }

    @Test
    void stampChangesWithHash() {
        assertNotEquals(AuthService.stamp("hashA"), AuthService.stamp("hashB"));
    }
}
